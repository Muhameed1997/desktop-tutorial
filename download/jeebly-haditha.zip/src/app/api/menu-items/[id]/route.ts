import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// PATCH /api/menu-items/[id] - تعديل صنف
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const allowed = ["name", "description", "price", "section", "imageUrl", "isAvailable", "isPopular", "storeId"] as const;

    const data: Record<string, unknown> = {};
    for (const key of allowed) {
      if (key in body) data[key] = body[key];
    }

    const item = await db.menuItem.update({ where: { id }, data });
    return NextResponse.json(item);
  } catch (error) {
    console.error("PATCH /api/menu-items/[id] error:", error);
    return NextResponse.json({ error: "خطأ في تعديل الصنف" }, { status: 500 });
  }
}

// DELETE /api/menu-items/[id] - حذف صنف
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.menuItem.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("DELETE /api/menu-items/[id] error:", error);
    return NextResponse.json({ error: "خطأ في حذف الصنف" }, { status: 500 });
  }
}
