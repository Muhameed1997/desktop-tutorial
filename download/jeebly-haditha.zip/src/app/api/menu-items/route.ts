import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/menu-items?storeId=... - أصناف متجر معين
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const storeId = searchParams.get("storeId");
    const where: Record<string, unknown> = {};
    if (storeId) where.storeId = storeId;

    const items = await db.menuItem.findMany({
      where,
      orderBy: { createdAt: "asc" },
    });
    return NextResponse.json(items);
  } catch (error) {
    console.error("GET /api/menu-items error:", error);
    return NextResponse.json({ error: "خطأ في جلب الأصناف" }, { status: 500 });
  }
}

// POST /api/menu-items - إضافة صنف جديد
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { storeId, name, description, price, section, imageUrl, isAvailable, isPopular } = body;

    if (!storeId || !name || price == null) {
      return NextResponse.json({ error: "الاسم والسعر مطلوبان" }, { status: 400 });
    }

    const item = await db.menuItem.create({
      data: {
        storeId,
        name: String(name).trim(),
        description: description || null,
        price: Number(price),
        section: section || "الأطباق الرئيسية",
        imageUrl: imageUrl || null,
        isAvailable: isAvailable != null ? Boolean(isAvailable) : true,
        isPopular: isPopular != null ? Boolean(isPopular) : false,
      },
    });

    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    console.error("POST /api/menu-items error:", error);
    return NextResponse.json({ error: "خطأ في إضافة الصنف" }, { status: 500 });
  }
}
