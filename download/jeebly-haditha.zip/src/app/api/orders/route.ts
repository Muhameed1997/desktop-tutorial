import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";
import { HADITHA_CENTER } from "@/lib/geo";

function generateOrderCode(): string {
  const digits = Math.floor(100000 + Math.random() * 900000);
  return `TT-${digits}`;
}

// GET /api/orders - جلب الطلبات (مع فلترة حسب الحالة أو الوكيل أو الكود أو حسابي)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const agentId = searchParams.get("agentId");
    const code = searchParams.get("code");
    const storeId = searchParams.get("storeId");
    const mine = searchParams.get("mine");

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (agentId) where.agentId = agentId;
    if (code) where.code = code;
    if (storeId) where.storeId = storeId;

    // طلبات المستخدم المسجَّل فقط
    if (mine === "1") {
      const uid = await getSessionUserId();
      if (!uid) return NextResponse.json({ error: "يجب تسجيل الدخول" }, { status: 401 });
      where.userId = uid;
    }

    const orders = await db.order.findMany({
      where,
      orderBy: { createdAt: "desc" },
      include: {
        store: { select: { id: true, name: true, imageUrl: true, type: true, lat: true, lng: true } },
        agent: { select: { id: true, name: true, phone: true, vehicleType: true } },
        items: true,
      },
    });

    return NextResponse.json(orders);
  } catch (error) {
    console.error("GET /api/orders error:", error);
    return NextResponse.json({ error: "خطأ في جلب الطلبات" }, { status: 500 });
  }
}

// POST /api/orders - إنشاء طلب جديد من العميل (يتطلب حساباً)
export async function POST(req: NextRequest) {
  try {
    const uid = await getSessionUserId();
    if (!uid) {
      return NextResponse.json(
        { error: "أنشئ حساباً أو سجّل الدخول لتتمكن من الطلب" },
        { status: 401 }
      );
    }

    const body = await req.json();
    const { storeId, customerName, customerPhone, address, notes, paymentMethod, items, destLat, destLng } = body;

    if (!storeId || !customerName || !customerPhone || !address || !Array.isArray(items) || items.length === 0) {
      return NextResponse.json(
        { error: "بيانات الطلب غير مكتملة (المتجر، الاسم، الهاتف، العنوان، والأصناف مطلوبة)" },
        { status: 400 }
      );
    }

    const store = await db.store.findUnique({ where: { id: storeId } });
    if (!store) {
      return NextResponse.json({ error: "المتجر غير موجود" }, { status: 404 });
    }
    if (!store.isOpen) {
      return NextResponse.json({ error: "هذا المتجر مغلق حالياً" }, { status: 400 });
    }

    const subtotal = items.reduce((sum: number, it: { price: number; quantity: number }) => {
      return sum + Number(it.price) * Number(it.quantity);
    }, 0);

    if (subtotal < store.minOrder) {
      return NextResponse.json(
        { error: `الحد الأدنى للطلب من هذا المتجر هو ${store.minOrder} د.ع` },
        { status: 400 }
      );
    }

    const deliveryFee = store.deliveryFee;
    const total = subtotal + deliveryFee;

    const order = await db.order.create({
      data: {
        code: generateOrderCode(),
        customerName: String(customerName).trim(),
        customerPhone: String(customerPhone).trim(),
        address: String(address).trim(),
        notes: notes || null,
        userId: uid,
        storeId,
        paymentMethod: paymentMethod || "CASH",
        subtotal,
        deliveryFee,
        total,
        destLat: destLat != null ? Number(destLat) : HADITHA_CENTER.lat,
        destLng: destLng != null ? Number(destLng) : HADITHA_CENTER.lng,
        status: "PENDING",
        items: {
          create: items.map((it: { name: string; price: number; quantity: number }) => ({
            name: it.name,
            price: Number(it.price),
            quantity: Number(it.quantity),
          })),
        },
      },
      include: {
        store: { select: { id: true, name: true, imageUrl: true, type: true, lat: true, lng: true } },
        agent: true,
        items: true,
      },
    });

    return NextResponse.json(order, { status: 201 });
  } catch (error) {
    console.error("POST /api/orders error:", error);
    return NextResponse.json({ error: "خطأ في إنشاء الطلب" }, { status: 500 });
  }
}
