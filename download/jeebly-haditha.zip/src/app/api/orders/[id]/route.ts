import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { haversineKm, etaMinutesFor } from "@/lib/geo";

// GET /api/orders/[id] - تفاصيل طلب
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const order = await db.order.findUnique({
      where: { id },
      include: {
        store: { select: { id: true, name: true, imageUrl: true, type: true } },
        agent: true,
        items: true,
      },
    });
    if (!order) {
      return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
    }
    return NextResponse.json(order);
  } catch (error) {
    console.error("GET /api/orders/[id] error:", error);
    return NextResponse.json({ error: "خطأ في جلب الطلب" }, { status: 500 });
  }
}

// PATCH /api/orders/[id] - تحديث حالة الطلب أو إسناده لوكيل
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const { status, agentId, cancelReason } = body;

    const current = await db.order.findUnique({ where: { id } });
    if (!current) {
      return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
    }

    const data: Record<string, unknown> = {};

    if (status) data.status = status;

    if ("agentId" in body) {
      data.agentId = agentId; // قد يكون null لإلغاء الإسناد
    }

    if (cancelReason) data.notes = cancelReason;

    // عند بدء التوصيل يدوياً (من تطبيق الوكيل أو المدير): سجّل وقت الانطلاق واحسب مدة الوصول
    if (status === "DELIVERING") {
      const withStore = await db.order.findUnique({
        where: { id },
        select: { destLat: true, destLng: true, store: { select: { lat: true, lng: true } } },
      });
      const storeLoc = { lat: withStore?.store?.lat ?? 34.1329, lng: withStore?.store?.lng ?? 42.3775 };
      const dest = { lat: withStore?.destLat ?? 34.1329, lng: withStore?.destLng ?? 42.3775 };
      const vehicle = body.vehicleType === "CAR" ? "CAR" : "MOTORCYCLE";
      data.deliveringAt = new Date();
      data.etaMinutes = etaMinutesFor(haversineKm(storeLoc, dest), vehicle);
    }

    const order = await db.order.update({
      where: { id },
      data,
      include: {
        store: { select: { id: true, name: true, imageUrl: true, type: true } },
        agent: true,
        items: true,
      },
    });

    // تحديث حالة الوكيل تلقائياً: مشغول عند أسناده لطلب قيد التنفيذ، متاح عند التسليم
    if (order.agentId) {
      const activeStatuses = ["CONFIRMED", "PREPARING", "DELIVERING"];
      if (activeStatuses.includes(order.status)) {
        await db.agent.update({ where: { id: order.agentId }, data: { status: "BUSY" } }).catch(() => {});
      } else if (order.status === "DELIVERED" || order.status === "CANCELLED") {
        // عند التسليم: الوكيل يصبح متاحاً ويزيد عدد التوصيلات
        const agent = await db.agent.findUnique({ where: { id: order.agentId } });
        if (agent) {
          await db.agent.update({
            where: { id: order.agentId },
            data: {
              status: "AVAILABLE",
              totalDeliveries:
                order.status === "DELIVERED" ? agent.totalDeliveries + 1 : agent.totalDeliveries,
            },
          }).catch(() => {});
        }
      }
    }

    return NextResponse.json(order);
  } catch (error) {
    console.error("PATCH /api/orders/[id] error:", error);
    return NextResponse.json({ error: "خطأ في تحديث الطلب" }, { status: 500 });
  }
}
