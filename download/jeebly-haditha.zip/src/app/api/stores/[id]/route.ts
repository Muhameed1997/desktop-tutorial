import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/stores/[id] - تفاصيل متجر مع منيو
export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const store = await db.store.findUnique({
      where: { id },
      include: { items: { orderBy: { createdAt: "asc" } } },
    });
    if (!store) {
      return NextResponse.json({ error: "المتجر غير موجود" }, { status: 404 });
    }
    return NextResponse.json(store);
  } catch (error) {
    console.error("GET /api/stores/[id] error:", error);
    return NextResponse.json({ error: "خطأ في جلب المتجر" }, { status: 500 });
  }
}

// PATCH /api/stores/[id] - تعديل متجر
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const allowed = [
      "name", "description", "type", "category", "imageUrl", "coverUrl",
      "rating", "deliveryFee", "deliveryTime", "minOrder", "isOpen",
      "isFeatured", "phone", "address", "lat", "lng",
    ] as const;

    const data: Record<string, unknown> = {};
    for (const key of allowed) {
      if (key in body) data[key] = body[key];
    }

    const store = await db.store.update({ where: { id }, data });
    return NextResponse.json(store);
  } catch (error) {
    console.error("PATCH /api/stores/[id] error:", error);
    return NextResponse.json({ error: "خطأ في تعديل المتجر" }, { status: 500 });
  }
}

// DELETE /api/stores/[id] - حذف متجر
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.store.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("DELETE /api/stores/[id] error:", error);
    return NextResponse.json({ error: "خطأ في حذف المتجر" }, { status: 500 });
  }
}
