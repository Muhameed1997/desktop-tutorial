import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/stores - قائمة المتاجر (مطاعم/متاجر/أسواق)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const type = searchParams.get("type");
    const q = searchParams.get("q");
    const featured = searchParams.get("featured");

    const where: Record<string, unknown> = {};
    if (type && type !== "ALL") where.type = type;
    if (featured === "true") where.isFeatured = true;
    if (q) {
      where.OR = [
        { name: { contains: q } },
        { category: { contains: q } },
        { description: { contains: q } },
      ];
    }

    const stores = await db.store.findMany({
      where,
      orderBy: [{ isFeatured: "desc" }, { rating: "desc" }],
      include: { items: { select: { id: true } } },
    });

    return NextResponse.json(stores);
  } catch (error) {
    console.error("GET /api/stores error:", error);
    return NextResponse.json({ error: "خطأ في جلب المتاجر" }, { status: 500 });
  }
}

// POST /api/stores - إضافة متجر جديد (من لوحة المدير)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const {
      name,
      description,
      type,
      category,
      imageUrl,
      coverUrl,
      rating,
      deliveryFee,
      deliveryTime,
      minOrder,
      isOpen,
      isFeatured,
      phone,
      address,
      lat,
      lng,
    } = body;

    if (!name || String(name).trim().length === 0) {
      return NextResponse.json({ error: "اسم المتجر مطلوب" }, { status: 400 });
    }

    const store = await db.store.create({
      data: {
        name: String(name).trim(),
        description: description || null,
        type: type || "RESTAURANT",
        category: category || "مطاعم",
        imageUrl: imageUrl || null,
        coverUrl: coverUrl || null,
        rating: rating != null ? Number(rating) : 4.5,
        deliveryFee: deliveryFee != null ? Number(deliveryFee) : 1000,
        deliveryTime: deliveryTime || "30-45 دقيقة",
        minOrder: minOrder != null ? Number(minOrder) : 0,
        isOpen: isOpen != null ? Boolean(isOpen) : true,
        isFeatured: isFeatured != null ? Boolean(isFeatured) : false,
        phone: phone || null,
        address: address || null,
        lat: lat != null && lat !== "" ? Number(lat) : 34.1329,
        lng: lng != null && lng !== "" ? Number(lng) : 42.3775,
      },
    });

    return NextResponse.json(store, { status: 201 });
  } catch (error) {
    console.error("POST /api/stores error:", error);
    return NextResponse.json({ error: "خطأ في إضافة المتجر" }, { status: 500 });
  }
}
