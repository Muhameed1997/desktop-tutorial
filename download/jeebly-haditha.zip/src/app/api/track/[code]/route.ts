import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { haversineKm, interpolate, etaMinutesFor } from "@/lib/geo";

// مدة المراحل التجريبية (بالثواني) لتقدم الطلب تلقائياً أثناء التتبع
const T_ACCEPT = 8; // PENDING → CONFIRMED
const T_PREPARE = 20; // CONFIRMED → PREPARING (بعد القبول)
const T_DISPATCH = 35; // PREPARING → DELIVERING (بعد بدء التحضير)

const orderInclude = {
  store: { select: { id: true, name: true, imageUrl: true, type: true, lat: true, lng: true, address: true } },
  agent: { select: { id: true, name: true, phone: true, vehicleType: true, vehiclePlate: true, rating: true, lat: true, lng: true } },
  items: true,
};

/**
 * GET /api/track/[code] — تتبع مباشر:
 * يقدّم حالة الطلب تلقائياً مع الزمن، يسند وكيل عند بدء التوصيل،
 * ويحسب موقع السائق الحالي بين المتجر وموقع العميل + مدة الوصول المتبقية.
 */
export async function GET(_req: NextRequest, { params }: { params: Promise<{ code: string }> }) {
  try {
    const { code } = await params;
    let order = await db.order.findFirst({
      where: { code },
      include: orderInclude,
    });
    if (!order) return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });

    const ageSec = (Date.now() - new Date(order.createdAt).getTime()) / 1000;
    let mutated = false;

    // ===== التقدم التلقائي للطلب =====
    if (order.status === "PENDING" && ageSec >= T_ACCEPT) {
      await db.order.update({ where: { id: order.id }, data: { status: "CONFIRMED" } });
      mutated = true;
    }
    if (["PENDING", "CONFIRMED"].includes(order.status) && ageSec >= T_ACCEPT + T_PREPARE) {
      await db.order.update({ where: { id: order.id }, data: { status: "PREPARING" } });
      mutated = true;
    }
    if (["PENDING", "CONFIRMED", "PREPARING"].includes(order.status) && ageSec >= T_ACCEPT + T_PREPARE + T_DISPATCH) {
      // إسناد أول وكيل متاح داخل حديثة
      const agent = await db.agent.findFirst({
        where: { status: "AVAILABLE" },
        orderBy: { rating: "desc" },
      });
      if (agent) {
        const dest = { lat: order.destLat ?? 34.1329, lng: order.destLng ?? 42.3775 };
        const storeLoc = {
          lat: order.store?.lat ?? 34.1329,
          lng: order.store?.lng ?? 42.3775,
        };
        const eta = etaMinutesFor(haversineKm(storeLoc, dest), agent.vehicleType);
        await db.order.update({
          where: { id: order.id },
          data: {
            status: "DELIVERING",
            agentId: agent.id,
            deliveringAt: new Date(),
            etaMinutes: eta,
          },
        });
        await db.agent.update({ where: { id: agent.id }, data: { status: "BUSY" } }).catch(() => {});
        mutated = true;
      }
    }

    if (order.status === "DELIVERING" && order.deliveringAt && order.etaMinutes) {
      const elapsedMin = (Date.now() - new Date(order.deliveringAt).getTime()) / 60000;
      if (elapsedMin >= order.etaMinutes) {
        await db.order.update({ where: { id: order.id }, data: { status: "DELIVERED" } });
        if (order.agentId) {
          const ag = await db.agent.findUnique({ where: { id: order.agentId } });
          if (ag) {
            await db.agent
              .update({
                where: { id: order.agentId },
                data: { status: "AVAILABLE", totalDeliveries: ag.totalDeliveries + 1 },
              })
              .catch(() => {});
          }
        }
        mutated = true;
      }
    }

    if (mutated) {
      order = await db.order.findFirst({ where: { code }, include: orderInclude });
      if (!order) return NextResponse.json({ error: "الطلب غير موجود" }, { status: 404 });
    }

    // ===== حساب موقع السائق والوقت المتبقي =====
    let driver: { lat: number; lng: number; progress: number } | null = null;
    let etaRemaining: number | null = null;
    const storeLoc = {
      lat: order.store?.lat ?? 34.1329,
      lng: order.store?.lng ?? 42.3775,
    };
    const dest = { lat: order.destLat ?? 34.1329, lng: order.destLng ?? 42.3775 };

    if (order.status === "DELIVERING" && order.deliveringAt && order.etaMinutes) {
      const totalMs = order.etaMinutes * 60000;
      const elapsed = Math.min(totalMs, Math.max(0, Date.now() - new Date(order.deliveringAt).getTime()));
      const progress = totalMs > 0 ? elapsed / totalMs : 0;
      const pos = interpolate(storeLoc, dest, progress);
      etaRemaining = Math.max(0, Math.ceil(order.etaMinutes - elapsed / 60000));
      driver = { lat: pos.lat, lng: pos.lng, progress: Math.round(progress * 100) };
      // تحديث آخر موقع معروف للوكيل
      if (order.agentId) {
        await db.agent
          .update({ where: { id: order.agentId }, data: { lat: pos.lat, lng: pos.lng } })
          .catch(() => {});
      }
    } else if (order.status === "DELIVERED") {
      driver = { lat: dest.lat, lng: dest.lng, progress: 100 };
      etaRemaining = 0;
    }

    return NextResponse.json({ order, driver, etaRemaining, route: { from: storeLoc, to: dest } });
  } catch (error) {
    console.error("GET /api/track/[code] error:", error);
    return NextResponse.json({ error: "خطأ في جلب بيانات التتبع" }, { status: 500 });
  }
}
