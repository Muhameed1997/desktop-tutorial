import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

// PATCH /api/agents/[id] - تعديل وكيل
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();
    const allowed = ["name", "phone", "vehicleType", "vehiclePlate", "status", "rating", "totalDeliveries"] as const;

    const data: Record<string, unknown> = {};
    for (const key of allowed) {
      if (key in body) data[key] = body[key];
    }

    const agent = await db.agent.update({ where: { id }, data });
    return NextResponse.json(agent);
  } catch (error) {
    console.error("PATCH /api/agents/[id] error:", error);
    return NextResponse.json({ error: "خطأ في تعديل الوكيل" }, { status: 500 });
  }
}

// DELETE /api/agents/[id] - حذف وكيل
export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await db.agent.delete({ where: { id } });
    return NextResponse.json({ ok: true });
  } catch (error) {
    console.error("DELETE /api/agents/[id] error:", error);
    return NextResponse.json({ error: "خطأ في حذف الوكيل" }, { status: 500 });
  }
}
