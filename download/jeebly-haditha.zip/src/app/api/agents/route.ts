import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { randomHadithaPoint } from "@/lib/geo";

// GET /api/agents - قائمة الوكلاء (الكباتن)
export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const phone = searchParams.get("phone");

    const where: Record<string, unknown> = {};
    if (status) where.status = status;
    if (phone) where.phone = phone;

    const agents = await db.agent.findMany({
      where,
      orderBy: { createdAt: "asc" },
      include: {
        orders: {
          where: { status: { in: ["CONFIRMED", "PREPARING", "DELIVERING"] } },
          select: { id: true, code: true, status: true },
        },
      },
    });

    return NextResponse.json(agents);
  } catch (error) {
    console.error("GET /api/agents error:", error);
    return NextResponse.json({ error: "خطأ في جلب الوكلاء" }, { status: 500 });
  }
}

// POST /api/agents - إضافة وكيل جديد (سيارة أو دراجة)
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { name, phone, vehicleType, vehiclePlate, status, rating } = body;

    if (!name || !phone) {
      return NextResponse.json({ error: "الاسم ورقم الهاتف مطلوبان" }, { status: 400 });
    }

    const point = randomHadithaPoint(0.008);
    const agent = await db.agent.create({
      data: {
        name: String(name).trim(),
        phone: String(phone).trim(),
        vehicleType: vehicleType || "MOTORCYCLE",
        vehiclePlate: vehiclePlate || null,
        status: status || "AVAILABLE",
        rating: rating != null ? Number(rating) : 5,
        lat: body.lat != null ? Number(body.lat) : point.lat,
        lng: body.lng != null ? Number(body.lng) : point.lng,
      },
    });

    return NextResponse.json(agent, { status: 201 });
  } catch (error) {
    console.error("POST /api/agents error:", error);
    return NextResponse.json({ error: "خطأ في إضافة الوكيل" }, { status: 500 });
  }
}
