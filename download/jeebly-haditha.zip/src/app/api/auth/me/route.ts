import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSessionUserId } from "@/lib/auth";

// GET /api/auth/me - بيانات المستخدم الحالي (أو null)
export async function GET() {
  try {
    const uid = await getSessionUserId();
    if (!uid) return NextResponse.json(null);
    const user = await db.user.findUnique({
      where: { id: uid },
      select: { id: true, name: true, email: true, phone: true, address: true },
    });
    return NextResponse.json(user);
  } catch {
    return NextResponse.json(null);
  }
}
