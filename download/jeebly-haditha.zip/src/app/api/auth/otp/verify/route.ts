import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { createSessionToken, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth";
import { normalizeIrPhone } from "@/lib/phone";

// POST /api/auth/otp/verify — التحقق من الرمز ثم دخول/إنشاء الحساب تلقائياً
// لا توجد كلمة مرور: الحساب يُنشأ بمجرد التحقق من رقم الهاتف
export async function POST(req: NextRequest) {
  try {
    const { phone, code, name } = await req.json();
    const normalized = normalizeIrPhone(String(phone || ""));
    const otp = String(code || "").replace(/\D/g, "");

    if (!normalized) {
      return NextResponse.json({ error: "رقم الهاتف غير صحيح" }, { status: 400 });
    }
    if (otp.length !== 6) {
      return NextResponse.json({ error: "أدخل رمز التحقق المكوّن من 6 أرقام" }, { status: 400 });
    }

    const record = await db.otpCode.findUnique({ where: { phone: normalized } });
    if (!record) {
      return NextResponse.json(
        { error: "لم يتم إرسال رمز لهذا الرقم — اطلب رمزاً جديداً" },
        { status: 400 }
      );
    }
    if (record.expiresAt < new Date()) {
      await db.otpCode.delete({ where: { phone: normalized } }).catch(() => {});
      return NextResponse.json(
        { error: "انتهت صلاحية الرمز — اطلب رمزاً جديداً" },
        { status: 410 }
      );
    }
    if (record.attempts >= 5) {
      await db.otpCode.delete({ where: { phone: normalized } }).catch(() => {});
      return NextResponse.json(
        { error: "تجاوزت عدد المحاولات — اطلب رمزاً جديداً" },
        { status: 429 }
      );
    }

    if (record.code !== otp) {
      await db.otpCode.update({
        where: { phone: normalized },
        data: { attempts: { increment: 1 } },
      });
      const left = 5 - (record.attempts + 1);
      return NextResponse.json(
        { error: `الرمز غير صحيح — تبقّت ${Math.max(0, left)} محاولات` },
        { status: 401 }
      );
    }

    // الرمز صحيح — نحذفه (يُستخدم مرة واحدة)
    await db.otpCode.delete({ where: { phone: normalized } }).catch(() => {});

    // دخول تلقائي إذا كان الحساب موجوداً، وإلا إنشاؤه فوراً
    let user = await db.user.findUnique({ where: { phone: normalized } });
    let isNewUser = false;

    if (!user) {
      const cleanName = String(name || "").trim();
      user = await db.user.create({
        data: {
          name: cleanName.length >= 2 ? cleanName : "مستخدم جيبلي",
          phone: normalized,
        },
      });
      isNewUser = true;
    }

    const res = NextResponse.json({
      id: user.id,
      name: user.name,
      email: user.email,
      phone: user.phone,
      address: user.address,
      isNewUser,
    });
    res.cookies.set(SESSION_COOKIE, createSessionToken(user.id), sessionCookieOptions());
    return res;
  } catch (error) {
    console.error("POST /api/auth/otp/verify error:", error);
    return NextResponse.json({ error: "تعذر التحقق من الرمز، حاول مجدداً" }, { status: 500 });
  }
}
