import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { normalizeIrPhone } from "@/lib/phone";

// POST /api/auth/otp/send — إرسال رمز التحقق إلى الهاتف (التسجيل بالهاتف فقط، بدون كلمة مرور)
// ملاحظة: في النسخة التجريبية لا يوجد مزود SMS مربوط، فيُعاد الكود في الاستجابة
// (devCode) ليظهر للمستخدم على الشاشة. عند الربط بمزود SMS (Twilio/مزود عراقي)
// يُحذف devCode ويُرسل الكود فعلياً إلى الهاتف.
export async function POST(req: NextRequest) {
  try {
    const { phone } = await req.json();
    const normalized = normalizeIrPhone(String(phone || ""));

    if (!normalized) {
      return NextResponse.json(
        { error: "أدخل رقم هاتف عراقي صحيح (مثال: 07701234567)" },
        { status: 400 }
      );
    }

    // منع التكرار السريع: كود نشط أقل من 45 ثانية
    const existing = await db.otpCode.findUnique({ where: { phone: normalized } });
    if (existing && existing.expiresAt > new Date()) {
      const elapsedSec = Math.round(
        (5 * 60 * 1000 - (existing.expiresAt.getTime() - Date.now())) / 1000
      );
      if (elapsedSec < 45) {
        return NextResponse.json(
          { error: `انتظر ${45 - elapsedSec} ثانية قبل إعادة إرسال الرمز` },
          { status: 429 }
        );
      }
    }

    // توليد رمز من 6 أرقام وصلاحيته 5 دقائق
    const code = String(Math.floor(100000 + Math.random() * 900000));
    const expiresAt = new Date(Date.now() + 5 * 60 * 1000);

    await db.otpCode.upsert({
      where: { phone: normalized },
      update: { code, expiresAt, attempts: 0, createdAt: new Date() },
      create: { phone: normalized, code, expiresAt },
    });

    // هل الحساب موجود مسبقاً؟ (لتخصيص الرسالة)
    const user = await db.user.findUnique({ where: { phone: normalized } });

    return NextResponse.json({
      ok: true,
      phone: normalized,
      isNewUser: !user,
      expiresInSec: 300,
      // كود التجربة — يُحذف عند ربط مزود SMS حقيقي
      devCode: code,
      note: "النسخة التجريبية: يظهر الرمز هنا بدل وصوله كرسالة نصية",
    });
  } catch (error) {
    console.error("POST /api/auth/otp/send error:", error);
    return NextResponse.json({ error: "تعذر إرسال الرمز، حاول مجدداً" }, { status: 500 });
  }
}
