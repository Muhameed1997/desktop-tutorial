import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// GET /api/stats - إحصائيات لوحة تحكم المدير
export async function GET() {
  try {
    const [storesCount, restaurantsCount, storesTypeCount, marketsCount, agentsCount, availableAgents, ordersCount, activeOrders, deliveredOrders, cancelledOrders] =
      await Promise.all([
        db.store.count(),
        db.store.count({ where: { type: "RESTAURANT" } }),
        db.store.count({ where: { type: "STORE" } }),
        db.store.count({ where: { type: "MARKET" } }),
        db.agent.count(),
        db.agent.count({ where: { status: "AVAILABLE" } }),
        db.order.count(),
        db.order.count({ where: { status: { in: ["PENDING", "CONFIRMED", "PREPARING", "DELIVERING"] } } }),
        db.order.count({ where: { status: "DELIVERED" } }),
        db.order.count({ where: { status: "CANCELLED" } }),
      ]);

    const revenueAgg = await db.order.aggregate({
      where: { status: { in: ["DELIVERED", "DELIVERING", "PREPARING", "CONFIRMED"] } },
      _sum: { total: true },
    });

    const recentOrders = await db.order.findMany({
      orderBy: { createdAt: "desc" },
      take: 6,
      include: {
        store: { select: { name: true } },
        agent: { select: { name: true } },
      },
    });

    // أكثر المطاعم طلباً
    const topStores = await db.store.findMany({
      orderBy: { orders: { _count: "desc" } },
      take: 5,
      select: {
        id: true,
        name: true,
        type: true,
        imageUrl: true,
        _count: { select: { orders: true } },
      },
    });

    return NextResponse.json({
      stores: { total: storesCount, restaurants: restaurantsCount, stores: storesTypeCount, markets: marketsCount },
      agents: { total: agentsCount, available: availableAgents },
      orders: { total: ordersCount, active: activeOrders, delivered: deliveredOrders, cancelled: cancelledOrders },
      revenue: revenueAgg._sum.total || 0,
      recentOrders,
      topStores,
    });
  } catch (error) {
    console.error("GET /api/stats error:", error);
    return NextResponse.json({ error: "خطأ في جلب الإحصائيات" }, { status: 500 });
  }
}
