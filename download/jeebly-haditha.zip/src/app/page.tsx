"use client";

import { useEffect, useState } from "react";
import Image from "next/image";
import { useAppStore } from "@/store/app-store";
import { useAuthStore } from "@/store/auth-store";
import { Header } from "@/components/toters/header";
import { CustomerHome } from "@/components/toters/customer-home";
import { StoreView } from "@/components/toters/store-view";
import { CheckoutView } from "@/components/toters/checkout-view";
import { TrackView, MyOrdersView } from "@/components/toters/track-view";
import { AccountView } from "@/components/toters/account-view";
import { AdminPanel } from "@/components/toters/admin-panel";
import { AgentPanel } from "@/components/toters/agent-panel";
import { BottomNav } from "@/components/toters/bottom-nav";

export default function Home() {
  const view = useAppStore((s) => s.view);
  const [search, setSearch] = useState("");
  const [ready, setReady] = useState(false);
  const sync = useAuthStore((s) => s.sync);

  // انتظار تحميل الحالة المحفوظة (zustand persist) + مزامنة الجلسة
  useEffect(() => {
    sync();
    const t = setTimeout(() => setReady(true), 0);
    return () => clearTimeout(t);
  }, [sync]);

  if (!ready) {
    return (
      <main className="min-h-screen flex items-center justify-center bg-[#F8F9FA]">
        <div className="text-center px-6">
          {/* شاشة بداية جيبلي — لوغو بنبضة خفيفة بدل الدراجة العائمة */}
          <div className="relative inline-block mb-5">
            <span className="absolute inset-0 rounded-[28%] bg-[#FF6B00]/20 blur-2xl" />
            <Image
              src="/brand/jeebly-icon.png"
              alt="جيبلي Jeebly"
              width={104}
              height={104}
              priority
              className="relative h-26 w-26 rounded-[28%] shadow-brand logo-breathe"
            />
          </div>
          {/* اللوقو الرسمي */}
          <div className="flex justify-center mt-1">
            <Image
              src="/brand/jeebly-wordmark-dark.png"
              alt="jeebly | جيبلي"
              width={2463}
              height={501}
              priority
              className="h-8 w-auto"
            />
          </div>
          <p className="text-xs text-muted-foreground mt-2">توصيل سريع من مطاعم ومتاجر حديثة – الأنبار</p>
          <div className="relative h-1 w-40 mx-auto mt-5 rounded-full bg-[#FF6B00]/15 overflow-hidden">
            <span className="absolute inset-y-0 left-0 w-1/2 rounded-full brand-gradient splash-bar" />
          </div>
        </div>
      </main>
    );
  }

  const isCustomerView = ["home", "store", "checkout", "account", "track", "myOrders"].includes(view.name);

  return (
    <div className="min-h-screen flex flex-col">
      {isCustomerView && <Header search={search} onSearch={setSearch} />}

      <main className="flex-1">
        {view.name === "home" && <CustomerHome search={search} />}
        {view.name === "store" && <StoreView key={view.storeId} storeId={view.storeId} />}
        {view.name === "checkout" && <CheckoutView />}
        {view.name === "account" && <AccountView />}
        {view.name === "myOrders" && <MyOrdersView />}
        {view.name === "track" && <TrackView code={view.code} />}
        {view.name === "admin" && <AdminPanel />}
        {view.name === "agent" && <AgentPanel />}
      </main>

      {/* تذييل — يظهر على الشاشات الكبيرة فقط؛ الجوال يعتمد على الشريط السفلي */}
      <footer className="mt-auto border-t bg-white py-6 text-xs text-muted-foreground hidden md:block">
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <Image src="/brand/jeebly-icon.png" alt="جيبلي Jeebly" width={34} height={34} className="h-9 w-9 rounded-xl" />
            <div className="leading-tight">
              <Image
                src="/brand/jeebly-wordmark-dark.png"
                alt="jeebly | جيبلي"
                width={2463}
                height={501}
                className="h-5 w-auto"
              />
              <div className="mt-0.5">كل شي يوصلك… بسرعة</div>
            </div>
          </div>
          <span className="text-center">تطبيق توصيل المطاعم والمتاجر والأسواق · مدينة حديثة – محافظة الأنبار © 2025</span>
        </div>
      </footer>

      {isCustomerView && <BottomNav />}

      {/* زر عائم للعودة للوحة الإدارة عند التواجد فيها */}
      {(view.name === "admin" || view.name === "agent") && (
        <button
          onClick={() => useAppStore.getState().setView({ name: "home" })}
          className="fixed bottom-6 start-4 z-40 bg-[#FF6B00] text-white rounded-full shadow-xl px-4 py-3 text-sm font-bold hover:bg-[#E85F00] transition md:hidden"
        >
          🏠 الرئيسية
        </button>
      )}
    </div>
  );
}
