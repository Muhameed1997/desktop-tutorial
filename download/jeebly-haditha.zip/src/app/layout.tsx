import type { Metadata, Viewport } from "next";
import { Cairo, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";

const cairo = Cairo({
  variable: "--font-cairo",
  subsets: ["arabic", "latin"],
  weight: ["400", "500", "600", "700", "800", "900"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "جيبلي Jeebly | توصيل طلبات المطاعم والمتاجر – حديثة، الأنبار",
  description:
    "جيبلي — تطبيق التوصيل في مدينة حديثة – محافظة الأنبار: سجّل برقم هاتفك العراقي فقط عبر رمز التحقق، اطلب من المطاعم والمتاجر والأسواق، وتابع السائق مباشرة على خريطة حديثة مع مدة وصول متوقعة.",
  keywords: ["جيبلي", "Jeebly", "توصيل", "مطاعم", "متاجر", "أسواق", "حديثة", "الأنبار", "العراق", "delivery"],
  icons: {
    icon: "/brand/jeebly-icon.png",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  themeColor: "#ff6b00",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning>
      <body className={`${cairo.variable} ${geistMono.variable} antialiased bg-background text-foreground`}>
        {children}
        <Toaster />
      </body>
    </html>
  );
}
