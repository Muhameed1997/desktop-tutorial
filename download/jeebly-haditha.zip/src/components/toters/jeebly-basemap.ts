"use client";

// محرك خريطة جيبلي الموحد — مدينة حديثة، محافظة الأنبار
// خريطة حقيقية (شوارع ومبانٍ ونهر) بدون أي مطاعم أو متاجر خارجية:
// بلاطات CARTO light_nolabels + معالم حديثة المرسومة محلياً (مدارس، مشفى، دوار، جسر، أسواق، أحياء)
// علامات المطاعم تُضاف فقط من بيانات جيبلي عبر المكونات.
import "maplibre-gl/dist/maplibre-gl.css";
import type { Map as MlMap } from "maplibre-gl";
import { HADITHA_CENTER } from "@/lib/geo";

export interface JeeblyMapHandle {
  map: MlMap;
  /** وحدة maplibre-gl لإنشاء علامات إضافية */
  ml: typeof import("maplibre-gl");
  destroy: () => void;
}

/** معالم مدينة حديثة — مواقع تقريبية لغرض العرض داخل نطاق الخدمة */
export const HADITHA_LANDMARKS: { emoji: string; label: string; lat: number; lng: number }[] = [
  { emoji: "🏥", label: "مشفى حديثة العام", lat: 34.1348, lng: 42.3762 },
  { emoji: "🏫", label: "ثانوية حديثة للبنين", lat: 34.1364, lng: 42.3796 },
  { emoji: "🏫", label: "مدرسة الفرات الابتدائية", lat: 34.1310, lng: 42.3812 },
  { emoji: "🔄", label: "دوار المركز", lat: 34.1332, lng: 42.3779 },
  { emoji: "🔄", label: "دوار الستين", lat: 34.1301, lng: 42.3768 },
  { emoji: "🌉", label: "جسر حديثة", lat: 34.1287, lng: 42.3742 },
  { emoji: "🛒", label: "سوق حديثة القديم", lat: 34.1340, lng: 42.3800 },
  { emoji: "🌇", label: "كورنيش الفرات", lat: 34.1289, lng: 42.3792 },
  { emoji: "🏘️", label: "حي المعلمين", lat: 34.1362, lng: 42.3748 },
  { emoji: "🏘️", label: "حي الضباط", lat: 34.1301, lng: 42.3810 },
  { emoji: "🏘️", label: "حي الكرامة", lat: 34.1356, lng: 42.3822 },
  { emoji: "🕌", label: "جامع حديثة الكبير", lat: 34.1337, lng: 42.3764 },
  { emoji: "🛣️", label: "شارع الستين (60)", lat: 34.1318, lng: 42.3754 },
  { emoji: "🏞️", label: "نهر الفرات", lat: 34.1268, lng: 42.3774 },
];

/** عنصر علامة خريطة جيبلي (من إيموجي أو HTML جاهز) */
export function markerEl(innerHtml: string, extraClass = ""): HTMLElement {
  const el = document.createElement("div");
  el.className = `jb-marker ${extraClass}`.trim();
  el.innerHTML = innerHtml;
  return el;
}

/** عنصر معلم حديثة (شريحة بيضاء بأيقونة واسم عربي) */
function landmarkEl(emoji: string, label: string): HTMLElement {
  const el = document.createElement("div");
  el.className = "map-landmark";
  el.innerHTML = `<span class="em">${emoji}</span><span>${label}</span>`;
  return el;
}

/** نمط الخريطة: شوارع حقيقية بدون تسميات/مطاعم خارجية */
function basemapStyle(): maplibregl.StyleSpecification | any {
  return {
    version: 8,
    sources: {
      "jeebly-base": {
        type: "raster",
        // Esri Light Gray Canvas: شوارع حقيقية وأسماء أحياء — بدون مطاعم/متاجر خارجية (POI)
        // ملاحظة: ترتيب {z}/{y}/{x} خاص بخدمات Esri
        tiles: [
          "https://server.arcgisonline.com/ArcGIS/rest/services/Canvas/World_Light_Gray_Base/MapServer/tile/{z}/{y}/{x}",
        ],
        tileSize: 256,
        maxzoom: 16,
        attribution: "© Esri · © OpenStreetMap contributors",
      },
    },
    layers: [
      { id: "jb-bg", type: "background", paint: { "background-color": "#E9EEF3" } },
      { id: "jb-tiles", type: "raster", source: "jeebly-base", paint: { "raster-fade-duration": 250 } },
    ],
  };
}

/**
 * إنشاء خريطة جيبلي لحديثة:
 * - بلاطات حقيقية (شوارع، مبانٍ، نهر الفرات) بلا أي معالم خارجية أو مطاعم
 * - معالم حديثة المضافة محلياً (مدارس، مشفى، دوار، جسر، أحياء…)
 */
export async function createJeeblyMap(
  container: HTMLElement,
  opts?: { zoom?: number; center?: { lat: number; lng: number }; landmarks?: boolean }
): Promise<JeeblyMapHandle> {
  const ml = await import("maplibre-gl");
  const map = new ml.Map({
    container,
    style: basemapStyle() as any,
    center: [opts?.center?.lng ?? HADITHA_CENTER.lng, opts?.center?.lat ?? HADITHA_CENTER.lat],
    zoom: opts?.zoom ?? 14,
    attributionControl: false,
    // منع أي تجاوز للعناصر: التفاعل داخل حاويتها فقط
    interactive: true,
    maxPitch: 0,
  });

  // منع التكبير بالتمرير المزدوج العشوائي داخل الصفحات — تجربة جوال أفضل
  map.touchZoomRotate.disableRotation();

  await new Promise<void>((resolve) => {
    if (map.loaded()) return resolve();
    map.on("load", () => resolve());
    // أمان: لا نعلّق الواجهة إن تأخر التحميل
    setTimeout(() => resolve(), 4000);
  });

  // إضافة معالم حديثة كعلامات DOM (فوق البلاطات، بدون أي بلاطات POI خارجية)
  if (opts?.landmarks !== false) {
    for (const lm of HADITHA_LANDMARKS) {
      new ml.Marker({ element: landmarkEl(lm.emoji, lm.label), anchor: "center" })
        .setLngLat([lm.lng, lm.lat])
        .addTo(map);
    }
  }

  return {
    map,
    ml,
    destroy: () => {
      map.remove();
    },
  };
}

// ===== خط الطريق بين المتجر والعميل =====

/** تهيئة طبقة الخط مرة واحدة */
export function ensureRouteLine(map: MlMap): void {
  if (map.getSource("jb-route")) return;
  map.addSource("jb-route", {
    type: "geojson",
    data: { type: "Feature", properties: {}, geometry: { type: "LineString", coordinates: [] } },
  });
  // إطار أبيض تحت الخط
  map.addLayer({
    id: "jb-route-casing",
    type: "line",
    source: "jb-route",
    layout: { "line-cap": "round", "line-join": "round" },
    paint: { "line-color": "#ffffff", "line-width": 6, "line-opacity": 0.9 },
  });
  map.addLayer({
    id: "jb-route-line",
    type: "line",
    source: "jb-route",
    layout: { "line-cap": "round", "line-join": "round" },
    paint: {
      "line-color": "#FF6B00",
      "line-width": 3.5,
      "line-dasharray": [1.5, 1.5],
      "line-opacity": 0.85,
    },
  });
}

/** تحديث خط الطريق بين نقطتين */
export function setRouteLine(
  map: MlMap,
  a: { lat: number; lng: number },
  b: { lat: number; lng: number }
): void {
  const src = map.getSource("jb-route") as maplibregl.GeoJSONSource | undefined;
  if (!src) return;
  src.setData({
    type: "Feature",
    properties: {},
    geometry: {
      type: "LineString",
      coordinates: [
        [a.lng, a.lat],
        [b.lng, b.lat],
      ],
    },
  });
}
