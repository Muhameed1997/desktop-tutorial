"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Search,
  PackageSearch,
  Bike,
  Store,
  CheckCircle2,
  CircleX,
  MapPin,
  Navigation,
  Clock,
  Phone,
  ReceiptText,
  PartyPopper,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { formatIQD, formatDate } from "@/lib/format";
import { HADITHA_CENTER } from "@/lib/geo";
import { ORDER_FLOW, ORDER_STATUS_AR, VEHICLE_AR, type AgentVehicle, type Order, type OrderStatus } from "@/lib/types";
import { useAppStore } from "@/store/app-store";
import HadithaMap, { type MapPoint } from "@/components/toters/haditha-map";

const STATUS_STEPS: { key: OrderStatus; label: string; icon: React.ReactNode }[] = [
  { key: "PENDING", label: "بانتظار القبول", icon: <ReceiptText className="h-4 w-4" /> },
  { key: "CONFIRMED", label: "المطعم قبل الطلب", icon: <CheckCircle2 className="h-4 w-4" /> },
  { key: "PREPARING", label: "قيد التحضير", icon: <Store className="h-4 w-4" /> },
  { key: "DELIVERING", label: "الوكيل في الطريق إليك", icon: <Bike className="h-4 w-4" /> },
  { key: "DELIVERED", label: "تم التسليم ✅", icon: <CheckCircle2 className="h-4 w-4" /> },
];

interface TrackData {
  order: Order;
  driver: { lat: number; lng: number; progress: number } | null;
  etaRemaining: number | null;
  route: { from: MapPoint; to: MapPoint };
}

export function TrackView({ code }: { code: string }) {
  const [data, setData] = useState<TrackData | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchCode, setSearchCode] = useState(code);
  const setView = useAppStore((s) => s.setView);

  const load = useCallback(async (c: string) => {
    if (!c.trim()) return;
    try {
      const res = await fetch(`/api/track/${encodeURIComponent(c.trim())}`);
      const json = await res.json();
      setData(res.ok && json.order ? json : null);
    } catch {
      setData(null);
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    if (!code) return;
    let alive = true;
    const tick = async () => {
      if (!alive) return;
      await load(code);
    };
    tick();
    // تحديث مباشر كل 4 ثوانٍ (تتبع مباشر)
    const t = setInterval(tick, 4000);
    return () => {
      alive = false;
      clearInterval(t);
    };
  }, [code, load]);

  const order = data?.order;

  return (
    <div className="max-w-3xl mx-auto px-4 pb-32 pt-4">
      <button
        onClick={() => setView({ name: "home" })}
        className="flex items-center gap-1.5 text-sm font-bold text-muted-foreground hover:text-[#FF6B00] transition mb-3"
      >
        <ArrowRight className="h-4 w-4" /> رجوع
      </button>

      {/* بحث برقم الطلب */}
      <div className="bg-white rounded-2xl border border-border p-4 mb-4">
        <h1 className="font-black mb-3 flex items-center gap-2">
          <PackageSearch className="h-5 w-5 text-[#FF6B00]" /> تتبع طلبك مباشرة
        </h1>
        <div className="flex gap-2">
          <Input
            value={searchCode}
            onChange={(e) => setSearchCode(e.target.value)}
            placeholder="أدخل رقم الطلب مثل TT-123456"
            dir="ltr"
            className="bg-[#F8F9FA] text-left"
            onKeyDown={(e) => e.key === "Enter" && load(searchCode)}
          />
          <Button className="rounded-full bg-[#FF6B00] hover:bg-[#E85F00] px-5" onClick={() => load(searchCode)}>
            <Search className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {loading ? (
        <div className="space-y-3">
          <Skeleton className="h-40 rounded-2xl" />
          <Skeleton className="h-64 rounded-2xl" />
        </div>
      ) : !order ? (
        <div className="bg-white rounded-2xl p-10 text-center border border-dashed border-[#FFAA00]">
          <div className="text-4xl mb-2">🧭</div>
          <p className="font-bold">لم نجد هذا الطلب</p>
          <p className="text-sm text-muted-foreground mt-1">تأكد من رقم الطلب أو أنشئ طلباً جديداً</p>
        </div>
      ) : (
        <TrackContent data={data!} />
      )}
    </div>
  );
}

function TrackContent({ data }: { data: TrackData }) {
  const { order, driver, etaRemaining } = data;
  const statusIndex = ORDER_FLOW.indexOf(order.status);
  const isActive = ["PENDING", "CONFIRMED", "PREPARING", "DELIVERING"].includes(order.status);

  const storeLoc: MapPoint = useMemo(
    () => ({
      lat: (order.store as unknown as { lat?: number })?.lat ?? HADITHA_CENTER.lat,
      lng: (order.store as unknown as { lng?: number })?.lng ?? HADITHA_CENTER.lng,
    }),
    [order.store]
  );
  const dest: MapPoint = useMemo(
    () => ({ lat: order.destLat ?? HADITHA_CENTER.lat, lng: order.destLng ?? HADITHA_CENTER.lng }),
    [order.destLat, order.destLng]
  );

  return (
    <motion.div initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
      {/* شريط الحالة والوقت المتبقي */}
      <div className="bg-white rounded-2xl border border-border p-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div>
            <div className="font-black text-lg" dir="ltr">
              {order.code}
            </div>
            <div className="text-xs text-muted-foreground">
              {formatDate(order.createdAt)} · {order.store?.name}
            </div>
          </div>
          <Badge
            className={`border-0 ${
              order.status === "DELIVERED"
                ? "bg-[#2E7D32]"
                : order.status === "CANCELLED"
                  ? "bg-red-500"
                  : "bg-[#FFAA00] text-[#111827]"
            }`}
          >
            {ORDER_STATUS_AR[order.status as OrderStatus]}
          </Badge>
        </div>

        {order.status === "CANCELLED" ? (
          <div className="flex items-center gap-3 p-4 rounded-xl bg-red-50 text-red-600 mt-3">
            <CircleX className="h-8 w-8" />
            <div>
              <div className="font-bold">تم إلغاء هذا الطلب</div>
              {order.notes && <div className="text-xs">السبب: {order.notes}</div>}
            </div>
          </div>
        ) : (
          <>
            {/* مدة الوصول المتوقعة */}
            <div className="mt-3 rounded-2xl p-4 toters-gradient text-white relative overflow-hidden">
              {order.status === "DELIVERED" ? (
                <div className="flex items-center gap-3">
                  <PartyPopper className="h-9 w-9" />
                  <div>
                    <div className="font-black text-lg">تم تسليم طلبك 🎉</div>
                    <div className="text-xs text-white/85">نتمنى لك وجبة شهية — لا تنسَ تقييم المطعم</div>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex items-center gap-3">
                    <span className="h-12 w-12 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center shrink-0">
                      {order.status === "DELIVERING" ? (
                        <Navigation className="h-6 w-6 animate-pulse" />
                      ) : (
                        <Clock className="h-6 w-6" />
                      )}
                    </span>
                    <div className="flex-1">
                      <div className="font-black text-xl leading-tight">
                        {order.status === "DELIVERING"
                          ? etaRemaining === 0
                            ? "يصلك الآن!"
                            : `يصل خلال ~${etaRemaining ?? "—"} دقيقة`
                          : order.status === "PREPARING"
                            ? "طلبك قيد التحضير الآن 👨‍🍳"
                            : order.status === "CONFIRMED"
                              ? "تم قبول طلبك من المتجر ✅"
                              : "جاري إرسال طلبك للمتجر..."}
                      </div>
                      <div className="text-xs text-white/85 mt-0.5">
                        {order.status === "DELIVERING"
                          ? "السائق في الطريق إليك — تابعه على الخريطة"
                          : "سنتابع طلبك وأصلك في أقرب وقت"}
                      </div>
                    </div>
                    {driver && order.status === "DELIVERING" && (
                      <div className="text-center shrink-0">
                        <div className="text-2xl font-black">{driver.progress}%</div>
                        <div className="text-[10px] text-white/80">المسافة المقطوعة</div>
                      </div>
                    )}
                  </div>
                  {/* شريط التقدم */}
                  <div className="mt-3 h-2 rounded-full bg-white/25 overflow-hidden">
                    <motion.div
                      className="h-full rounded-full bg-white"
                      animate={{ width: `${driver?.progress ?? (statusIndex / 4) * 25}%` }}
                      transition={{ duration: 1.2, ease: "easeOut" }}
                    />
                  </div>
                </>
              )}
            </div>

            {/* خريطة حديثة — السائق والعميل مباشرة */}
            {(isActive || order.status === "DELIVERED") && (
              <div className="mt-3 rounded-2xl overflow-hidden border border-border relative">
                <HadithaMap
                  storeLoc={storeLoc}
                  dest={dest}
                  driver={driver}
                  vehicle={order.agent?.vehicleType}
                  className="h-72 w-full"
                  fitKey={`${order.code}-${order.status}`}
                />
                <div className="absolute top-2 start-2 flex flex-col gap-1.5 pointer-events-none">
                  <span className="bg-white/95 backdrop-blur text-[10px] font-black px-2.5 py-1.5 rounded-full shadow flex items-center gap-1">
                    🍽️ المتجر — {order.store?.name}
                  </span>
                  <span className="bg-white/95 backdrop-blur text-[10px] font-black px-2.5 py-1.5 rounded-full shadow flex items-center gap-1">
                    🏠 أنت — {order.address}
                  </span>
                  {driver && (
                    <span className="bg-[#FF6B00] text-white text-[10px] font-black px-2.5 py-1.5 rounded-full shadow flex items-center gap-1 soft-blink">
                      🛵 السائق متحرك الآن
                    </span>
                  )}
                </div>
              </div>
            )}

            {/* مراحل الطلب */}
            <ol className="relative border-s-2 border-dashed border-[#FFAA00] ms-3 space-y-4 py-2 mt-4">
              {STATUS_STEPS.map((step, i) => {
                const done = i <= statusIndex;
                const current = i === statusIndex;
                return (
                  <li key={step.key} className="ms-5 flex items-center gap-3">
                    <span
                      className={`absolute -start-[13px] h-6 w-6 rounded-full flex items-center justify-center border-2 ${
                        done ? "bg-[#FF6B00] border-[#FFD9B3] text-white" : "bg-white border-[#FFAA00] text-[#FFAA00]"
                      } ${current ? "animate-pulse" : ""}`}
                    >
                      {step.icon}
                    </span>
                    <div>
                      <div className={`text-sm font-bold ${done ? "text-foreground" : "text-muted-foreground"}`}>
                        {step.label}
                      </div>
                      {current && <div className="text-[11px] text-[#FF6B00]">المرحلة الحالية</div>}
                    </div>
                  </li>
                );
              })}
            </ol>
          </>
        )}

        {/* الوكيل المسند */}
        {order.agent && (
          <div className="mt-3 rounded-xl warm-gradient p-3.5 flex items-center gap-3">
            <span className="h-11 w-11 rounded-full bg-white flex items-center justify-center text-xl shrink-0">
              {order.agent.vehicleType === "CAR" ? "🚗" : "🛵"}
            </span>
            <div className="flex-1 min-w-0">
              <div className="font-black text-sm text-[#111827]">
                {order.agent.name} — {VEHICLE_AR[order.agent.vehicleType as AgentVehicle] || "وكيل"}
              </div>
              <div className="text-xs text-[#111827]/70">وكيل التوصيل الخاص بطلبك داخل حديثة</div>
            </div>
            <a
              href={`tel:${order.agent.phone}`}
              className="bg-[#FF6B00] text-white text-xs font-bold px-3.5 py-2 rounded-full hover:bg-[#E85F00] transition flex items-center gap-1.5"
            >
              <Phone className="h-3.5 w-3.5" /> اتصال
            </a>
          </div>
        )}
      </div>

      {/* تفاصيل */}
      <div className="bg-white rounded-2xl border border-border p-4 text-sm">
        <h3 className="font-black mb-2.5">تفاصيل الطلب</h3>
        <div className="space-y-1.5">
          {order.items.map((it) => (
            <div key={it.id} className="flex justify-between text-muted-foreground">
              <span>
                {it.name} × {it.quantity}
              </span>
              <span>{formatIQD(it.price * it.quantity)}</span>
            </div>
          ))}
          <div className="flex justify-between text-muted-foreground">
            <span>التوصيل</span>
            <span>{order.deliveryFee === 0 ? "مجاني" : formatIQD(order.deliveryFee)}</span>
          </div>
          <div className="flex justify-between font-black text-foreground pt-1.5 border-t border-dashed">
            <span>المجموع ({order.paymentMethod === "CASH" ? "نقداً" : "بطاقة"})</span>
            <span className="text-[#FF6B00]">{formatIQD(order.total)}</span>
          </div>
        </div>
        <div className="mt-3 pt-3 border-t flex items-start gap-2 text-muted-foreground">
          <MapPin className="h-4 w-4 shrink-0 text-[#FF6B00] mt-0.5" />
          <div>
            <div className="font-bold text-foreground text-xs">
              {order.customerName} — <span dir="ltr">{order.customerPhone}</span>
            </div>
            <div className="text-xs">{order.address}</div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

// تتبع طلب برقمه (للزوار غير المسجلين)
export function MyOrdersView() {
  const [code, setCode] = useState("");
  const [found, setFound] = useState<string | null>(null);
  const setView = useAppStore((s) => s.setView);
  const [loading, setLoading] = useState(false);

  async function find() {
    if (!code.trim()) return;
    setLoading(true);
    const res = await fetch(`/api/orders?code=${encodeURIComponent(code.trim())}`);
    const all: Order[] = await res.json();
    setLoading(false);
    if (Array.isArray(all) && all.length > 0) {
      setFound(all[0].code);
      setView({ name: "track", code: all[0].code });
    } else {
      setFound("");
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-4 pb-32 pt-4">
      <button
        onClick={() => setView({ name: "home" })}
        className="flex items-center gap-1.5 text-sm font-bold text-muted-foreground hover:text-[#FF6B00] transition mb-3"
      >
        <ArrowRight className="h-4 w-4" /> رجوع
      </button>
      <div className="bg-white rounded-2xl border border-border p-4 mb-4">
        <h1 className="font-black mb-1">تتبع طلب برقمه</h1>
        <p className="text-xs text-muted-foreground mb-3">
          أدخل رقم الطلب (مثل TT-100002) لمشاهدة السائق مباشرة على خريطة حديثة — أو سجّل الدخول لعرض كل طلباتك من
          صفحة حسابك
        </p>
        <div className="flex gap-2">
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="TT-XXXXXX"
            dir="ltr"
            className="bg-[#F8F9FA] text-left"
            onKeyDown={(e) => e.key === "Enter" && find()}
          />
          <Button className="rounded-full bg-[#FF6B00] hover:bg-[#E85F00] px-5 shrink-0" onClick={find} disabled={loading}>
            <Search className="h-4 w-4" />
          </Button>
        </div>
        {found === "" && <p className="text-xs text-red-500 mt-2">لم نجد طلباً بهذا الرقم</p>}
      </div>
    </div>
  );
}
