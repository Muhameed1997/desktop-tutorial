"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { ClipboardList, RefreshCw, UserPlus, Bike, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { toast } from "@/hooks/use-toast";
import { formatIQD, formatDate } from "@/lib/format";
import { ORDER_STATUS_AR, TYPE_AR, VEHICLE_AR, type Agent, type AgentVehicle, type Order, type OrderStatus, type StoreType } from "@/lib/types";
import { STATUS_COLORS } from "./admin-panel";

// انتقالات الحالة المسموحة لكل حالة
const NEXT_STATUS: Partial<Record<OrderStatus, { to: OrderStatus; label: string }[]>> = {
  PENDING: [
    { to: "CONFIRMED", label: "قبول الطلب" },
    { to: "CANCELLED", label: "إلغاء" },
  ],
  CONFIRMED: [
    { to: "PREPARING", label: "بدء التحضير" },
    { to: "CANCELLED", label: "إلغاء" },
  ],
  PREPARING: [{ to: "DELIVERING", label: "خرج للتوصيل" }],
  DELIVERING: [{ to: "DELIVERED", label: "تم التسليم ✅" }],
  DELIVERED: [],
  CANCELLED: [],
};

const FILTERS: { key: "ACTIVE" | "ALL" | OrderStatus; label: string }[] = [
  { key: "ACTIVE", label: "النشطة" },
  { key: "PENDING", label: "جديدة" },
  { key: "DELIVERING", label: "قيد التوصيل" },
  { key: "DELIVERED", label: "مكتملة" },
  { key: "CANCELLED", label: "ملغية" },
  { key: "ALL", label: "الكل" },
];

export function AdminOrdersTab() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<"ACTIVE" | "ALL" | OrderStatus>("ACTIVE");

  const load = useCallback(() => {
    setLoading(true);
    Promise.all([fetch("/api/orders").then((r) => r.json()), fetch("/api/agents").then((r) => r.json())])
      .then(([o, a]) => {
        setOrders(Array.isArray(o) ? o : []);
        setAgents(Array.isArray(a) ? a : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    let cancel = false;
    const run = () => {
      Promise.all([fetch("/api/orders").then((r) => r.json()), fetch("/api/agents").then((r) => r.json())])
        .then(([o, a]) => {
          if (cancel) return;
          setOrders(Array.isArray(o) ? o : []);
          setAgents(Array.isArray(a) ? a : []);
          setLoading(false);
        })
        .catch(() => {
          if (!cancel) setLoading(false);
        });
    };
    run();
    const t = setInterval(run, 20000); // تحديث تلقائي
    return () => {
      cancel = true;
      clearInterval(t);
    };
  }, []);

  const filtered = useMemo(() => {
    if (filter === "ALL") return orders;
    if (filter === "ACTIVE") return orders.filter((o) => ["PENDING", "CONFIRMED", "PREPARING", "DELIVERING"].includes(o.status));
    return orders.filter((o) => o.status === filter);
  }, [orders, filter]);

  async function updateStatus(order: Order, status: OrderStatus) {
    const res = await fetch(`/api/orders/${order.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status, cancelReason: status === "CANCELLED" ? "أُلغي من إدارة المتجر" : undefined }),
    });
    if (res.ok) {
      toast({ title: `الطلب ${order.code}: ${ORDER_STATUS_AR[status]}` });
      load();
    } else {
      toast({ title: "تعذر تحديث الطلب", variant: "destructive" });
    }
  }

  async function assignAgent(order: Order, agentId: string | null) {
    const res = await fetch(`/api/orders/${order.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ agentId }),
    });
    if (res.ok) {
      const agent = agents.find((a) => a.id === agentId);
      toast({ title: agentId ? `أُسند الطلب إلى ${agent?.name} ${agent?.vehicleType === "CAR" ? "🚗" : "🛵"}` : "أُلغي إسناد الطلب" });
      load();
    } else {
      toast({ title: "تعذر إسناد الوكيل", variant: "destructive" });
    }
  }

  return (
    <div className="space-y-4">
      {/* الفلاتر */}
      <div className="flex items-center gap-2 flex-wrap">
        <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
          {FILTERS.map((f) => (
            <button
              key={f.key}
              onClick={() => setFilter(f.key)}
              className={`px-3.5 py-2 rounded-full text-xs font-bold whitespace-nowrap border transition ${filter === f.key ? "bg-[#FF6B00] text-white border-transparent" : "bg-white border-border hover:border-[#FFAA00]"}`}
            >
              {f.label}
            </button>
          ))}
        </div>
        <Button variant="outline" size="sm" className="rounded-full h-8 ms-auto" onClick={load}>
          <RefreshCw className="h-3.5 w-3.5 me-1.5" /> تحديث
        </Button>
      </div>

      {loading ? (
        <p className="text-center text-sm text-muted-foreground py-10">جاري تحميل الطلبات...</p>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 text-center border border-dashed border-[#FFAA00]">
          <ClipboardList className="h-10 w-10 mx-auto text-[#FFAA00] mb-2" />
          <p className="font-bold">لا توجد طلبات في هذا التصنيف</p>
          <p className="text-sm text-muted-foreground mt-1">الطلبات الجديدة من العملاء ستظهر هنا مباشرة</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map((o) => {
            const activeAgent = agents.find((a) => a.id === o.agentId);
            const assignable = agents.filter((a) => a.status !== "OFFLINE" && a.id !== o.agentId);
            return (
              <Collapsible key={o.id} className="bg-white rounded-2xl border border-border overflow-hidden">
                <div className="p-3.5 flex items-center gap-3 flex-wrap">
                  <span className="h-11 w-11 rounded-xl bg-[#F8F9FA] flex items-center justify-center text-xl shrink-0">
                    {o.store?.type === "MARKET" ? "🛒" : o.store?.type === "STORE" ? "🏬" : "🍽️"}
                  </span>
                  <div className="flex-1 min-w-40">
                    <div className="font-black text-sm">
                      {o.store?.name}
                      <span className="text-muted-foreground font-medium text-xs ms-1.5" dir="ltr">{o.code}</span>
                    </div>
                    <div className="text-[11px] text-muted-foreground">
                      {formatDate(o.createdAt)} · {o.customerName} · <span dir="ltr">{o.customerPhone}</span>
                    </div>
                  </div>
                  <div className="text-left">
                    <Badge className={`border-0 text-[10px] ${STATUS_COLORS[o.status as OrderStatus]}`}>
                      {ORDER_STATUS_AR[o.status as OrderStatus]}
                    </Badge>
                    <div className="font-black text-sm mt-1">{formatIQD(o.total)}</div>
                  </div>
                  <CollapsibleTrigger className="flex items-center gap-1 text-xs font-bold text-[#FF6B00] hover:underline ms-auto">
                    تفاصيل وإدارة <ChevronDown className="h-4 w-4" />
                  </CollapsibleTrigger>
                </div>

                <CollapsibleContent>
                  <div className="border-t bg-[#F8F9FA] p-3.5 space-y-3">
                    {/* الأصناف */}
                    <div className="text-sm space-y-1">
                      {o.items.map((it) => (
                        <div key={it.id} className="flex justify-between text-muted-foreground">
                          <span>{it.name} × {it.quantity}</span>
                          <span>{formatIQD(it.price * it.quantity)}</span>
                        </div>
                      ))}
                      <div className="flex justify-between text-muted-foreground pt-1">
                        <span>أجرة التوصيل ({TYPE_AR[o.store?.type as StoreType] || ""})</span>
                        <span>{o.deliveryFee === 0 ? "مجاني" : formatIQD(o.deliveryFee)}</span>
                      </div>
                      <div className="flex justify-between font-bold text-foreground">
                        <span>الدفع: {o.paymentMethod === "CASH" ? "نقداً 💵" : "بطاقة 💳"}</span>
                        <span>المجموع: {formatIQD(o.total)}</span>
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground flex items-start gap-1.5">
                      📍 {o.address}
                      {o.notes && <span className="text-[#FF6B00]">· 📝 {o.notes}</span>}
                    </div>

                    {/* إسناد الوكيل */}
                    <div className="flex items-center gap-2 flex-wrap bg-white rounded-xl border p-2.5">
                      <span className="text-xs font-bold flex items-center gap-1">
                        <Bike className="h-4 w-4 text-[#FFAA00]" /> وكيل التوصيل:
                      </span>
                      {o.status === "CANCELLED" ? (
                        <span className="text-xs text-muted-foreground">الطلب ملغي — لا يمكن الإسناد</span>
                      ) : activeAgent ? (
                        <>
                          <Badge className="bg-[#FFF6DE] text-[#111827] border-0">
                            {activeAgent.vehicleType === "CAR" ? "🚗" : "🛵"} {activeAgent.name} ({VEHICLE_AR[activeAgent.vehicleType as AgentVehicle]})
                          </Badge>
                          <Button size="sm" variant="outline" className="h-7 rounded-full text-[11px]" onClick={() => assignAgent(o, null)}>
                            إلغاء الإسناد
                          </Button>
                        </>
                      ) : (
                        <Select onValueChange={(v) => assignAgent(o, v)}>
                          <SelectTrigger className="w-52 h-8 rounded-full text-xs bg-[#F8F9FA]">
                            <SelectValue placeholder={<span className="flex items-center gap-1"><UserPlus className="h-3.5 w-3.5" /> اختر وكيل للإسناد</span>} />
                          </SelectTrigger>
                          <SelectContent>
                            {assignable.length === 0 ? (
                              <div className="p-3 text-xs text-muted-foreground text-center">لا يوجد وكلاء متاحون — أضف وكلاء أولاً</div>
                            ) : (
                              assignable.map((a) => (
                                <SelectItem key={a.id} value={a.id}>
                                  {a.vehicleType === "CAR" ? "🚗" : "🛵"} {a.name} — {a.status === "AVAILABLE" ? "متاح" : "مشغول"}
                                </SelectItem>
                              ))
                            )}
                          </SelectContent>
                        </Select>
                      )}
                    </div>

                    {/* انتقالات الحالة */}
                    {(NEXT_STATUS[o.status as OrderStatus]?.length || 0) > 0 && (
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="text-xs font-bold">تغيير الحالة:</span>
                        {NEXT_STATUS[o.status as OrderStatus]!.map((ns) => (
                          <Button
                            key={ns.to}
                            size="sm"
                            className={`h-8 rounded-full text-xs font-bold ${ns.to === "CANCELLED" ? "bg-red-500 hover:bg-red-600" : "bg-[#FF6B00] hover:bg-[#E85F00]"}`}
                            onClick={() => updateStatus(o, ns.to)}
                          >
                            {ns.label}
                          </Button>
                        ))}
                      </div>
                    )}
                  </div>
                </CollapsibleContent>
              </Collapsible>
            );
          })}
        </div>
      )}
    </div>
  );
}
