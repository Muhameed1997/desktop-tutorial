"use client";

// خريطة مدينة حديثة – الأنبار مع تتبع مباشر: السائق + العميل + المتجر
// محرك جيبلي الموحد (MapLibre) — خريطة غنية بمعالم حديثة (مدارس، مشفى، دوار، منازل)
// بدون أي مطاعم خارجية — فقط علامات جيبلي
import { useEffect, useRef, useState } from "react";
import type { Marker as MlMarker } from "maplibre-gl";
import { HADITHA_CENTER } from "@/lib/geo";
import {
  createJeeblyMap,
  ensureRouteLine,
  markerEl,
  setRouteLine,
  type JeeblyMapHandle,
} from "./jeebly-basemap";

export interface MapPoint {
  lat: number;
  lng: number;
}

interface HadithaMapProps {
  /** موقع المتجر (نقطة الانطلاق) */
  storeLoc: MapPoint;
  /** موقع العميل (نقطة الوصول) */
  dest: MapPoint;
  /** الموقع الحالي للسائق (يتحدث لحظياً) */
  driver?: MapPoint | null;
  /** نوع مركبة السائق */
  vehicle?: "CAR" | "MOTORCYCLE" | string | null;
  /** إظهار منتجع الخريطة عند تغيّر النقاط */
  fitKey?: string;
  /** قابل للنقر لتحديد موقع (منتقي العنوان) */
  pickMode?: boolean;
  onPick?: (p: MapPoint) => void;
  className?: string;
}

/** حركة ناعمة للعلامة بين نقطتين (بدون CSS transition حتى لا تتخلف عن تحريك الخريطة) */
function animateMarker(mk: MlMarker, from: MapPoint, to: MapPoint, ms: number) {
  const anyMk = mk as unknown as { _jbRaf?: number };
  if (anyMk._jbRaf) cancelAnimationFrame(anyMk._jbRaf);
  const start = performance.now();
  const step = (now: number) => {
    const t = Math.min(1, (now - start) / ms);
    mk.setLngLat([from.lng + (to.lng - from.lng) * t, from.lat + (to.lat - from.lat) * t]);
    if (t < 1) anyMk._jbRaf = requestAnimationFrame(step);
  };
  anyMk._jbRaf = requestAnimationFrame(step);
}

export default function HadithaMap({
  storeLoc,
  dest,
  driver,
  vehicle,
  fitKey,
  pickMode,
  onPick,
  className,
}: HadithaMapProps) {
  const mapRef = useRef<HTMLDivElement | null>(null);
  const handle = useRef<JeeblyMapHandle | null>(null);
  const [ready, setReady] = useState(false);
  const markers = useRef<{
    store?: MlMarker;
    dest?: MlMarker;
    driver?: MlMarker;
    pick?: MlMarker;
  }>({});
  const driverPos = useRef<MapPoint | null>(null);
  const pickRef = useRef(onPick);
  const pickModeRef = useRef(pickMode);
  useEffect(() => {
    pickRef.current = onPick;
    pickModeRef.current = pickMode;
  }, [onPick, pickMode]);

  // تهيئة الخريطة مرة واحدة
  useEffect(() => {
    let disposed = false;
    let local: JeeblyMapHandle | null = null;
    (async () => {
      if (!mapRef.current) return;
      const h = await createJeeblyMap(mapRef.current, { zoom: 14 });
      if (disposed) {
        h.destroy();
        return;
      }
      local = h;
      handle.current = h;

      // وضع تحديد الموقع: النقر على الخريطة يحدد منزلك
      h.map.on("click", (e) => {
        if (pickModeRef.current) {
          pickRef.current?.({ lat: e.lngLat.lat, lng: e.lngLat.lng });
        }
      });

      setReady(true);
    })();
    return () => {
      disposed = true;
      local?.destroy();
      handle.current = null;
      markers.current = {};
      driverPos.current = null;
      setReady(false);
    };
  }, []);

  // ===== علامات المتجر والعميل + خط الطريق =====
  useEffect(() => {
    const h = handle.current;
    if (!ready || !h) return;
    const { map, ml } = h;

    if (!markers.current.store) {
      markers.current.store = new ml.Marker({
        element: markerEl(`<div class="map-pin map-pin-store">🍽️</div>`),
        anchor: "center",
      })
        .setLngLat([storeLoc.lng, storeLoc.lat])
        .addTo(map);
      markers.current.store.getElement().title = "موقع المتجر";
    } else {
      markers.current.store.setLngLat([storeLoc.lng, storeLoc.lat]);
    }

    if (!markers.current.dest) {
      markers.current.dest = new ml.Marker({
        element: markerEl(`<div class="map-pin map-pin-dest">🏠</div>`),
        anchor: "center",
      })
        .setLngLat([dest.lng, dest.lat])
        .addTo(map);
      markers.current.dest.getElement().title = "موقعك";
    } else {
      markers.current.dest.setLngLat([dest.lng, dest.lat]);
    }

    // خط الطريق بين المتجر والعميل
    ensureRouteLine(map);
    setRouteLine(map, storeLoc, dest);

    // ملاءمة الإطار على النقطتين
    const sw: [number, number] = [Math.min(storeLoc.lng, dest.lng), Math.min(storeLoc.lat, dest.lat)];
    const ne: [number, number] = [Math.max(storeLoc.lng, dest.lng), Math.max(storeLoc.lat, dest.lat)];
    map.fitBounds([sw, ne], {
      padding: { top: 70, bottom: 80, left: 60, right: 60 },
      maxZoom: 15.5,
      duration: 800,
    });
  }, [ready, storeLoc.lat, storeLoc.lng, dest.lat, dest.lng, fitKey]);

  // ===== علامة السائق المتحركة =====
  useEffect(() => {
    const h = handle.current;
    if (!ready || !h) return;
    const { map, ml } = h;
    const emoji = vehicle === "CAR" ? "🚗" : "🛵";

    if (!driver) {
      markers.current.driver?.remove();
      markers.current.driver = undefined;
      driverPos.current = null;
      return;
    }

    if (!markers.current.driver) {
      const mk = new ml.Marker({
        element: markerEl(
          `<div class="map-pin map-pin-driver"><span class="map-pin-pulse"></span><span>${emoji}</span></div>`
        ),
        anchor: "center",
        zIndex: 1000,
      })
        .setLngLat([driver.lng, driver.lat])
        .addTo(map);
      mk.getElement().title = "السائق (الكابتن)";
      markers.current.driver = mk;
      driverPos.current = { lat: driver.lat, lng: driver.lng };
    } else {
      // حركة ناعمة من الموقع السابق إلى الجديد
      const from = driverPos.current ?? { lat: driver.lat, lng: driver.lng };
      const to = { lat: driver.lat, lng: driver.lng };
      animateMarker(markers.current.driver, from, to, 1700);
      driverPos.current = to;
    }
  }, [ready, driver?.lat, driver?.lng, vehicle]);

  // ===== وضع منتقي الموقع (علامة 📍 فوق موقعك) =====
  useEffect(() => {
    const h = handle.current;
    if (!ready || !h || !pickMode) return;
    const { map, ml } = h;
    if (!markers.current.pick) {
      markers.current.pick = new ml.Marker({
        element: markerEl(`<div class="map-pin map-pin-dest">📍</div>`),
        anchor: "center",
        zIndex: 900,
      })
        .setLngLat([dest.lng, dest.lat])
        .addTo(map);
    } else {
      markers.current.pick.setLngLat([dest.lng, dest.lat]);
    }
  }, [ready, pickMode, dest.lat, dest.lng]);

  return (
    <div
      ref={mapRef}
      className={className}
      style={{ minHeight: 280 }}
      aria-label="خريطة مدينة حديثة — جيبلي"
    />
  );
}
