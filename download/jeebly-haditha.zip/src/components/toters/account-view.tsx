"use client";

// واجهة الحساب: تسجيل برقم الهاتف فقط عبر رمز التحقق OTP (بدون كلمة مرور) + الملف الشخصي وطلباتي
import { useEffect, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import Image from "next/image";
import {
  ArrowRight,
  Bike,
  Car,
  CheckCircle2,
  Loader2,
  LogOut,
  Mail,
  MapPin,
  MessageSquareText,
  Pencil,
  Phone,
  Receipt,
  Search,
  ShieldCheck,
  Smartphone,
  LocateFixed,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { useToast } from "@/hooks/use-toast";
import { formatIQD, formatDate } from "@/lib/format";
import { formatPhoneDisplay, IQ_DIAL_CODE } from "@/lib/phone";
import { ORDER_STATUS_AR, type Order, type OrderStatus } from "@/lib/types";
import { useAppStore } from "@/store/app-store";
import { useAuthStore } from "@/store/auth-store";

export function AccountView() {
  const user = useAuthStore((s) => s.user);
  const sync = useAuthStore((s) => s.sync);
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    sync().finally(() => setChecking(false));
  }, [sync]);

  if (checking) {
    return (
      <div className="max-w-md mx-auto px-4 pb-40 pt-8 space-y-4">
        <Skeleton className="h-28 rounded-3xl" />
        <Skeleton className="h-40 rounded-2xl" />
      </div>
    );
  }

  return user ? <ProfileCard /> : <AuthForms />;
}

// ===== التسجيل برقم الهاتف فقط — رمز تحقق يصل إلى الهاتف، بدون كلمة مرور =====
function AuthForms() {
  const setUser = useAuthStore((s) => s.setUser);
  const setView = useAppStore((s) => s.setView);
  const { toast } = useToast();

  const [step, setStep] = useState<"phone" | "code">("phone");
  const [phone, setPhone] = useState("");
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [isNewUser, setIsNewUser] = useState(false);
  const [devCode, setDevCode] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const [resendIn, setResendIn] = useState(0);

  // عداد إعادة إرسال الرمز (45 ثانية)
  useEffect(() => {
    if (resendIn <= 0) return;
    const t = setTimeout(() => setResendIn((s) => s - 1), 1000);
    return () => clearTimeout(t);
  }, [resendIn]);

  async function sendCode() {
    if (!phone.trim()) {
      toast({ title: "أدخل رقم هاتفك أولاً", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/auth/otp/send", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "تعذر إرسال الرمز", description: data.error, variant: "destructive" });
        setBusy(false);
        return;
      }
      setIsNewUser(Boolean(data.isNewUser));
      setDevCode(data.devCode || null);
      setResendIn(45);
      setCode("");
      setStep("code");
      toast({
        title: "تم إرسال رمز التحقق 📲",
        description: `أدخل الرمز المرسل إلى ${formatPhoneDisplay(data.phone)}`,
      });
    } catch {
      toast({ title: "خطأ بالشبكة", variant: "destructive" });
    }
    setBusy(false);
  }

  async function verifyCode() {
    if (code.length !== 6) {
      toast({ title: "أدخل الرمز المكوّن من 6 أرقام", variant: "destructive" });
      return;
    }
    setBusy(true);
    try {
      const res = await fetch("/api/auth/otp/verify", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ phone, code, name }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "تعذر التحقق", description: data.error, variant: "destructive" });
        setBusy(false);
        return;
      }
      setUser(data);
      toast({
        title: data.isNewUser ? `تم إنشاء حسابك — أهلاً ${data.name}! 🎉` : `أهلاً بعودتك ${data.name} 👋`,
        description: "دخلت بنجاح — تصفح واطلب بحرية",
      });
    } catch {
      toast({ title: "خطأ بالشبكة", variant: "destructive" });
    }
    setBusy(false);
  }

  return (
    <div className="max-w-md mx-auto px-4 pb-40 pt-4">
      <button
        onClick={() => setView({ name: "home" })}
        className="flex items-center gap-1.5 text-sm font-bold text-muted-foreground hover:text-[#FF6B00] transition mb-3"
      >
        <ArrowRight className="h-4 w-4" /> رجوع
      </button>

      <motion.div initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.35 }}>
        <div className="brand-gradient rounded-3xl p-6 text-center text-white mb-4 overflow-hidden relative shadow-brand">
          <div className="absolute -top-6 -start-6 h-24 w-24 rounded-full bg-white/10" />
          <div className="absolute -bottom-8 -end-4 h-24 w-24 rounded-full bg-white/10" />
          <Image
            src="/brand/jeebly-icon.png"
            alt="جيبلي Jeebly"
            width={64}
            height={64}
            className="h-16 w-16 rounded-2xl mx-auto mb-2.5 shadow-lg ring-2 ring-white/40"
          />
          <h1 className="text-xl font-black">أهلاً بك في جيبلي Jeebly</h1>
          <p className="text-sm text-white/90 mt-1">
            سجّل برقم هاتفك العراقي فقط — نرسل لك رمز تحقق، <span className="font-black">بدون كلمة مرور</span>
          </p>
        </div>

        <div className="bg-white rounded-2xl border border-border p-4">
          <AnimatePresence mode="wait">
            {step === "phone" ? (
              <motion.div
                key="phone"
                initial={{ opacity: 0, x: 16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -16 }}
                transition={{ duration: 0.2 }}
                className="space-y-3.5"
              >
                <div className="flex items-center gap-2 text-sm font-black text-[#111827]">
                  <Smartphone className="h-4.5 w-4.5 text-[#FF6B00]" />
                  ما رقم هاتفك؟
                </div>

                {/* الرقم العراقي بدون مفتاح الدولة — +964 مضاف تلقائياً */}
                <div className="space-y-1.5">
                  <Label htmlFor="otp-phone">رقم الهاتف العراقي</Label>
                  <div className="flex" dir="ltr">
                    <span className="inline-flex items-center justify-center rounded-l-xl border border-r-0 border-input bg-[#F8F9FA] px-3 text-sm font-black text-[#111827] select-none">
                      {IQ_DIAL_CODE}
                    </span>
                    <Input
                      id="otp-phone"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="0770 123 4567"
                      dir="ltr"
                      inputMode="tel"
                      autoComplete="tel"
                      className="rounded-l-none rounded-r-xl text-left bg-white"
                      onKeyDown={(e) => e.key === "Enter" && sendCode()}
                    />
                  </div>
                  <p className="text-[11px] text-muted-foreground flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-[#2E7D32]" />
                    اكتب رقمك بدون مفتاح الدولة — يُضاف {IQ_DIAL_CODE} تلقائياً
                  </p>
                </div>

                {/* الاسم — للحساب الجديد فقط */}
                <div className="space-y-1.5">
                  <Label htmlFor="otp-name">الاسم (لإنشاء حساب جديد)</Label>
                  <Input
                    id="otp-name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="مثال: أحمد علي — يُطلب مرة واحدة فقط"
                    className="bg-[#F8F9FA]"
                  />
                </div>

                <Button
                  className="w-full rounded-full bg-[#FF6B00] hover:bg-[#E85F00] h-11 font-black"
                  onClick={sendCode}
                  disabled={busy}
                >
                  {busy ? <Loader2 className="h-4.5 w-4.5 animate-spin me-1.5" /> : <MessageSquareText className="h-4.5 w-4.5 me-1.5" />}
                  إرسال رمز التحقق
                </Button>
                <p className="text-[11px] text-center text-muted-foreground leading-relaxed">
                  بالمتابعة أنت توافق على شروط الاستخدام وسياسة الخصوصية
                </p>
              </motion.div>
            ) : (
              <motion.div
                key="code"
                initial={{ opacity: 0, x: -16 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: 16 }}
                transition={{ duration: 0.2 }}
                className="space-y-3.5"
              >
                <div className="flex items-center justify-between gap-2">
                  <div className="text-sm font-black text-[#111827] flex items-center gap-2">
                    <ShieldCheck className="h-4.5 w-4.5 text-[#2E7D32]" />
                    أدخل رمز التحقق
                  </div>
                  <button
                    onClick={() => setStep("phone")}
                    className="text-xs font-bold text-[#FF6B00] flex items-center gap-1 hover:underline"
                  >
                    <Pencil className="h-3 w-3" /> تعديل الرقم
                  </button>
                </div>

                <p className="text-xs text-muted-foreground">
                  أرسلنا رمزاً من 6 أرقام إلى{" "}
                  <span dir="ltr" className="font-black text-[#111827]">
                    {formatPhoneDisplay(phone)}
                  </span>
                  {isNewUser && " — سيُنشأ حسابك الجديد تلقائياً"}
                </p>

                <div className="flex justify-center py-1" dir="ltr">
                  <InputOTP maxLength={6} value={code} onChange={(v) => setCode(v.replace(/\D/g, ""))}>
                    <InputOTPGroup>
                      {[0, 1, 2, 3, 4, 5].map((i) => (
                        <InputOTPSlot key={i} index={i} className="h-12 w-11 text-lg font-black border-[#E5E7EB] first:rounded-r-xl last:rounded-l-xl data-[active=true]:border-[#FF6B00] data-[active=true]:ring-[#FF6B00]/25" />
                      ))}
                    </InputOTPGroup>
                  </InputOTP>
                </div>

                {/* كود التجربة — يُحذف عند ربط مزود SMS حقيقي */}
                {devCode && (
                  <div className="rounded-xl bg-[#FFF6DE] border border-[#FFAA00]/50 p-3 text-[11px] text-center text-[#111827]/85 leading-relaxed">
                    <span className="font-black">🔑 النسخة التجريبية — رمز التحقق: </span>
                    <span dir="ltr" className="font-black text-base text-[#FF6B00] tracking-widest">
                      {devCode}
                    </span>
                    <br />
                    عند ربط خدمة الرسائل القصيرة سيصل الرمز إلى هاتفك كرسالة نصية
                  </div>
                )}

                <Button
                  className="w-full rounded-full bg-[#FF6B00] hover:bg-[#E85F00] h-11 font-black"
                  onClick={verifyCode}
                  disabled={busy || code.length !== 6}
                >
                  {busy ? <Loader2 className="h-4.5 w-4.5 animate-spin me-1.5" /> : <CheckCircle2 className="h-4.5 w-4.5 me-1.5" />}
                  تحقق وادخل
                </Button>

                <div className="text-center text-xs text-muted-foreground">
                  لم يصلك الرمز؟{" "}
                  {resendIn > 0 ? (
                    <span className="font-bold">إعادة الإرسال بعد {resendIn} ثانية</span>
                  ) : (
                    <button onClick={sendCode} disabled={busy} className="font-black text-[#FF6B00] hover:underline">
                      إعادة إرسال الرمز
                    </button>
                  )}
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </motion.div>
    </div>
  );
}

// ===== الملف الشخصي + طلباتي =====
function ProfileCard() {
  const user = useAuthStore((s) => s.user)!;
  const logout = useAuthStore((s) => s.logout);
  const setView = useAppStore((s) => s.setView);
  const { toast } = useToast();

  const [orders, setOrders] = useState<Order[] | null>(null);
  const [searchCode, setSearchCode] = useState("");

  useEffect(() => {
    fetch("/api/orders?mine=1")
      .then((r) => r.json())
      .then((d) => setOrders(Array.isArray(d) ? d : []))
      .catch(() => setOrders([]));
  }, []);

  const shown = (orders || []).filter(
    (o) => !searchCode.trim() || o.code.toLowerCase().includes(searchCode.trim().toLowerCase())
  );
  const active = shown.filter((o) => ["PENDING", "CONFIRMED", "PREPARING", "DELIVERING"].includes(o.status));
  const past = shown.filter((o) => ["DELIVERED", "CANCELLED"].includes(o.status));

  return (
    <div className="max-w-2xl mx-auto px-4 pb-40 pt-4">
      <button
        onClick={() => setView({ name: "home" })}
        className="flex items-center gap-1.5 text-sm font-bold text-muted-foreground hover:text-[#FF6B00] transition mb-3"
      >
        <ArrowRight className="h-4 w-4" /> رجوع
      </button>

      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        className="brand-gradient rounded-3xl p-5 text-white flex items-center gap-4 relative overflow-hidden shadow-brand"
      >
        <div className="absolute -top-8 -start-8 h-28 w-28 rounded-full bg-white/10" />
        <span className="h-16 w-16 rounded-2xl bg-white/25 backdrop-blur flex items-center justify-center text-3xl font-black shrink-0">
          {user.name.trim().charAt(0)}
        </span>
        <div className="flex-1 min-w-0">
          <h1 className="text-xl font-black truncate">{user.name}</h1>
          <div className="text-sm text-white/90 flex flex-col" dir="ltr">
            {user.phone && (
              <span className="flex items-center gap-1.5 justify-end">
                <Phone className="h-3.5 w-3.5" /> {formatPhoneDisplay(user.phone)}
              </span>
            )}
            {user.email && (
              <span className="flex items-center gap-1.5 justify-end">
                <Mail className="h-3.5 w-3.5" /> {user.email}
              </span>
            )}
          </div>
          {user.address && (
            <div className="text-xs text-white/80 mt-1 flex items-center gap-1">
              <MapPin className="h-3 w-3" /> {user.address}
            </div>
          )}
        </div>
        <Button
          variant="outline"
          size="sm"
          className="rounded-full bg-white/15 border-white/40 text-white hover:bg-white/25 hover:text-white shrink-0"
          onClick={async () => {
            await logout();
            toast({ title: "تم تسجيل الخروج 👋" });
            setView({ name: "home" });
          }}
        >
          <LogOut className="h-3.5 w-3.5 me-1" /> خروج
        </Button>
      </motion.div>

      {/* طلباتي */}
      <div className="mt-5">
        <div className="flex items-center justify-between gap-2 mb-3 flex-wrap">
          <h2 className="font-black text-lg flex items-center gap-2">
            <Receipt className="h-5 w-5 text-[#FF6B00]" /> طلباتي وتتبعها
          </h2>
          <div className="relative w-48">
            <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
            <Input
              value={searchCode}
              onChange={(e) => setSearchCode(e.target.value)}
              placeholder="ابحث برقم الطلب"
              dir="ltr"
              className="ps-8 h-9 bg-white text-left text-xs rounded-full"
            />
          </div>
        </div>

        {orders === null ? (
          <div className="space-y-2">
            <Skeleton className="h-20 rounded-2xl" />
            <Skeleton className="h-20 rounded-2xl" />
          </div>
        ) : shown.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center border border-dashed border-[#FFAA00]">
            <div className="text-4xl mb-2">📭</div>
            <p className="font-bold">لا توجد طلبات بعد</p>
            <p className="text-sm text-muted-foreground mt-1 mb-4">اطلب من مطاعم ومتاجر حديثة وسيظهر طلبك هنا مع التتبع المباشر</p>
            <Button className="rounded-full bg-[#FF6B00] hover:bg-[#E85F00]" onClick={() => setView({ name: "home" })}>
              تصفح المتاجر
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            {active.length > 0 && (
              <section className="space-y-2">
                <h3 className="text-xs font-black text-[#2E7D32] flex items-center gap-1.5">
                  <span className="h-2 w-2 rounded-full bg-[#2E7D32] soft-blink" /> طلبات جارية ({active.length})
                </h3>
                {active.map((o) => (
                  <OrderRow key={o.id} order={o} onTrack={() => setView({ name: "track", code: o.code })} />
                ))}
              </section>
            )}
            {past.length > 0 && (
              <section className="space-y-2">
                <h3 className="text-xs font-black text-muted-foreground">السجل السابق ({past.length})</h3>
                {past.map((o) => (
                  <OrderRow key={o.id} order={o} onTrack={() => setView({ name: "track", code: o.code })} />
                ))}
              </section>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function OrderRow({ order, onTrack }: { order: Order; onTrack: () => void }) {
  const isActive = ["PENDING", "CONFIRMED", "PREPARING", "DELIVERING"].includes(order.status);
  return (
    <button
      onClick={onTrack}
      className={`w-full text-right bg-white rounded-2xl border p-4 flex items-center gap-3 transition hover:shadow-md ${
        isActive ? "border-[#FFAA00] anim-in" : "border-border"
      }`}
    >
      <span className="h-12 w-12 rounded-xl bg-[#FFF6DE] flex items-center justify-center text-xl shrink-0">
        {order.store?.type === "MARKET" ? "🛒" : order.store?.type === "STORE" ? "🏬" : "🍽️"}
      </span>
      <div className="flex-1 min-w-0">
        <div className="font-black text-sm">
          {order.store?.name}{" "}
          <span className="text-muted-foreground font-medium text-xs" dir="ltr">
            · {order.code}
          </span>
        </div>
        <div className="text-xs text-muted-foreground">
          {formatDate(order.createdAt)} · {order.items.reduce((s, i) => s + i.quantity, 0)} أصناف
        </div>
      </div>
      <div className="text-left shrink-0">
        <Badge
          className={`border-0 text-[10px] ${
            order.status === "DELIVERED"
              ? "bg-[#2E7D32]"
              : order.status === "CANCELLED"
                ? "bg-red-500"
                : "bg-[#FFAA00] text-[#111827]"
          }`}
        >
          {ORDER_STATUS_AR[order.status as OrderStatus]}
        </Badge>
        <div className="font-black text-sm mt-1">{formatIQD(order.total)}</div>
      </div>
      {isActive && (
        <span className="flex items-center gap-1 text-[10px] font-black text-[#FF6B00] shrink-0">
          <Bike className="h-3.5 w-3.5" />
          تتبع
          <span className="hidden sm:inline">
            <Car className="h-3 w-3" />
          </span>
          <LocateFixed className="h-3 w-3 animate-pulse" />
        </span>
      )}
    </button>
  );
}
