"use client";

// خريطة مطاعم جيبلي في مدينة حديثة — الصفحة الرئيسية
// الخريطة الحقيقية لمعالم المدينة (مدارس، مشفى، دوار، أحياء) + علامات مطاعم جيبلي فقط
// لا تظهر أي مطاعم أو متاجر خارجية على الخريطة
import { useEffect, useMemo, useRef, useState } from "react";
import type { Marker as MlMarker } from "maplibre-gl";
import { motion } from "framer-motion";
import { Clock, MapPinned, Star, Truck, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppStore } from "@/store/app-store";
import { formatIQD } from "@/lib/format";
import { HADITHA_BOUNDS, HADITHA_CENTER, haversineKm } from "@/lib/geo";
import type { Store } from "@/lib/types";
import { createJeeblyMap, markerEl, type JeeblyMapHandle } from "./jeebly-basemap";

interface Props {
  restaurants: Store[];
  loading?: boolean;
}

export function HadithaRestaurantsMap({ restaurants, loading }: Props) {
  const setView = useAppStore((s) => s.setView);
  const mapRef = useRef<HTMLDivElement | null>(null);
  const handle = useRef<JeeblyMapHandle | null>(null);
  const [ready, setReady] = useState(false);
  const [selected, setSelected] = useState<Store | null>(null);
  const markersRef = useRef<Record<string, MlMarker>>({});
  const selectRef = useRef<(s: Store | null) => void>(() => {});
  useEffect(() => {
    selectRef.current = (s) => setSelected(s);
  }, []);

  const withCoords = useMemo(
    () => restaurants.filter((r) => typeof r.lat === "number" && typeof r.lng === "number"),
    [restaurants]
  );

  // HADITHA_BOUNDS معرفة بصيغة [lat,lng] — MapLibre يتوقع [[lng,lat],[lng,lat]]
  const JB_BOUNDS: [[number, number], [number, number]] = [
    [HADITHA_BOUNDS[0][1], HADITHA_BOUNDS[0][0]],
    [HADITHA_BOUNDS[1][1], HADITHA_BOUNDS[1][0]],
  ];

  // تهيئة الخريطة مرة واحدة
  useEffect(() => {
    let disposed = false;
    let local: JeeblyMapHandle | null = null;
    (async () => {
      if (!mapRef.current) return;
      const h = await createJeeblyMap(mapRef.current, { zoom: 13.4 });
      if (disposed) {
        h.destroy();
        return;
      }
      local = h;
      handle.current = h;
      setReady(true);
    })();
    return () => {
      disposed = true;
      local?.destroy();
      handle.current = null;
      markersRef.current = {};
      setReady(false);
    };
  }, []);

  // علامات مطاعم جيبلي (المصدر الوحيد لعلامات الطعام على الخريطة)
  const didFit = useRef(false);
  useEffect(() => {
    const h = handle.current;
    if (!ready || !h) return;
    const { map, ml } = h;

    // إزالة العلامات القديمة
    Object.values(markersRef.current).forEach((m) => m.remove());
    markersRef.current = {};

    withCoords.forEach((r, i) => {
      const el = markerEl(
        `<div class="map-pin map-pin-store" style="width:34px;height:34px;font-size:17px;">🍽️
           <span style="position:absolute;top:-6px;inset-inline-end:-6px;background:#111827;color:#fff;font-size:9px;font-weight:900;border-radius:999px;min-width:15px;height:15px;display:flex;align-items:center;justify-content:center;border:2px solid #fff;">${i + 1}</span>
         </div>`
      );
      el.style.cursor = "pointer";
      el.title = r.name;
      el.addEventListener("click", (e) => {
        e.stopPropagation();
        selectRef.current(r);
      });
      const mk = new ml.Marker({ element: el, anchor: "center" })
        .setLngLat([r.lng as number, r.lat as number])
        .addTo(map);
      markersRef.current[r.id] = mk;
    });

    // أول ظهور للبيانات: تأطير منطقة المطاعم بحيث تنتشر العلامات بوضوح
    if (!didFit.current && withCoords.length > 0) {
      didFit.current = true;
      const lngs = withCoords.map((r) => r.lng as number);
      const lats = withCoords.map((r) => r.lat as number);
      map.fitBounds(
        [
          [Math.min(...lngs), Math.min(...lats)],
          [Math.max(...lngs), Math.max(...lats)],
        ],
        { padding: { top: 60, bottom: 90, left: 50, right: 50 }, maxZoom: 14.4, duration: 0 }
      );
    }
  }, [ready, withCoords]);

  const loadingDots = loading || (!ready && withCoords.length === 0);

  return (
    <section aria-label="خريطة مطاعم جيبلي في حديثة" className="relative isolate">
      <div className="flex items-center justify-between mb-3 gap-2 flex-wrap">
        <h2 className="text-lg font-black flex items-center gap-2">
          <MapPinned className="h-5 w-5 text-[#FF6B00]" />
          خريطة مطاعم جيبلي — مدينة حديثة
        </h2>
        {/* دليل الخريطة */}
        <div className="flex items-center gap-2 text-[10px] font-bold text-muted-foreground">
          <span className="flex items-center gap-1">
            <span className="h-3.5 w-3.5 rounded-full bg-[#FF6B00] border-2 border-white shadow" />
            مطاعم جيبلي
          </span>
          <span className="flex items-center gap-1">
            <span className="h-3.5 w-3.5 rounded-full bg-white border border-border shadow-sm" />
            معالم المدينة
          </span>
        </div>
      </div>

      <div className="rounded-3xl overflow-hidden border border-border shadow-sm relative bg-[#E9EEF3]">
        <div ref={mapRef} className="h-[340px] sm:h-[400px] w-full" aria-label="خريطة حديثة" />

        {/* بطاقة المطعم المحدد — فوق الخريطة داخل حاويتها */}
        {selected && (
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            className="absolute bottom-3 start-3 end-3 sm:end-auto sm:w-80 bg-white rounded-2xl shadow-xl border border-border p-3.5 z-20"
          >
            <button
              onClick={() => setSelected(null)}
              className="absolute top-2.5 end-2.5 h-6 w-6 rounded-full bg-[#F8F9FA] flex items-center justify-center text-muted-foreground hover:text-foreground"
              aria-label="إغلاق"
            >
              <X className="h-3.5 w-3.5" />
            </button>
            <div className="flex items-center gap-3">
              <img
                src={selected.imageUrl || "/placeholder-restaurant.svg"}
                alt={selected.name}
                className="h-14 w-14 rounded-xl object-cover shrink-0"
                loading="lazy"
              />
              <div className="min-w-0 flex-1">
                <div className="flex items-center gap-1.5">
                  <h3 className="font-black text-sm truncate">{selected.name}</h3>
                  <span className="flex items-center gap-0.5 text-[10px] font-black bg-[#FFAA00]/20 text-[#111827] px-1.5 py-0.5 rounded-md shrink-0">
                    <Star className="h-2.5 w-2.5 fill-current text-[#FFAA00]" />
                    {selected.rating.toFixed(1)}
                  </span>
                </div>
                <div className="flex items-center gap-2.5 mt-1 text-[11px] text-muted-foreground">
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3" />
                    {selected.deliveryTime}
                  </span>
                  <span className="flex items-center gap-1">
                    <Truck className="h-3 w-3" />
                    {selected.deliveryFee === 0 ? "مجاني" : formatIQD(selected.deliveryFee)}
                  </span>
                  <span className="hidden sm:inline">
                    {haversineKm(HADITHA_CENTER, { lat: selected.lat as number, lng: selected.lng as number }).toFixed(1)} كم
                  </span>
                </div>
              </div>
            </div>
            <Button
              className="w-full mt-3 rounded-full bg-[#FF6B00] hover:bg-[#E85F00] h-9 font-black text-sm"
              onClick={() => setView({ name: "store", storeId: selected.id })}
            >
              عرض قائمة الطعام
            </Button>
          </motion.div>
        )}

        {/* حالة التحميل */}
        {loadingDots && (
          <div className="absolute inset-0 bg-white/70 backdrop-blur-[2px] flex flex-col items-center justify-center gap-3 z-10">
            <Skeleton className="h-10 w-10 rounded-full" />
            <p className="text-xs font-bold text-muted-foreground">جاري تحميل خريطة حديثة…</p>
          </div>
        )}
      </div>

      <p className="text-[11px] text-muted-foreground mt-2 leading-relaxed">
        تُظهر الخريطة معالم مدينة حديثة (المدارس، المشفى، الدوائر، الأحياء، الجسر، نهر الفرات) مع
        علامات <span className="font-black text-[#FF6B00]">مطاعم جيبلي فقط</span> — انقر على أي علامة برتقالية لعرض المطعم.
      </p>
    </section>
  );
}
