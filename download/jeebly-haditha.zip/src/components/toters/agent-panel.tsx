"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { ArrowRight, Bike, Car, LogOut, MapPin, Phone, RefreshCw, Navigation } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { formatIQD, formatDate } from "@/lib/format";
import { ORDER_STATUS_AR, type Agent, type Order, type OrderStatus } from "@/lib/types";
import { useAppStore } from "@/store/app-store";

export function AgentPanel() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [toggling, setToggling] = useState(false);
  const setView = useAppStore((s) => s.setView);

  const me = useMemo(() => agents.find((a) => a.id === selectedId) || null, [agents, selectedId]);

  const loadAgents = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/agents");
      const data: Agent[] = await res.json();
      setAgents(Array.isArray(data) ? data : []);
      return Array.isArray(data) ? data : [];
    } finally {
      setLoading(false);
    }
  }, []);

  const loadOrders = useCallback(async (agentId: string) => {
    const res = await fetch(`/api/orders?agentId=${agentId}`);
    const data: Order[] = await res.json();
    setOrders(Array.isArray(data) ? data : []);
  }, []);

  useEffect(() => {
    loadAgents();
  }, [loadAgents]);

  useEffect(() => {
    if (!selectedId) return;
    loadOrders(selectedId);
    const t = setInterval(() => loadOrders(selectedId), 15000);
    return () => clearInterval(t);
  }, [selectedId, loadOrders]);

  const activeOrders = orders.filter((o) => ["CONFIRMED", "PREPARING", "DELIVERING"].includes(o.status));
  const history = orders.filter((o) => ["DELIVERED", "CANCELLED"].includes(o.status));

  async function toggleOnline() {
    if (!me || toggling) return;
    setToggling(true);
    const next = me.status === "OFFLINE" ? "AVAILABLE" : "OFFLINE";
    await fetch(`/api/agents/${me.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status: next }),
    });
    await loadAgents();
    toast({ title: next === "AVAILABLE" ? "أنت متاح الآن 🟢 — ستصلوصلك الطلبات" : "انت غير متصل الآن ⚪" });
    setToggling(false);
  }

  async function updateOrder(order: Order, status: OrderStatus) {
    const res = await fetch(`/api/orders/${order.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    if (res.ok) {
      toast({
        title: status === "DELIVERING" ? `الطلب ${order.code}: في الطريق 🛵` : status === "DELIVERED" ? `تم تسليم ${order.code} ✅ أحسنت!` : `تم تحديث الطلب`,
      });
      if (selectedId) {
        await Promise.all([loadOrders(selectedId), loadAgents()]);
      }
    } else {
      toast({ title: "تعذر تحديث الطلب", variant: "destructive" });
    }
  }

  return (
    <div className="max-w-3xl mx-auto px-4 pb-32 pt-4">
      <button onClick={() => setView({ name: "home" })} className="flex items-center gap-1.5 text-sm font-bold text-muted-foreground hover:text-[#FF6B00] transition mb-3">
        <ArrowRight className="h-4 w-4" /> رجوع للمتجر
      </button>

      <div className="toters-gradient rounded-3xl p-5 text-white mb-4 anim-in">
        <div className="flex items-center gap-3">
          <span className="h-14 w-14 rounded-2xl bg-white/20 backdrop-blur flex items-center justify-center text-3xl">🛵</span>
          <div className="flex-1">
            <h1 className="text-xl font-black">تطبيق الوكيل — الكابتن</h1>
            <p className="text-sm text-white/90">اختر اسمك لعرض الطلبات المسندة إليك</p>
          </div>
        </div>
      </div>

      {/* اختيار الوكيل */}
      <div className="bg-white rounded-2xl border border-border p-4 mb-4">
        {loading ? (
          <Skeleton className="h-10 rounded-full" />
        ) : agents.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-3">
            لا يوجد وكلاء بعد — أضف وكلاء من <span className="font-bold text-[#FF6B00]">لوحة تحكم المدير ← الوكلاء</span>
          </p>
        ) : (
          <div className="flex items-center gap-2 flex-wrap">
            <Select value={selectedId || undefined} onValueChange={setSelectedId}>
              <SelectTrigger className="flex-1 min-w-44 rounded-full h-11 bg-[#F8F9FA]">
                <SelectValue placeholder="🧑‍✈️ اختر اسم الوكيل..." />
              </SelectTrigger>
              <SelectContent>
                {agents.map((a) => (
                  <SelectItem key={a.id} value={a.id}>
                    {a.vehicleType === "CAR" ? "🚗" : "🛵"} {a.name} — {a.status === "AVAILABLE" ? "متاح" : a.status === "BUSY" ? "مشغول" : "غير متصل"}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {me && (
              <Button
                variant={me.status === "OFFLINE" ? "default" : "outline"}
                className={`rounded-full h-11 font-bold ${me.status === "OFFLINE" ? "bg-[#2E7D32] hover:bg-[#1B5E20]" : "text-red-500"}`}
                onClick={toggleOnline}
                disabled={toggling}
              >
                {me.status === "OFFLINE" ? "تشغيل الاستقبال 🟢" : "إيقاف الاستقبال ⚪"}
              </Button>
            )}
          </div>
        )}
      </div>

      {me && (
        <div className="space-y-4 anim-in">
          {/* بطاقة الوكيل */}
          <div className="bg-white rounded-2xl border border-border p-4 flex items-center gap-3 flex-wrap">
            <span className={`h-12 w-12 rounded-2xl flex items-center justify-center text-2xl ${me.vehicleType === "CAR" ? "bg-[#E6F4EA]" : "bg-[#FFF3E6]"}`}>
              {me.vehicleType === "CAR" ? <Car className="h-6 w-6 text-[#2E7D32]" /> : <Bike className="h-6 w-6 text-[#FF6B00]" />}
            </span>
            <div className="flex-1 min-w-32">
              <div className="font-black">{me.name}</div>
              <div className="text-xs text-muted-foreground" dir="ltr">{me.phone}</div>
            </div>
            <Badge className="bg-[#E6F4EA] text-[#2E7D32] border-0">⭐ {me.rating.toFixed(1)}</Badge>
            <Badge className="bg-[#FFF6DE] text-[#111827] border-0">{me.totalDeliveries} توصيلة مكتملة</Badge>
            <Badge className={`border-0 ${me.status === "AVAILABLE" ? "bg-[#2E7D32]" : me.status === "BUSY" ? "bg-[#FFAA00] text-[#111827]" : "bg-gray-300"}`}>
              {me.status === "AVAILABLE" ? "متاح" : me.status === "BUSY" ? "مشغول" : "غير متصل"}
            </Badge>
          </div>

          {/* الطلبات الجارية */}
          <div>
            <h2 className="font-black text-sm mb-2.5 flex items-center gap-2">
              <Navigation className="h-4 w-4 text-[#FF6B00]" /> طلبات جارية ({activeOrders.length})
              <Button variant="ghost" size="sm" className="h-7 rounded-full ms-auto text-xs" onClick={() => selectedId && loadOrders(selectedId)}>
                <RefreshCw className="h-3.5 w-3.5" />
              </Button>
            </h2>
            {activeOrders.length === 0 ? (
              <div className="bg-white rounded-2xl p-8 text-center border border-dashed border-[#FFAA00]">
                <div className="text-3xl mb-1">☕</div>
                <p className="text-sm font-bold">لا توجد طلبات مسندة لك حالياً</p>
                <p className="text-xs text-muted-foreground mt-1">حالة {me.status === "OFFLINE" ? "«غير متصل»" : "«متاح»"} — سيُسند لك المدير الطلبات من لوحة التحكم</p>
              </div>
            ) : (
              <div className="space-y-3">
                {activeOrders.map((o) => (
                  <div key={o.id} className="bg-white rounded-2xl border border-border p-4 space-y-3">
                    <div className="flex items-center justify-between flex-wrap gap-2">
                      <div>
                        <div className="font-black text-sm">{o.store?.name} <span className="text-muted-foreground font-medium text-xs" dir="ltr">· {o.code}</span></div>
                        <div className="text-[11px] text-muted-foreground">{formatDate(o.createdAt)} · {o.paymentMethod === "CASH" ? "💵 نقداً" : "💳 بطاقة"}</div>
                      </div>
                      <Badge className={`border-0 text-[10px] ${o.status === "DELIVERING" ? "bg-[#2E7D32]" : o.status === "PREPARING" ? "bg-[#111827]" : "bg-[#FFAA00] text-[#111827]"}`}>
                        {ORDER_STATUS_AR[o.status as OrderStatus]}
                      </Badge>
                    </div>

                    <div className="text-sm space-y-0.5 bg-[#F8F9FA] rounded-xl p-3">
                      {o.items.map((it) => (
                        <div key={it.id} className="flex justify-between text-muted-foreground">
                          <span>{it.name} × {it.quantity}</span>
                          <span>{formatIQD(it.price * it.quantity)}</span>
                        </div>
                      ))}
                      <div className="flex justify-between font-bold text-foreground pt-1">
                        <span>تُحصّل من العميل</span>
                        <span className="text-[#FF6B00]">{formatIQD(o.total)}</span>
                      </div>
                    </div>

                    <div className="text-xs text-muted-foreground flex items-start gap-1.5">
                      <MapPin className="h-3.5 w-3.5 text-[#FF6B00] shrink-0 mt-0.5" />
                      <span>{o.address} — {o.customerName}</span>
                    </div>

                    <div className="flex gap-2 flex-wrap">
                      <a
                        href={`tel:${o.customerPhone}`}
                        className="flex items-center gap-1.5 border rounded-full px-3.5 h-9 text-xs font-bold hover:bg-[#F8F9FA] transition"
                      >
                        <Phone className="h-3.5 w-3.5" /> اتصال بالعميل
                      </a>
                      {o.status === "PREPARING" && (
                        <Button className="rounded-full h-9 bg-[#FF6B00] hover:bg-[#E85F00] text-xs font-bold" onClick={() => updateOrder(o, "DELIVERING")}>
                          🛵 استلمت الطلب — في الطريق
                        </Button>
                      )}
                      {o.status === "DELIVERING" && (
                        <Button className="rounded-full h-9 bg-[#2E7D32] hover:bg-[#1B5E20] text-xs font-bold" onClick={() => updateOrder(o, "DELIVERED")}>
                          ✅ تم التسليم
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* سجل التوصيلات */}
          {history.length > 0 && (
            <div>
              <h2 className="font-black text-sm mb-2.5">سجل التوصيلات ({history.length})</h2>
              <div className="space-y-2">
                {history.slice(0, 8).map((o) => (
                  <div key={o.id} className="bg-white rounded-xl border border-border p-3 flex items-center gap-2.5 text-sm">
                    <span className={`h-2.5 w-2.5 rounded-full shrink-0 ${o.status === "DELIVERED" ? "bg-[#2E7D32]" : "bg-red-400"}`} />
                    <span className="font-bold flex-1 truncate">{o.store?.name}</span>
                    <span className="text-[11px] text-muted-foreground" dir="ltr">{o.code}</span>
                    <span className="text-xs text-muted-foreground">{formatDate(o.createdAt)}</span>
                    <span className="font-black text-xs">{formatIQD(o.total)}</span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
