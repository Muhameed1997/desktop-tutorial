"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import Image from "next/image";
import { Star, Clock, Truck, UtensilsCrossed, Store, ShoppingCart, UserPlus } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { useAppStore } from "@/store/app-store";
import { useAuthStore } from "@/store/auth-store";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatIQD } from "@/lib/format";
import { TYPE_AR, type Store, type StoreType } from "@/lib/types";
import { HadithaRestaurantsMap } from "@/components/toters/haditha-restaurants-map";

interface Props {
  search: string;
}

const CATEGORIES: { key: StoreType | "ALL"; label: string; icon: React.ReactNode; activeClass: string }[] = [
  { key: "ALL", label: "الكل", icon: <UtensilsCrossed className="h-5 w-5" />, activeClass: "bg-[#FF6B00] text-white" },
  { key: "RESTAURANT", label: "مطاعم", icon: <UtensilsCrossed className="h-5 w-5" />, activeClass: "bg-[#FF6B00] text-white" },
  { key: "STORE", label: "متاجر", icon: <Store className="h-5 w-5" />, activeClass: "bg-[#FFAA00] text-[#111827]" },
  { key: "MARKET", label: "أسواق", icon: <ShoppingCart className="h-5 w-5" />, activeClass: "bg-[#2E7D32] text-white" },
];

const RANK_STYLES = ["bg-[#FF6B00] text-white", "bg-[#FFAA00] text-[#111827]", "bg-[#2E7D32] text-white"];

// حركة موحدة للبطاقات
const cardVariants = {
  hidden: { opacity: 0, y: 16 },
  show: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { delay: i * 0.06, duration: 0.35, ease: "easeOut" as const },
  }),
};

export function CustomerHome({ search }: Props) {
  const [all, setAll] = useState<Store[]>([]);
  const [loading, setLoading] = useState(true);
  const [cat, setCat] = useState<StoreType | "ALL">("ALL");
  const user = useAuthStore((s) => s.user);
  const setView = useAppStore((s) => s.setView);

  useEffect(() => {
    setLoading(true);
    fetch("/api/stores")
      .then((r) => r.json())
      .then((data) => {
        setAll(Array.isArray(data) ? data : []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  // المطاعم الأكثر رواجاً: مطاعم فقط مرتبة بالرواج والتقييم
  const popularRestaurants = useMemo(() => {
    return all
      .filter((s) => s.type === "RESTAURANT" && s.isOpen)
      .sort((a, b) => Number(b.isFeatured) - Number(a.isFeatured) || b.rating - a.rating)
      .slice(0, 8);
  }, [all]);

  const filtered = useMemo(() => {
    const q = search.trim();
    return all.filter(
      (s) =>
        (cat === "ALL" || s.type === cat) &&
        (!q || s.name.includes(q) || s.category.includes(q) || (s.description || "").includes(q))
    );
  }, [all, cat, search]);

  return (
    <div className="max-w-6xl mx-auto px-4 pb-44 pt-4 space-y-6">
      {/* بانر جيبلي — مختصر وواضح */}
      <motion.div
        initial={{ opacity: 0, y: 18, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.45, ease: "easeOut" }}
        className="brand-gradient rounded-3xl px-5 py-4 sm:px-7 sm:py-5 text-white relative overflow-hidden shadow-brand"
      >
        <motion.div
          className="absolute -top-8 -start-8 h-36 w-36 rounded-full bg-white/10"
          animate={{ scale: [1, 1.15, 1] }}
          transition={{ duration: 5, repeat: Infinity, ease: "easeInOut" }}
        />
        {/* علامة جيبلي الرسمية كعلامة مائية أنيقة */}
        <div className="absolute top-3 end-4 opacity-95 hidden sm:block" aria-hidden>
          <Image
            src="/brand/jeebly-mark.png"
            alt=""
            width={96}
            height={67}
            className="h-14 w-auto drop-shadow-[0_6px_16px_rgba(0,0,0,0.25)]"
          />
        </div>
        <h1 className="text-xl sm:text-2xl font-black">
          جوعان؟ <span className="text-[#FFF6DE]">جيبلي</span> يوصلك 🍽️
        </h1>
        <p className="text-white/90 text-sm mt-0.5">توصيل سريع داخل حديثة — تابع سائقك مباشرة 🗺️</p>
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          <Badge className="bg-white/20 text-white border-0 backdrop-blur text-[11px]">📍 حديثة – الأنبار</Badge>
          <Badge className="bg-white/20 text-white border-0 backdrop-blur text-[11px]">⚡ توصيل سريع</Badge>
        </div>
      </motion.div>

      {/* المطاعم الأكثر رواجاً في حديثة — شريط أفقي بأسلوب تطبيقات التوصيل */}
      {!loading && popularRestaurants.length > 0 && !search && (
        <section aria-label="المطاعم الأكثر رواجاً">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-lg font-black flex items-center gap-2">
              <span className="text-xl">🔥</span>
              الأكثر رواجاً في حديثة
            </h2>
          </div>
          <div className="flex gap-4 overflow-x-auto no-scrollbar -mx-4 px-4 pb-2 snap-x snap-mandatory">
            {popularRestaurants.map((s, i) => (
              <motion.button
                key={s.id}
                custom={i}
                variants={cardVariants}
                initial="hidden"
                animate="show"
                whileHover={{ y: -4, scale: 1.015 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setView({ name: "store", storeId: s.id })}
                className="snap-start shrink-0 w-60 text-right bg-white rounded-2xl overflow-hidden border border-border hover:shadow-xl transition-shadow"
                aria-label={`مطعم ${s.name}`}
              >
                <div className="relative h-32">
                  <img
                    src={s.imageUrl || "/placeholder-restaurant.svg"}
                    alt={s.name}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/45 to-transparent" />
                  {i < 3 && (
                    <span
                      className={`absolute top-2 end-2 h-7 w-7 rounded-full flex items-center justify-center text-xs font-black shadow-lg ${RANK_STYLES[i]}`}
                    >
                      {i + 1}
                    </span>
                  )}
                  <span className="absolute top-2 start-2 bg-[#FFAA00] text-[#111827] text-[10px] font-black px-2 py-1 rounded-full shadow">
                    رواج 🔥
                  </span>
                  <div className="absolute bottom-2 start-3 end-3 text-white">
                    <div className="font-black text-sm truncate">{s.name}</div>
                  </div>
                </div>
                <div className="p-3">
                  <p className="text-xs text-muted-foreground truncate">🍽️ مطعم · {s.category}</p>
                  <div className="flex items-center gap-3 mt-2 text-[11px] text-muted-foreground">
                    <span className="flex items-center gap-1 font-bold text-[#111827] bg-[#FFAA00]/20 px-1.5 py-0.5 rounded-md">
                      <Star className="h-3 w-3 fill-current text-[#FFAA00]" />
                      {s.rating.toFixed(1)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {s.deliveryTime}
                    </span>
                    <span className="flex items-center gap-1">
                      <Truck className="h-3 w-3" />
                      {s.deliveryFee === 0 ? "مجاني" : formatIQD(s.deliveryFee)}
                    </span>
                  </div>
                </div>
              </motion.button>
            ))}
          </div>
        </section>
      )}

      {/* خريطة مطاعم جيبلي — مدينة حديثة (معالم المدينة + مطاعم جيبلي فقط) */}
      {!search && (
        <HadithaRestaurantsMap
          restaurants={all.filter((s) => s.type === "RESTAURANT")}
          loading={loading}
        />
      )}

      {/* شرائح التصنيفات */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar -mx-4 px-4">
        {CATEGORIES.map((c) => (
          <button
            key={c.key}
            onClick={() => setCat(c.key)}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-bold whitespace-nowrap border transition-all shrink-0 ${
              cat === c.key
                ? `${c.activeClass} border-transparent shadow-md scale-[1.02]`
                : "bg-white border-border text-foreground hover:border-[#FFAA00]"
            }`}
            aria-pressed={cat === c.key}
          >
            {c.icon}
            {c.label}
          </button>
        ))}
      </div>

      {/* دعوة لإنشاء حساب للطلب — التسجيل بالهاتف فقط */}
      {!user && !search && (
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
          className="bg-white rounded-2xl border-2 border-dashed border-[#FF6B00]/50 p-4 flex items-center gap-3 flex-wrap"
        >
          <span className="h-11 w-11 rounded-2xl bg-[#FFF3E6] flex items-center justify-center shrink-0">
            <UserPlus className="h-5 w-5 text-[#FF6B00]" />
          </span>
          <div className="flex-1 min-w-40">
            <p className="font-black text-sm">سجّل برقم هاتفك لتطلب</p>
            <p className="text-xs text-muted-foreground">رمز تحقق يصلك على هاتفك — بدون كلمة مرور، خلال ثوانٍ</p>
          </div>
          <Button
            className="rounded-full bg-[#FF6B00] hover:bg-[#E85F00] font-bold"
            onClick={() => setView({ name: "account" })}
          >
            إنشاء حساب / دخول
          </Button>
        </motion.div>
      )}

      {/* قائمة المتاجر — بأسلوب تطبيقات التوصيل الشائعة (صفوف بطاقة بصورة جانبية) */}
      <section>
        <h2 className="text-lg font-black mb-3">
          {cat === "ALL" ? "كل المتاجر القريبة منك في حديثة" : CATEGORIES.find((c) => c.key === cat)?.label}
          <span className="text-muted-foreground font-medium text-sm ms-2">({filtered.length})</span>
        </h2>

        {loading ? (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="bg-white rounded-2xl border border-border p-3 flex gap-3">
                <Skeleton className="h-24 w-24 rounded-2xl shrink-0" />
                <div className="flex-1 space-y-2 py-1">
                  <Skeleton className="h-4 w-2/3" />
                  <Skeleton className="h-3 w-1/2" />
                  <Skeleton className="h-3 w-3/4" />
                </div>
              </div>
            ))}
          </div>
        ) : filtered.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center border border-dashed border-[#FFAA00]">
            <div className="text-4xl mb-2">🔍</div>
            <p className="font-bold">لا توجد نتائج</p>
            <p className="text-sm text-muted-foreground mt-1">
              {search ? `لا يوجد متجر يطابق بحثك عن "${search}"` : "لم يتم إضافة متاجر بعد — أضفها من لوحة المدير"}
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            {filtered.map((s, i) => (
              <motion.div key={s.id} custom={i} variants={cardVariants} initial="hidden" animate="show" whileHover={{ y: -3 }}>
                <StoreCard store={s} />
              </motion.div>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

// بطاقة متجر بأسلوب تطبيقات التوصيل الشائعة (Talabat/ToYou): صورة جانبية + معلومات موجزة
function StoreCard({ store }: { store: Store }) {
  const setView = useAppStore((s) => s.setView);
  const typeIcon = store.type === "RESTAURANT" ? "🍽️" : store.type === "MARKET" ? "🛒" : "🏬";

  return (
    <button
      onClick={() => setView({ name: "store", storeId: store.id })}
      className="w-full text-right bg-white rounded-2xl border border-border hover:shadow-lg transition-all group h-full flex gap-3 p-3"
    >
      {/* الصورة الجانبية المربعة */}
      <div className="relative h-24 w-24 sm:h-28 sm:w-28 rounded-2xl overflow-hidden shrink-0">
        <img
          src={
            store.imageUrl ||
            (store.type === "MARKET"
              ? "/placeholder-market.svg"
              : store.type === "STORE"
                ? "/placeholder-store.svg"
                : "/placeholder-restaurant.svg")
          }
          alt={store.name}
          className="h-full w-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        {store.isFeatured && store.isOpen && (
          <span className="absolute top-1.5 start-1.5 bg-[#FFAA00] text-[#111827] text-[9px] font-black px-1.5 py-0.5 rounded-full shadow">
            رواج 🔥
          </span>
        )}
        {!store.isOpen && (
          <div className="absolute inset-0 bg-black/55 flex items-center justify-center">
            <span className="text-white font-bold text-[11px] bg-black/60 px-2 py-1 rounded-full">مغلق</span>
          </div>
        )}
      </div>

      {/* المعلومات */}
      <div className="flex-1 min-w-0 flex flex-col py-0.5">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-black text-[15px] truncate">{store.name}</h3>
          <span className="flex items-center gap-1 text-xs font-bold text-[#111827] bg-[#FFAA00]/20 px-1.5 py-0.5 rounded-md shrink-0">
            <Star className="h-3 w-3 fill-current text-[#FFAA00]" />
            {store.rating.toFixed(1)}
          </span>
        </div>
        <p className="text-xs text-muted-foreground mt-0.5 truncate">
          {typeIcon} {TYPE_AR[store.type as StoreType] || "متجر"} · {store.category}
        </p>
        <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{store.description}</p>
        <div className="flex items-center gap-3 mt-auto pt-1.5 text-[11px] text-muted-foreground flex-wrap">
          <span className="flex items-center gap-1 font-bold text-[#2E7D32]">
            <Clock className="h-3 w-3" />
            {store.deliveryTime}
          </span>
          <span className="flex items-center gap-1">
            <Truck className="h-3 w-3" />
            {store.deliveryFee === 0 ? "توصيل مجاني" : formatIQD(store.deliveryFee)}
          </span>
          {store.minOrder > 0 && (
            <span className="text-[10px] bg-[#F8F9FA] border border-border rounded px-1.5 py-0.5">
              أدنى طلب {formatIQD(store.minOrder)}
            </span>
          )}
        </div>
      </div>
    </button>
  );
}
