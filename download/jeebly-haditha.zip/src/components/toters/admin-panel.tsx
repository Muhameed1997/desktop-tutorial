"use client";

import { useCallback, useEffect, useState } from "react";
import {
  ArrowRight, LayoutDashboard, UtensilsCrossed, Bike, ClipboardList, RefreshCw,
  Star, TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { toast } from "@/hooks/use-toast";
import { formatIQD, formatDate, formatNumber } from "@/lib/format";
import { ORDER_STATUS_AR, TYPE_AR, type Agent, type Order, type OrderStatus, type Stats, type Store, type StoreType } from "@/lib/types";
import { AdminStoresTab } from "./admin-stores";
import { AdminAgentsTab } from "./admin-agents";
import { AdminOrdersTab } from "./admin-orders";
import { useAppStore } from "@/store/app-store";

const TABS = [
  { key: "overview", label: "نظرة عامة", icon: LayoutDashboard },
  { key: "stores", label: "المطاعم والمتاجر", icon: UtensilsCrossed },
  { key: "agents", label: "الوكلاء", icon: Bike },
  { key: "orders", label: "الطلبات", icon: ClipboardList },
] as const;

type TabKey = (typeof TABS)[number]["key"];

export function AdminPanel() {
  const [tab, setTab] = useState<TabKey>("overview");
  const setView = useAppStore((s) => s.setView);

  return (
    <div className="max-w-6xl mx-auto px-4 pb-32 pt-4">
      <div className="flex items-center justify-between flex-wrap gap-2 mb-4">
        <div className="flex items-center gap-2">
          <button onClick={() => setView({ name: "home" })} className="flex items-center gap-1.5 text-sm font-bold text-muted-foreground hover:text-[#FF6B00] transition">
            <ArrowRight className="h-4 w-4" />
          </button>
          <div>
            <h1 className="text-xl font-black">لوحة تحكم المدير 👨‍💼</h1>
            <p className="text-xs text-muted-foreground">إدارة المطاعم والمتاجر والأسواق والوكلاء والطلبات</p>
          </div>
        </div>
        <Button variant="outline" size="sm" className="rounded-full" onClick={() => window.location.reload()}>
          <RefreshCw className="h-3.5 w-3.5 me-1.5" /> تحديث
        </Button>
      </div>

      {/* التبويبات */}
      <div className="flex gap-2 overflow-x-auto no-scrollbar mb-5 -mx-4 px-4">
        {TABS.map((t) => {
          const Icon = t.icon;
          return (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl text-sm font-bold whitespace-nowrap border transition-all shrink-0 ${
                tab === t.key
                  ? "bg-[#FF6B00] text-white border-transparent shadow-md"
                  : "bg-white border-border hover:border-[#FFAA00]"
              }`}
            >
              <Icon className="h-4 w-4" />
              {t.label}
            </button>
          );
        })}
      </div>

      {tab === "overview" && <OverviewTab />}
      {tab === "stores" && <AdminStoresTab />}
      {tab === "agents" && <AdminAgentsTab />}
      {tab === "orders" && <AdminOrdersTab />}
    </div>
  );
}

function OverviewTab() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [agents, setAgents] = useState<Agent[]>([]);

  const load = useCallback(() => {
    fetch("/api/stats").then((r) => r.json()).then(setStats).catch(() => {});
    fetch("/api/agents").then((r) => r.json()).then((d) => setAgents(Array.isArray(d) ? d : [])).catch(() => {});
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  if (!stats) {
    return (
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {Array.from({ length: 8 }).map((_, i) => (
          <Skeleton key={i} className="h-24 rounded-2xl" />
        ))}
      </div>
    );
  }

  const cards = [
    { label: "إجمالي الطلبات", value: formatNumber(stats.orders.total), icon: "📦", bg: "bg-[#FFF3E6]", sub: `${stats.orders.active} نشط الآن` },
    { label: "الإيرادات", value: formatIQD(stats.revenue), icon: "💰", bg: "bg-[#E6F4EA]", sub: "طلبات مكتملة وجارية" },
    { label: "المطاعم", value: formatNumber(stats.stores.restaurants), icon: "🍽️", bg: "bg-[#FFF6DE]", sub: `${stats.stores.stores} متجر · ${stats.stores.markets} سوق` },
    { label: "الوكلاء", value: formatNumber(stats.agents.total), icon: "🛵", bg: "bg-[#FFF6DE]", sub: `${stats.agents.available} متاح الآن` },
  ];

  return (
    <div className="space-y-5">
      {/* بطاقات الإحصائيات */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
        {cards.map((c) => (
          <div key={c.label} className="bg-white rounded-2xl border border-border p-4 anim-in">
            <div className="flex items-center justify-between mb-2">
              <span className={`h-10 w-10 rounded-xl ${c.bg} flex items-center justify-center text-xl`}>{c.icon}</span>
              <TrendingUp className="h-4 w-4 text-[#2E7D32]" />
            </div>
            <div className="font-black text-lg leading-tight">{c.value}</div>
            <div className="text-xs text-muted-foreground">{c.label}</div>
            <div className="text-[11px] text-[#FF6B00] font-bold mt-1">{c.sub}</div>
          </div>
        ))}
      </div>

      <div className="grid lg:grid-cols-2 gap-4">
        {/* أحدث الطلبات */}
        <div className="bg-white rounded-2xl border border-border p-4">
          <h3 className="font-black text-sm mb-3 flex items-center gap-2"><ClipboardList className="h-4 w-4 text-[#FF6B00]" /> أحدث الطلبات</h3>
          {stats.recentOrders.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-6">لا توجد طلبات بعد — أنشئ طلباً من واجهة العميل لتجربة النظام</p>
          ) : (
            <div className="space-y-2.5">
              {stats.recentOrders.map((o: Order) => (
                <div key={o.id} className="flex items-center gap-2.5 text-sm">
                  <span className="h-9 w-9 rounded-xl bg-[#F8F9FA] flex items-center justify-center shrink-0">
                    {o.store?.type === "MARKET" ? "🛒" : o.store?.type === "STORE" ? "🏬" : "🍽️"}
                  </span>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold truncate">{o.store?.name} <span className="text-muted-foreground font-normal text-xs" dir="ltr">{o.code}</span></div>
                    <div className="text-[11px] text-muted-foreground">{formatDate(o.createdAt)} · {o.agent?.name || "لم يُسند وكيل"}</div>
                  </div>
                  <div className="text-left shrink-0">
                    <Badge className={`border-0 text-[10px] ${STATUS_COLORS[o.status as OrderStatus]}`}>{ORDER_STATUS_AR[o.status as OrderStatus]}</Badge>
                    <div className="font-black text-xs mt-0.5">{formatIQD(o.total)}</div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* الأكثر طلباً + حالة الوكلاء */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-border p-4">
            <h3 className="font-black text-sm mb-3 flex items-center gap-2"><Star className="h-4 w-4 text-[#FF6B00]" /> الأكثر طلباً</h3>
            {stats.topStores.every((s) => s._count.orders === 0) ? (
              <p className="text-sm text-muted-foreground text-center py-4">لا توجد بيانات كافية بعد</p>
            ) : (
              <div className="space-y-2">
                {stats.topStores.filter((s) => s._count.orders > 0).map((s, i) => (
                  <div key={s.id} className="flex items-center gap-2.5 text-sm">
                    <span className="font-black text-[#FF6B00] w-5">{i + 1}.</span>
                    <span className="flex-1 truncate font-bold">{s.name}</span>
                    <Badge variant="secondary" className="bg-[#FFF6DE] text-[#111827] border-0">{TYPE_AR[s.type as StoreType]}</Badge>
                    <span className="text-xs text-muted-foreground">{s._count.orders} طلب</span>
                  </div>
                ))}
              </div>
            )}
          </div>

          <div className="bg-white rounded-2xl border border-border p-4">
            <h3 className="font-black text-sm mb-3 flex items-center gap-2"><Bike className="h-4 w-4 text-[#FF6B00]" /> حالة الوكلاء الآن</h3>
            {agents.length === 0 ? (
              <p className="text-sm text-muted-foreground text-center py-4">لا يوجد وكلاء — أضف وكلاء من تبويب الوكلاء</p>
            ) : (
              <div className="flex flex-wrap gap-2">
                {agents.map((a) => (
                  <span key={a.id} className="flex items-center gap-1.5 text-xs font-bold border rounded-full px-2.5 py-1.5">
                    <span>{a.vehicleType === "CAR" ? "🚗" : "🛵"}</span>
                    {a.name}
                    <span className={`h-2 w-2 rounded-full ${a.status === "AVAILABLE" ? "bg-[#2E7D32]" : a.status === "BUSY" ? "bg-[#FFAA00]" : "bg-gray-300"}`} />
                  </span>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export const STATUS_COLORS: Record<OrderStatus, string> = {
  PENDING: "bg-[#FFAA00] text-[#111827]",
  CONFIRMED: "bg-[#FF6B00]",
  PREPARING: "bg-[#111827]",
  DELIVERING: "bg-[#2E7D32]",
  DELIVERED: "bg-[#2E7D32]",
  CANCELLED: "bg-red-500",
};

