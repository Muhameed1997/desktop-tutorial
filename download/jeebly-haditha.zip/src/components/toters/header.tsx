"use client";

// هيدر جيبلي — مساحة أمان علوية: اسم التطبيق أعلى الصفحة
// الإشعارات في أقصى اليسار + زر الحساب — أزرار الضبط/المدير/الوكيل انتقلت للشريط السفلي
import { useState } from "react";
import { Search, MapPin, X, LogIn, Bell, Gift, Truck, Megaphone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useAppStore } from "@/store/app-store";
import { useAuthStore } from "@/store/auth-store";
import Image from "next/image";

interface HeaderProps {
  search: string;
  onSearch: (v: string) => void;
}

const NOTIFICATIONS = [
  {
    icon: Gift,
    title: "مرحباً بك في جيبلي!",
    body: "أول طلب لك بخصم 10% — اطلب من مطاعم حديثة المفضلة",
    time: "الآن",
    tone: "bg-[#FFF3E6] text-[#FF6B00]",
  },
  {
    icon: Truck,
    title: "تتبع مباشر للسائق",
    body: "تابع كابتن التوصيل لحظة بلحظة على خريطة حديثة مع مدة الوصول",
    time: "اليوم",
    tone: "bg-[#FFF6DE] text-[#FFAA00]",
  },
  {
    icon: Megaphone,
    title: "عروض الأسبوع",
    body: "عروض حصرية من المطاعم والمتاجر الشريكة داخل مدينة حديثة",
    time: "أمس",
    tone: "bg-[#E6F4EA] text-[#2E7D32]",
  },
];

export function Header({ search, onSearch }: HeaderProps) {
  const setView = useAppStore((s) => s.setView);
  const goHome = useAppStore((s) => s.goHome);
  const user = useAuthStore((s) => s.user);
  const [openBell, setOpenBell] = useState(false);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-border">
      <div className="max-w-6xl mx-auto px-4">
        {/* الصف الأول: مساحة الأمان العلوية — اسم جيبلي أعلى الصفحة + الإشعارات أقصى اليسار */}
        <div className="safe-top flex items-center gap-2 pt-3 pb-2">
          <button
            onClick={goHome}
            className="flex items-center gap-2.5 shrink-0 group"
            aria-label="الصفحة الرئيسية — جيبلي"
          >
            <Image
              src="/brand/jeebly-icon.png"
              alt="جيبلي Jeebly"
              width={44}
              height={44}
              className="h-10 w-10 sm:h-11 sm:w-11 rounded-2xl shadow-brand transition-transform group-hover:scale-105"
              priority
            />
            {/* اسم التطبيق — اللوقو الرسمي يظهر دائماً في الأعلى */}
            <Image
              src="/brand/jeebly-wordmark-dark.png"
              alt="jeebly | جيبلي"
              width={2463}
              height={501}
              priority
              className="h-6 sm:h-7 w-auto"
            />
          </button>

          {/* شريحة موقع الخدمة */}
          <span className="hidden md:inline-flex items-center gap-1 text-[11px] font-black bg-[#FFF3E6] text-[#FF6B00] border border-[#FF6B00]/25 rounded-full px-3 py-1.5 shrink-0">
            <MapPin className="h-3.5 w-3.5" />
            حديثة – الأنبار
          </span>

          <div className="flex-1" />

          {/* زر الحساب */}
          <Button
            onClick={() => setView({ name: "account" })}
            className={`rounded-full h-10 px-3 shrink-0 font-bold text-xs ${
              user
                ? "bg-[#FFF3E6] text-[#FF6B00] hover:bg-[#FFE3CC] border border-[#FF6B00]/30"
                : "bg-[#FF6B00] hover:bg-[#E85F00] text-white shadow-brand"
            }`}
            aria-label={user ? "حسابي" : "تسجيل الدخول"}
          >
            {user ? (
              <>
                <span className="h-6 w-6 rounded-full bg-[#FF6B00] text-white flex items-center justify-center font-black text-[11px]">
                  {user.name.trim().charAt(0)}
                </span>
                <span className="hidden sm:inline max-w-20 truncate">{user.name}</span>
              </>
            ) : (
              <>
                <LogIn className="h-4 w-4" />
                <span className="hidden sm:inline">دخول</span>
              </>
            )}
          </Button>

          {/* جرس الإشعارات — في أقصى يسار الصفحة */}
          <Popover open={openBell} onOpenChange={setOpenBell}>
            <PopoverTrigger asChild>
              <button
                className="relative h-10 w-10 rounded-full bg-[#F8F9FA] border border-border flex items-center justify-center hover:bg-[#FFF3E6] hover:border-[#FF6B00]/30 transition shrink-0"
                aria-label="الإشعارات"
              >
                <Bell className="h-4.5 w-4.5 text-[#111827]" />
                <span className="absolute top-1.5 end-1.5 h-2.5 w-2.5 rounded-full bg-[#FF6B00] ring-2 ring-white" />
              </button>
            </PopoverTrigger>
            <PopoverContent align="end" className="w-80 p-0 overflow-hidden rounded-2xl" sideOffset={8}>
              <div className="px-4 py-3 bg-[#FFF9F3] border-b border-border flex items-center justify-between">
                <span className="font-black text-sm">الإشعارات</span>
                <span className="text-[10px] font-bold bg-[#FF6B00] text-white rounded-full px-2 py-0.5">
                  3 جديدة
                </span>
              </div>
              <div className="max-h-80 overflow-y-auto divide-y divide-border">
                {NOTIFICATIONS.map((n) => {
                  const Icon = n.icon;
                  return (
                    <div key={n.title} className="flex gap-3 p-3.5 hover:bg-[#F8F9FA] transition">
                      <span className={`h-9 w-9 rounded-xl flex items-center justify-center shrink-0 ${n.tone}`}>
                        <Icon className="h-4 w-4" />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <p className="font-black text-xs truncate">{n.title}</p>
                          <span className="text-[10px] text-muted-foreground shrink-0">{n.time}</span>
                        </div>
                        <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{n.body}</p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </PopoverContent>
          </Popover>
        </div>

        {/* الصف الثاني: البحث */}
        <div className="pb-3">
          <div className="relative">
            <Search className="absolute start-4 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
            <Input
              value={search}
              onChange={(e) => onSearch(e.target.value)}
              placeholder="ابحث عن مطعم أو متجر أو صنف..."
              className="ps-10 h-10 bg-[#F8F9FA] border-[#E5E7EB] rounded-full text-sm focus-visible:ring-[#FF6B00]/30"
              aria-label="بحث"
            />
            {search && (
              <button
                onClick={() => onSearch("")}
                className="absolute end-4 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                aria-label="مسح البحث"
              >
                <X className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
