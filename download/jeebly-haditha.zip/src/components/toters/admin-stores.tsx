"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Plus, Pencil, Trash2, Utensils, PackageOpen, Power, Search, Loader2, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { formatIQD } from "@/lib/format";
import { TYPE_AR, type Store, type StoreItem, type StoreType } from "@/lib/types";

const TYPE_OPTIONS: { value: StoreType; label: string; icon: string }[] = [
  { value: "RESTAURANT", label: "مطعم", icon: "🍽️" },
  { value: "STORE", label: "متجر", icon: "🏬" },
  { value: "MARKET", label: "سوق", icon: "🛒" },
];

const CATEGORY_PRESETS: Record<StoreType, string[]> = {
  RESTAURANT: ["عراقي", "برجر", "بيتزا", "شاورما", "دجاج ومشويات", "أسماك", "حلويات", "قهوة ومشروبات", "فطور صباحي"],
  STORE: ["حلويات ومخبوزات", "عصائر ومثلجات", "بقالة", "إلكترونيات", "ملابس", "صيدلية"],
  MARKET: ["خضار وفواكه", "سوبرماركت", "تمر ومكسرات", "لحوم ودواجن", "منتجات ألبان"],
};

interface StoreForm {
  id?: string;
  name: string;
  description: string;
  type: StoreType;
  category: string;
  imageUrl: string;
  deliveryFee: string;
  deliveryTime: string;
  minOrder: string;
  phone: string;
  address: string;
  lat: string;
  lng: string;
  isOpen: boolean;
  isFeatured: boolean;
}

const EMPTY_FORM: StoreForm = {
  name: "",
  description: "",
  type: "RESTAURANT",
  category: "عراقي",
  imageUrl: "",
  deliveryFee: "1000",
  deliveryTime: "30-45 دقيقة",
  minOrder: "0",
  phone: "",
  address: "",
  lat: "34.1329",
  lng: "42.3775",
  isOpen: true,
  isFeatured: false,
};

export function AdminStoresTab() {
  const [stores, setStores] = useState<Store[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<StoreForm>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Store | null>(null);
  const [menuStore, setMenuStore] = useState<Store | null>(null);
  const [filter, setFilter] = useState<"ALL" | StoreType>("ALL");
  const [search, setSearch] = useState("");

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/stores")
      .then((r) => r.json())
      .then((d) => setStores(Array.isArray(d) ? d : []))
      .catch(() => toast({ title: "خطأ في جلب المتاجر", variant: "destructive" }))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(() => {
    return stores.filter(
      (s) =>
        (filter === "ALL" || s.type === filter) &&
        (!search.trim() || s.name.includes(search.trim()) || s.category.includes(search.trim()))
    );
  }, [stores, filter, search]);

  function openCreate() {
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function openEdit(s: Store) {
    setForm({
      id: s.id,
      name: s.name,
      description: s.description || "",
      type: s.type,
      category: s.category,
      imageUrl: s.imageUrl || "",
      deliveryFee: String(s.deliveryFee),
      deliveryTime: s.deliveryTime,
      minOrder: String(s.minOrder),
      phone: s.phone || "",
      address: s.address || "",
      lat: s.lat != null ? String(s.lat) : "34.1329",
      lng: s.lng != null ? String(s.lng) : "42.3775",
      isOpen: s.isOpen,
      isFeatured: s.isFeatured,
    });
    setDialogOpen(true);
  }

  async function save() {
    if (!form.name.trim()) {
      toast({ title: "اسم المتجر مطلوب", variant: "destructive" });
      return;
    }
    setSaving(true);
    const payload = {
      name: form.name.trim(),
      description: form.description.trim() || null,
      type: form.type,
      category: form.category,
      imageUrl: form.imageUrl.trim() || null,
      deliveryFee: Number(form.deliveryFee) || 0,
      deliveryTime: form.deliveryTime.trim() || "30-45 دقيقة",
      minOrder: Number(form.minOrder) || 0,
      phone: form.phone.trim() || null,
      address: form.address.trim() || null,
      lat: Number(form.lat) || 34.1329,
      lng: Number(form.lng) || 42.3775,
      isOpen: form.isOpen,
      isFeatured: form.isFeatured,
    };
    try {
      const res = await fetch(form.id ? `/api/stores/${form.id}` : "/api/stores", {
        method: form.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error);
      toast({ title: form.id ? "تم تعديل المتجر ✅" : "تمت إضافة المتجر ✅" });
      setDialogOpen(false);
      load();
    } catch (e) {
      toast({ title: "خطأ في الحفظ", description: e instanceof Error ? e.message : "حاول مجدداً", variant: "destructive" });
    }
    setSaving(false);
  }

  async function toggleOpen(s: Store) {
    await fetch(`/api/stores/${s.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isOpen: !s.isOpen }),
    });
    toast({ title: !s.isOpen ? `${s.name}: مفتوح الآن 🟢` : `${s.name}: مغلق الآن 🔴` });
    load();
  }

  async function remove() {
    if (!deleteTarget) return;
    await fetch(`/api/stores/${deleteTarget.id}`, { method: "DELETE" });
    toast({ title: `تم حذف "${deleteTarget.name}"` });
    setDeleteTarget(null);
    load();
  }

  return (
    <div className="space-y-4">
      {/* شريط الأدوات */}
      <div className="flex flex-wrap items-center gap-2">
        <Select value={filter} onValueChange={(v) => setFilter(v as "ALL" | StoreType)}>
          <SelectTrigger className="w-36 rounded-full bg-white h-10">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">كل الأنواع</SelectItem>
            {TYPE_OPTIONS.map((t) => (
              <SelectItem key={t.value} value={t.value}>{t.icon} {t.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <div className="relative flex-1 min-w-40">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث بالاسم أو التصنيف..." className="ps-9 rounded-full bg-white h-10" />
        </div>
        <Button className="rounded-full bg-[#FF6B00] hover:bg-[#E85F00] h-10 px-4 font-bold" onClick={openCreate}>
          <Plus className="h-4 w-4 me-1.5" /> إضافة متجر
        </Button>
      </div>

      {/* القائمة */}
      {loading ? (
        <div className="grid sm:grid-cols-2 gap-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-28 rounded-2xl" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 text-center border border-dashed border-[#FFAA00]">
          <div className="text-4xl mb-2">🏪</div>
          <p className="font-bold">لا توجد متاجر مطابقة</p>
          <p className="text-sm text-muted-foreground mt-1">اضغط «إضافة متجر» لإنشاء أول مطعم أو متجر أو سوق</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 gap-3">
          {filtered.map((s) => (
            <div key={s.id} className="bg-white rounded-2xl border border-border p-3.5 flex gap-3">
              <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 bg-[#F8F9FA]">
                <img src={s.imageUrl || (s.type === "MARKET" ? "/placeholder-market.svg" : s.type === "STORE" ? "/placeholder-store.svg" : "/placeholder-restaurant.svg")} alt={s.name} className="w-full h-full object-cover" />
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5 flex-wrap">
                  <h4 className="font-black text-sm truncate">{s.name}</h4>
                  <Badge className={`border-0 text-[10px] ${s.type === "MARKET" ? "bg-[#E6F4EA] text-[#2E7D32]" : s.type === "STORE" ? "bg-[#FFF6DE] text-[#B45309]" : "bg-[#FFF3E6] text-[#E85F00]"}`}>{TYPE_AR[s.type]}</Badge>
                  {s.isFeatured && <Badge className="border-0 text-[10px] bg-[#FFF6DE] text-[#B45309]"><Star className="h-2.5 w-2.5 me-0.5 fill-current" /> رواج</Badge>}
                </div>
                <p className="text-[11px] text-muted-foreground mt-0.5 truncate">{s.category} · {s.deliveryTime} · توصيل {formatIQD(s.deliveryFee)} · {s.items?.length || 0} صنف</p>
                <div className="flex items-center gap-1.5 mt-2">
                  <Button size="sm" variant="outline" className="h-7 rounded-full text-[11px] px-2.5" onClick={() => openEdit(s)}>
                    <Pencil className="h-3 w-3 me-1" /> تعديل
                  </Button>
                  <Button size="sm" variant="outline" className="h-7 rounded-full text-[11px] px-2.5" onClick={() => setMenuStore(s)}>
                    <Utensils className="h-3 w-3 me-1" /> المنيو ({s.items?.length || 0})
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className={`h-7 rounded-full text-[11px] px-2.5 ${s.isOpen ? "text-[#2E7D32]" : "text-red-500"}`}
                    onClick={() => toggleOpen(s)}
                  >
                    <Power className="h-3 w-3 me-1" /> {s.isOpen ? "مفتوح" : "مغلق"}
                  </Button>
                  <Button size="sm" variant="outline" className="h-7 w-7 rounded-full p-0 text-red-500 hover:bg-red-50" onClick={() => setDeleteTarget(s)} aria-label={`حذف ${s.name}`}>
                    <Trash2 className="h-3.5 w-3.5" />
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* نافذة الإضافة/التعديل */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-lg max-h-[88vh] overflow-y-auto nice-scroll">
          <DialogHeader>
            <DialogTitle className="font-black">{form.id ? `تعديل: ${form.name}` : "إضافة متجر جديد"}</DialogTitle>
            <DialogDescription>أضف مطعماً أو متجراً أو سوقاً وسيظهر مباشرة في واجهة العملاء</DialogDescription>
          </DialogHeader>
          <div className="space-y-3.5">
            <div className="space-y-1.5">
              <Label>نوع المتجر *</Label>
              <div className="grid grid-cols-3 gap-2">
                {TYPE_OPTIONS.map((t) => (
                  <button
                    key={t.value}
                    type="button"
                    onClick={() => { setForm((f) => ({ ...f, type: t.value, category: CATEGORY_PRESETS[t.value][0] })); }}
                    className={`rounded-xl border p-2.5 text-center text-xs font-bold transition ${form.type === t.value ? "border-[#FF6B00] bg-[#FFF3E6]" : "border-border hover:border-[#FFAA00]"}`}
                  >
                    <div className="text-lg">{t.icon}</div>
                    {t.label}
                  </button>
                ))}
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="st-name">الاسم *</Label>
                <Input id="st-name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="مثال: بيت الكبابي" className="bg-[#F8F9FA]" />
              </div>
              <div className="space-y-1.5">
                <Label>التصنيف</Label>
                <Select value={form.category} onValueChange={(v) => setForm((f) => ({ ...f, category: v }))}>
                  <SelectTrigger className="bg-[#F8F9FA]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {CATEGORY_PRESETS[form.type].map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="st-desc">الوصف</Label>
              <Textarea id="st-desc" value={form.description} onChange={(e) => setForm((f) => ({ ...f, description: e.target.value }))} placeholder="وصف قصير يظهر للعملاء..." className="bg-[#F8F9FA] min-h-16" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="st-img">رابط صورة المتجر</Label>
              <Input id="st-img" value={form.imageUrl} onChange={(e) => setForm((f) => ({ ...f, imageUrl: e.target.value }))} placeholder="https://... (اتركه فارغاً لاستخدام صورة افتراضية)" dir="ltr" className="bg-[#F8F9FA] text-left text-xs" />
              {form.imageUrl.trim() && (
                <div className="h-24 w-40 rounded-xl overflow-hidden border">
                  <img src={form.imageUrl} alt="معاينة" className="w-full h-full object-cover" />
                </div>
              )}
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="st-fee">أجرة التوصيل (د.ع)</Label>
                <Input id="st-fee" type="number" value={form.deliveryFee} onChange={(e) => setForm((f) => ({ ...f, deliveryFee: e.target.value }))} className="bg-[#F8F9FA]" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="st-min">أدنى طلب (د.ع)</Label>
                <Input id="st-min" type="number" value={form.minOrder} onChange={(e) => setForm((f) => ({ ...f, minOrder: e.target.value }))} className="bg-[#F8F9FA]" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="st-time">وقت التوصيل</Label>
                <Input id="st-time" value={form.deliveryTime} onChange={(e) => setForm((f) => ({ ...f, deliveryTime: e.target.value }))} className="bg-[#F8F9FA]" />
              </div>
            </div>
            <div className="grid sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="st-phone">هاتف المتجر</Label>
                <Input id="st-phone" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} placeholder="07XXXXXXXXX" dir="ltr" className="bg-[#F8F9FA] text-left" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="st-addr">العنوان</Label>
                <Input id="st-addr" value={form.address} onChange={(e) => setForm((f) => ({ ...f, address: e.target.value }))} placeholder="حديثة – حي المعلمين" className="bg-[#F8F9FA]" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="st-lat">خط العرض (Lat) — خريطة حديثة</Label>
                <Input id="st-lat" type="number" step="0.0001" value={form.lat} onChange={(e) => setForm((f) => ({ ...f, lat: e.target.value }))} dir="ltr" className="bg-[#F8F9FA] text-left text-xs" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="st-lng">خط الطول (Lng) — خريطة حديثة</Label>
                <Input id="st-lng" type="number" step="0.0001" value={form.lng} onChange={(e) => setForm((f) => ({ ...f, lng: e.target.value }))} dir="ltr" className="bg-[#F8F9FA] text-left text-xs" />
              </div>
            </div>
            <div className="flex items-center justify-between rounded-xl border p-3">
              <Label htmlFor="st-open" className="cursor-pointer">المتجر مفتوح لاستقبال الطلبات</Label>
              <Switch id="st-open" checked={form.isOpen} onCheckedChange={(v) => setForm((f) => ({ ...f, isOpen: v }))} />
            </div>
            <div className="flex items-center justify-between rounded-xl border p-3">
              <Label htmlFor="st-feat" className="cursor-pointer">عرضه ضمن «الأكثر رواجاً»</Label>
              <Switch id="st-feat" checked={form.isFeatured} onCheckedChange={(v) => setForm((f) => ({ ...f, isFeatured: v }))} />
            </div>
            <Button className="w-full rounded-full bg-[#FF6B00] hover:bg-[#E85F00] h-11 font-black" onClick={save} disabled={saving}>
              {saving && <Loader2 className="h-4 w-4 animate-spin me-2" />}
              {form.id ? "حفظ التعديلات" : "إضافة المتجر"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* إدارة المنيو */}
      <MenuManager store={menuStore} onClose={() => setMenuStore(null)} onChanged={load} />

      {/* تأكيد الحذف */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف «{deleteTarget?.name}»؟</AlertDialogTitle>
            <AlertDialogDescription>
              سيتم حذف المتجر وكل أصنافه نهائياً. لا يمكن التراجع عن هذا الإجراء.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction className="bg-red-500 hover:bg-red-600" onClick={remove}>نعم، احذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

// ===== إدارة أصناف المنيو لمتجر معين =====
function MenuManager({ store, onClose, onChanged }: { store: Store | null; onClose: () => void; onChanged: () => void }) {
  const [items, setItems] = useState<StoreItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [desc, setDesc] = useState("");
  const [section, setSection] = useState("الأطباق الرئيسية");
  const [imageUrl, setImgUrl] = useState("");
  const [popular, setPopular] = useState(false);
  const [saving, setSaving] = useState(false);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  const reload = useCallback(() => {
    if (!store) return;
    setLoading(true);
    fetch(`/api/stores/${store.id}`)
      .then((r) => r.json())
      .then((d) => setItems(Array.isArray(d.items) ? d.items : []))
      .finally(() => setLoading(false));
  }, [store]);

  useEffect(() => {
    reload();
  }, [reload]);

  const sections = useMemo(() => Array.from(new Set(items.map((i) => i.section))), [items]);

  async function addItem() {
    if (!store || !name.trim() || !price) {
      toast({ title: "الاسم والسعر مطلوبان", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch("/api/menu-items", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          storeId: store.id,
          name: name.trim(),
          description: desc.trim() || null,
          price: Number(price),
          section: section.trim() || "الأطباق الرئيسية",
          imageUrl: imageUrl.trim() || null,
          isPopular: popular,
        }),
      });
      if (!res.ok) throw new Error();
      toast({ title: "تمت إضافة الصنف ✅" });
      setName(""); setPrice(""); setDesc(""); setImgUrl(""); setPopular(false);
      reload();
      onChanged();
    } catch {
      toast({ title: "تعذر إضافة الصنف", variant: "destructive" });
    }
    setSaving(false);
  }

  async function toggleAvailable(it: StoreItem) {
    await fetch(`/api/menu-items/${it.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isAvailable: !it.isAvailable }),
    });
    reload();
  }

  async function removeItem() {
    if (!deleteId) return;
    await fetch(`/api/menu-items/${deleteId}`, { method: "DELETE" });
    setDeleteId(null);
    reload();
    onChanged();
  }

  return (
    <>
      <Dialog open={!!store} onOpenChange={(o) => !o && onClose()}>
        <DialogContent className="max-w-2xl max-h-[88vh] overflow-hidden flex flex-col">
          <DialogHeader>
            <DialogTitle className="font-black flex items-center gap-2">
              <Utensils className="h-5 w-5 text-[#FF6B00]" />
              منيو «{store?.name}»
            </DialogTitle>
            <DialogDescription>أضف الأطباق أو المنتجات وأسعارها — ستظهر فوراً للعملاء</DialogDescription>
          </DialogHeader>

          {/* نموذج إضافة صنف */}
          <div className="rounded-2xl border bg-[#F8F9FA] p-3.5 space-y-3">
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              <div className="col-span-2 space-y-1">
                <Label htmlFor="mi-name" className="text-xs">اسم الصنف *</Label>
                <Input id="mi-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="مثال: كباب مشكل" className="bg-white h-9" />
              </div>
              <div className="space-y-1">
                <Label htmlFor="mi-price" className="text-xs">السعر (د.ع) *</Label>
                <Input id="mi-price" type="number" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="5000" className="bg-white h-9" />
              </div>
              <div className="space-y-1">
                <Label htmlFor="mi-sec" className="text-xs">القسم</Label>
                <Input id="mi-sec" value={section} onChange={(e) => setSection(e.target.value)} list="sections-list" className="bg-white h-9" />
                <datalist id="sections-list">
                  {["المقبلات", "الأطباق الرئيسية", "المشروبات", "الحلويات", ...sections].map((s) => (
                    <option key={s} value={s} />
                  ))}
                </datalist>
              </div>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
              <div className="sm:col-span-2 space-y-1">
                <Label htmlFor="mi-img" className="text-xs">رابط صورة الصنف (اختياري)</Label>
                <Input id="mi-img" value={imageUrl} onChange={(e) => setImgUrl(e.target.value)} dir="ltr" className="bg-white h-9 text-left text-xs" placeholder="https://..." />
              </div>
              <div className="flex items-end pb-0.5">
                <label className="flex items-center gap-2 text-xs font-bold cursor-pointer">
                  <Switch checked={popular} onCheckedChange={setPopular} /> الأكثر طلباً 🔥
                </label>
              </div>
            </div>
            <div className="space-y-1">
              <Label htmlFor="mi-desc" className="text-xs">وصف قصير (اختياري)</Label>
              <Input id="mi-desc" value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="المكونات أو التفاصيل..." className="bg-white h-9" />
            </div>
            <Button className="w-full rounded-full bg-[#FF6B00] hover:bg-[#E85F00] h-9 font-bold" onClick={addItem} disabled={saving}>
              {saving ? <Loader2 className="h-4 w-4 animate-spin me-1.5" /> : <Plus className="h-4 w-4 me-1.5" />}
              إضافة الصنف للمنيو
            </Button>
          </div>

          {/* قائمة الأصناف */}
          <div className="flex-1 overflow-y-auto nice-scroll mt-3 max-h-[42vh]">
            {loading ? (
              <p className="text-center text-sm text-muted-foreground py-6">جاري التحميل...</p>
            ) : items.length === 0 ? (
              <div className="text-center py-8">
                <PackageOpen className="h-10 w-10 mx-auto text-[#FFAA00] mb-2" />
                <p className="text-sm text-muted-foreground">لا توجد أصناف بعد — أضف أول صنف من الأعلى</p>
              </div>
            ) : (
              <div className="space-y-2 pe-1">
                {items.map((it) => (
                  <div key={it.id} className="flex items-center gap-2.5 bg-white border rounded-xl p-2.5">
                    <div className="w-11 h-11 rounded-lg overflow-hidden bg-[#F8F9FA] shrink-0">
                      <img src={it.imageUrl || "/placeholder-restaurant.svg"} alt={it.name} className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-1.5">
                        <span className="font-bold text-sm truncate">{it.name}</span>
                        {it.isPopular && <span className="text-[9px] bg-[#FFF3E6] text-[#FF6B00] px-1 rounded font-bold">🔥</span>}
                      </div>
                      <span className="text-[11px] text-muted-foreground">{it.section}</span>
                    </div>
                    <span className="font-black text-sm text-[#FF6B00] whitespace-nowrap">{formatIQD(it.price)}</span>
                    <Button size="sm" variant="outline" className={`h-7 rounded-full px-2 text-[10px] ${it.isAvailable ? "text-[#2E7D32]" : "text-red-500"}`} onClick={() => toggleAvailable(it)}>
                      {it.isAvailable ? "متوفر" : "نافذ"}
                    </Button>
                    <Button size="sm" variant="outline" className="h-7 w-7 rounded-full p-0 text-red-500" onClick={() => setDeleteId(it.id)} aria-label={`حذف ${it.name}`}>
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الصنف؟</AlertDialogTitle>
            <AlertDialogDescription>سيُحذف الصنف من المنيو نهائياً.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction className="bg-red-500 hover:bg-red-600" onClick={removeItem}>احذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
