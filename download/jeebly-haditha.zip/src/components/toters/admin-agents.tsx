"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { Plus, Pencil, Trash2, Car, Bike, Search, Loader2, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from "@/components/ui/alert-dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "@/hooks/use-toast";
import { AGENT_STATUS_AR, VEHICLE_AR, type Agent, type AgentStatus, type AgentVehicle } from "@/lib/types";

interface AgentForm {
  id?: string;
  name: string;
  phone: string;
  vehicleType: AgentVehicle;
  vehiclePlate: string;
  status: AgentStatus;
}

const EMPTY_FORM: AgentForm = {
  name: "",
  phone: "",
  vehicleType: "MOTORCYCLE",
  vehiclePlate: "",
  status: "AVAILABLE",
};

export function AdminAgentsTab() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [form, setForm] = useState<AgentForm>(EMPTY_FORM);
  const [saving, setSaving] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<Agent | null>(null);
  const [search, setSearch] = useState("");
  const [vehicleFilter, setVehicleFilter] = useState<"ALL" | AgentVehicle>("ALL");

  const load = useCallback(() => {
    setLoading(true);
    fetch("/api/agents")
      .then((r) => r.json())
      .then((d) => setAgents(Array.isArray(d) ? d : []))
      .catch(() => toast({ title: "خطأ في جلب الوكلاء", variant: "destructive" }))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const filtered = useMemo(
    () =>
      agents.filter(
        (a) =>
          (vehicleFilter === "ALL" || a.vehicleType === vehicleFilter) &&
          (!search.trim() || a.name.includes(search.trim()) || a.phone.includes(search.trim()))
      ),
    [agents, vehicleFilter, search]
  );

  function openCreate() {
    setForm(EMPTY_FORM);
    setDialogOpen(true);
  }

  function openEdit(a: Agent) {
    setForm({
      id: a.id,
      name: a.name,
      phone: a.phone,
      vehicleType: a.vehicleType,
      vehiclePlate: a.vehiclePlate || "",
      status: a.status,
    });
    setDialogOpen(true);
  }

  async function save() {
    if (!form.name.trim() || !form.phone.trim()) {
      toast({ title: "الاسم ورقم الهاتف مطلوبان", variant: "destructive" });
      return;
    }
    if (!/^07\d{9}$/.test(form.phone.trim().replace(/\s/g, ""))) {
      toast({ title: "رقم هاتف غير صحيح", description: "أدخل رقم عراقي يبدأ بـ 07 ويتكون من 11 رقم", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const res = await fetch(form.id ? `/api/agents/${form.id}` : "/api/agents", {
        method: form.id ? "PATCH" : "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: form.name.trim(),
          phone: form.phone.trim(),
          vehicleType: form.vehicleType,
          vehiclePlate: form.vehiclePlate.trim() || null,
          status: form.status,
        }),
      });
      if (!res.ok) throw new Error();
      toast({ title: form.id ? "تم تعديل الوكيل ✅" : "تمت إضافة الوكيل ✅" });
      setDialogOpen(false);
      load();
    } catch {
      toast({ title: "خطأ في الحفظ", variant: "destructive" });
    }
    setSaving(false);
  }

  async function remove() {
    if (!deleteTarget) return;
    await fetch(`/api/agents/${deleteTarget.id}`, { method: "DELETE" });
    toast({ title: `تم حذف الوكيل «${deleteTarget.name}»` });
    setDeleteTarget(null);
    load();
  }

  const statusDot: Record<AgentStatus, string> = {
    AVAILABLE: "bg-[#2E7D32]",
    BUSY: "bg-[#FFAA00]",
    OFFLINE: "bg-gray-300",
  };

  return (
    <div className="space-y-4">
      {/* شريط الأدوات */}
      <div className="flex flex-wrap items-center gap-2">
        <div className="flex gap-1.5">
          {(["ALL", "MOTORCYCLE", "CAR"] as const).map((v) => (
            <button
              key={v}
              onClick={() => setVehicleFilter(v)}
              className={`px-3.5 py-2 rounded-full text-xs font-bold border transition ${vehicleFilter === v ? "bg-[#FF6B00] text-white border-transparent" : "bg-white border-border hover:border-[#FFAA00]"}`}
            >
              {v === "ALL" ? "الكل" : v === "CAR" ? "🚗 سيارة" : "🛵 دراجة"}
            </button>
          ))}
        </div>
        <div className="relative flex-1 min-w-40">
          <Search className="absolute start-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="ابحث بالاسم أو الهاتف..." className="ps-9 rounded-full bg-white h-10" />
        </div>
        <Button className="rounded-full bg-[#FF6B00] hover:bg-[#E85F00] h-10 px-4 font-bold" onClick={openCreate}>
          <Plus className="h-4 w-4 me-1.5" /> إضافة وكيل
        </Button>
      </div>

      {/* القائمة */}
      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-36 rounded-2xl" />)}</div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-2xl p-10 text-center border border-dashed border-[#FFAA00]">
          <div className="text-4xl mb-2">🛵</div>
          <p className="font-bold">لا يوجد وكلاء</p>
          <p className="text-sm text-muted-foreground mt-1">أضف وكلاء التوصيل (سيارة أو دراجة) ليقوموا بتوصيل الطلبات</p>
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((a) => (
            <div key={a.id} className="bg-white rounded-2xl border border-border p-4 anim-in">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <span className={`h-12 w-12 rounded-2xl flex items-center justify-center text-2xl ${a.vehicleType === "CAR" ? "bg-[#E6F4EA]" : "bg-[#FFF3E6]"}`}>
                    {a.vehicleType === "CAR" ? "🚗" : "🛵"}
                  </span>
                  <div>
                    <div className="font-black text-sm">{a.name}</div>
                    <div className="text-[11px] text-muted-foreground flex items-center gap-1" dir="ltr">
                      <Phone className="h-3 w-3" /> {a.phone}
                    </div>
                  </div>
                </div>
                <span className="flex items-center gap-1 text-[10px] font-bold">
                  <span className={`h-2 w-2 rounded-full ${statusDot[a.status]}`} />
                  {AGENT_STATUS_AR[a.status]}
                </span>
              </div>

              <div className="mt-3 flex flex-wrap gap-1.5 text-[10px]">
                <Badge variant="secondary" className="bg-[#F8F9FA] border">{VEHICLE_AR[a.vehicleType]}</Badge>
                {a.vehiclePlate && <Badge variant="secondary" className="bg-[#F8F9FA] border" dir="ltr">{a.vehiclePlate}</Badge>}
                <Badge variant="secondary" className="bg-[#F8F9FA] border">⭐ {a.rating.toFixed(1)}</Badge>
                <Badge variant="secondary" className="bg-[#E6F4EA] text-[#2E7D32] border-0">{a.totalDeliveries} توصيلة</Badge>
                {(a.orders?.length || 0) > 0 && (
                  <Badge className="bg-[#FFF3E6] text-[#FF6B00] border-0">{a.orders!.length} طلب جاري</Badge>
                )}
              </div>

              <div className="flex gap-1.5 mt-3">
                <Button size="sm" variant="outline" className="h-7 rounded-full text-[11px] px-3 flex-1" onClick={() => openEdit(a)}>
                  <Pencil className="h-3 w-3 me-1" /> تعديل
                </Button>
                <Button size="sm" variant="outline" className="h-7 w-7 rounded-full p-0 text-red-500" onClick={() => setDeleteTarget(a)} aria-label={`حذف ${a.name}`}>
                  <Trash2 className="h-3 w-3" />
                </Button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* نافذة الإضافة/التعديل */}
      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="font-black">{form.id ? `تعديل الوكيل: ${form.name}` : "إضافة وكيل توصيل جديد"}</DialogTitle>
            <DialogDescription>الوكلاء هم الكباتن الذين يوصلون الطلبات — سيارة أو دراجة</DialogDescription>
          </DialogHeader>
          <div className="space-y-3.5">
            <div className="space-y-1.5">
              <Label>نوع المركبة *</Label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, vehicleType: "MOTORCYCLE" }))}
                  className={`rounded-xl border p-3 text-center transition ${form.vehicleType === "MOTORCYCLE" ? "border-[#FF6B00] bg-[#FFF3E6]" : "border-border hover:border-[#FFAA00]"}`}
                >
                  <div className="text-2xl mb-0.5">🛵</div>
                  <div className="text-xs font-bold">دراجة نارية</div>
                </button>
                <button
                  type="button"
                  onClick={() => setForm((f) => ({ ...f, vehicleType: "CAR" }))}
                  className={`rounded-xl border p-3 text-center transition ${form.vehicleType === "CAR" ? "border-[#FF6B00] bg-[#FFF3E6]" : "border-border hover:border-[#FFAA00]"}`}
                >
                  <div className="text-2xl mb-0.5">🚗</div>
                  <div className="text-xs font-bold">سيارة</div>
                </button>
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="ag-name">الاسم *</Label>
                <Input id="ag-name" value={form.name} onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))} placeholder="مثال: علي حسين" className="bg-[#F8F9FA]" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="ag-phone">الهاتف *</Label>
                <Input id="ag-phone" value={form.phone} onChange={(e) => setForm((f) => ({ ...f, phone: e.target.value }))} placeholder="07XXXXXXXXX" dir="ltr" className="bg-[#F8F9FA] text-left" inputMode="tel" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="ag-plate">رقم اللوحة</Label>
                <Input id="ag-plate" value={form.vehiclePlate} onChange={(e) => setForm((f) => ({ ...f, vehiclePlate: e.target.value }))} placeholder="بغداد 12345" className="bg-[#F8F9FA]" />
              </div>
              <div className="space-y-1.5">
                <Label>الحالة</Label>
                <Select value={form.status} onValueChange={(v) => setForm((f) => ({ ...f, status: v as AgentStatus }))}>
                  <SelectTrigger className="bg-[#F8F9FA]"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="AVAILABLE">🟢 متاح</SelectItem>
                    <SelectItem value="BUSY">🟡 مشغول</SelectItem>
                    <SelectItem value="OFFLINE">⚪ غير متصل</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button className="w-full rounded-full bg-[#FF6B00] hover:bg-[#E85F00] h-11 font-black" onClick={save} disabled={saving}>
              {saving && <Loader2 className="h-4 w-4 animate-spin me-2" />}
              {form.id ? "حفظ التعديلات" : "إضافة الوكيل"}
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* تأكيد الحذف */}
      <AlertDialog open={!!deleteTarget} onOpenChange={(o) => !o && setDeleteTarget(null)}>
        <AlertDialogContent dir="rtl">
          <AlertDialogHeader>
            <AlertDialogTitle>حذف الوكيل «{deleteTarget?.name}»؟</AlertDialogTitle>
            <AlertDialogDescription>سيتم إزالة الوكيل من فريق التوصيل. الطلبات المسندة له ستبقى في السجل.</AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>إلغاء</AlertDialogCancel>
            <AlertDialogAction className="bg-red-500 hover:bg-red-600" onClick={remove}>نعم، احذف</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
