"use client";

import { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import {
  ArrowRight,
  Banknote,
  BadgeCheck,
  CreditCard,
  Loader2,
  MapPin,
  Navigation,
  Phone,
  ShieldCheck,
  ShoppingBag,
  StickyNote,
  User,
  UserPlus,
  LocateFixed,
  Pencil,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { toast } from "@/hooks/use-toast";
import { formatIQD } from "@/lib/format";
import { formatPhoneDisplay } from "@/lib/phone";
import { HADITHA_AREAS, HADITHA_BOUNDS, HADITHA_CENTER } from "@/lib/geo";
import { useAppStore, cartSubtotal } from "@/store/app-store";
import { useAuthStore } from "@/store/auth-store";
import type { Order } from "@/lib/types";
import HadithaMap, { type MapPoint } from "@/components/toters/haditha-map";

export function CheckoutView() {
  const { cart, cartStoreId, cartStoreName, cartStoreFee, updateQty, clearCart, setView, setLastOrderCode } =
    useAppStore();
  const user = useAuthStore((s) => s.user);

  const [area, setArea] = useState<string>(HADITHA_AREAS[0]);
  const [details, setDetails] = useState<string | null>(null);
  const [notes, setNotes] = useState("");
  const [pin, setPin] = useState<MapPoint>(HADITHA_CENTER);
  const [payment, setPayment] = useState<"CASH" | "CARD">("CASH");
  const [submitting, setSubmitting] = useState(false);

  // تحديد الموقع: تلقائي (GPS) أو يدوي إذا لم يُفعّل المستخدم GPS
  const [locating, setLocating] = useState(false);
  const [geoMode, setGeoMode] = useState<"idle" | "auto" | "manual">("idle");

  const detailsVal = details ?? "";
  const subtotal = useMemo(() => cartSubtotal(cart), [cart]);
  const fee = cart.length > 0 ? cartStoreFee : 0;
  const total = subtotal + fee;
  const address = `حديثة – ${area}${detailsVal.trim() ? ` – ${detailsVal.trim()}` : ""}`;

  if (!user) {
    // بوابة الحساب: الطلب يتطلب حساباً — بالهاتف فقط عبر رمز التحقق
    return (
      <div className="max-w-xl mx-auto px-4 pb-32 pt-8">
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-white rounded-3xl border border-border p-8 text-center"
        >
          <div className="h-16 w-16 rounded-2xl brand-gradient mx-auto flex items-center justify-center mb-4">
            <UserPlus className="h-8 w-8 text-white" />
          </div>
          <h1 className="text-xl font-black mb-2">سجّل برقم هاتفك لإتمام طلبك</h1>
          <p className="text-sm text-muted-foreground mb-1">
            سلتك محفوظة — أدخل رقم هاتفك العراقي واستلم رمز التحقق، بدون كلمة مرور
          </p>
          <p className="text-xs text-muted-foreground mb-5">التسجيل يستغرق أقل من دقيقة ⚡</p>
          <div className="flex flex-col sm:flex-row gap-2 justify-center">
            <Button className="rounded-full bg-[#FF6B00] hover:bg-[#E85F00] px-6 h-11 font-black" onClick={() => setView({ name: "account" })}>
              <UserPlus className="h-4.5 w-4.5 me-1.5" /> إنشاء حساب / دخول
            </Button>
            <Button variant="outline" className="rounded-full px-6 h-11 font-bold" onClick={() => setView({ name: "home" })}>
              متابعة التصفح
            </Button>
          </div>
        </motion.div>
      </div>
    );
  }

  if (cart.length === 0) {
    return (
      <div className="max-w-2xl mx-auto px-4 pb-32 pt-16 text-center">
        <div className="text-6xl mb-4">🛒</div>
        <p className="font-black text-lg">سلتك فارغة</p>
        <p className="text-sm text-muted-foreground mt-1 mb-5">أضف أصنافاً من أي مطعم أو متجر لتبدأ الطلب</p>
        <Button className="rounded-full bg-[#FF6B00] hover:bg-[#FF6B00]/90 px-6" onClick={() => setView({ name: "home" })}>
          تصفح المتاجر
        </Button>
      </div>
    );
  }

  // ===== تحديد الموقع تلقائياً عبر GPS — مع خطة يدوية عند الرفض =====
  function autoLocate() {
    if (!("geolocation" in navigator)) {
      setGeoMode("manual");
      toast({
        title: "خدمة الموقع غير مدعومة على جهازك",
        description: "حدد منزلك يدوياً: اختر الحي ثم انقر على الخريطة",
        variant: "destructive",
      });
      return;
    }
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setLocating(false);
        const { latitude, longitude } = pos.coords;
        // داخل نطاق مدينة حديثة؟ (بهامش صغير)
        const margin = 0.02;
        const inHaditha =
          latitude >= HADITHA_BOUNDS[0][0] - margin &&
          latitude <= HADITHA_BOUNDS[1][0] + margin &&
          longitude >= HADITHA_BOUNDS[0][1] - margin &&
          longitude <= HADITHA_BOUNDS[1][1] + margin;
        if (inHaditha) {
          setPin({ lat: latitude, lng: longitude });
          setGeoMode("auto");
          toast({ title: "تم تحديد موقعك تلقائياً ✅", description: "يمكنك ضبطه بدقة أكبر بالنقر على الخريطة" });
        } else {
          setGeoMode("manual");
          toast({
            title: "أنت خارج نطاق خدمة حديثة",
            description: "حدد منزلك داخل المدينة يدوياً: اختر الحي ثم انقر على الخريطة",
            variant: "destructive",
          });
        }
      },
      () => {
        // رفض الإذن أو تعذر الوصول إلى GPS → الوضع اليدوي
        setLocating(false);
        setGeoMode("manual");
        toast({
          title: "لم نتمكن من الوصول إلى موقعك (GPS)",
          description: "لا مشكلة — حدد منزلك يدوياً: اختر الحي ثم انقر على الخريطة 📍",
        });
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  }

  async function submitOrder() {
    // بيانات المستلم تؤخذ تلقائياً من الحساب — لا إدخال يدوي
    const nameVal = user.name.trim();
    const phoneVal = (user.phone || "").trim();

    if (!/^07\d{9}$/.test(phoneVal)) {
      toast({
        title: "رقم هاتف حسابك غير مكتمل",
        description: "حدّث حسابك برقم عراقي صحيح من صفحة الحساب",
        variant: "destructive",
      });
      return;
    }
    if (!detailsVal.trim()) {
      toast({ title: "العنوان ناقص", description: "أضف أقرب نقطة دالة أو رقم الشارع", variant: "destructive" });
      return;
    }
    setSubmitting(true);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          storeId: cartStoreId,
          customerName: nameVal,
          customerPhone: phoneVal,
          address,
          notes: notes || undefined,
          paymentMethod: payment,
          destLat: pin.lat,
          destLng: pin.lng,
          items: cart.map((l) => ({ name: l.name, price: l.price, quantity: l.quantity })),
        }),
      });
      const data = (await res.json()) as Order & { error?: string };
      if (!res.ok) {
        toast({ title: "تعذر إنشاء الطلب", description: data.error || "حدث خطأ غير متوقع", variant: "destructive" });
        setSubmitting(false);
        return;
      }
      clearCart();
      setLastOrderCode(data.code);
      toast({ title: "تم إرسال طلبك! 🎉", description: `رقم الطلب ${data.code} — تابع السائق على الخريطة الآن` });
      setView({ name: "track", code: data.code });
    } catch {
      toast({ title: "خطأ بالشبكة", description: "تحقق من اتصالك وحاول مجدداً", variant: "destructive" });
    }
    setSubmitting(false);
  }

  return (
    <div className="max-w-6xl mx-auto px-4 pb-32 pt-4">
      <button
        onClick={() => setView({ name: "home" })}
        className="flex items-center gap-1.5 text-sm font-bold text-muted-foreground hover:text-[#FF6B00] transition mb-3"
      >
        <ArrowRight className="h-4 w-4" /> رجوع
      </button>
      <h1 className="text-xl font-black mb-4 flex items-center gap-2">
        <ShoppingBag className="h-5 w-5 text-[#FF6B00]" />
        إتمام الطلب — {cartStoreName}
      </h1>

      <div className="grid lg:grid-cols-5 gap-4 items-start">
        <div className="lg:col-span-3 space-y-4">
          {/* بيانات المستلم — تلقائياً من الحساب (بدون إدخال) */}
          <div className="bg-white rounded-2xl border border-border p-4 space-y-3">
            <div className="flex items-center justify-between gap-2 flex-wrap">
              <h2 className="font-black text-sm flex items-center gap-2">
                <User className="h-4 w-4 text-[#FF6B00]" /> بيانات المستلم
              </h2>
              <span className="text-[10px] font-black text-[#2E7D32] bg-[#E6F4EA] rounded-full px-2 py-1 flex items-center gap-1">
                <BadgeCheck className="h-3 w-3" /> تلقائياً من حسابك
              </span>
            </div>
            <div className="grid sm:grid-cols-2 gap-2.5">
              <div className="rounded-xl bg-[#F8F9FA] border border-border p-3 flex items-center gap-2.5">
                <span className="h-9 w-9 rounded-lg bg-white border border-border flex items-center justify-center shrink-0">
                  <User className="h-4 w-4 text-[#FF6B00]" />
                </span>
                <div className="min-w-0">
                  <div className="text-[10px] text-muted-foreground">الاسم</div>
                  <div className="font-black text-sm truncate">{user.name}</div>
                </div>
              </div>
              <div className="rounded-xl bg-[#F8F9FA] border border-border p-3 flex items-center gap-2.5">
                <span className="h-9 w-9 rounded-lg bg-white border border-border flex items-center justify-center shrink-0">
                  <Phone className="h-4 w-4 text-[#FF6B00]" />
                </span>
                <div className="min-w-0">
                  <div className="text-[10px] text-muted-foreground">رقم الهاتف</div>
                  <div className="font-black text-sm" dir="ltr">
                    {formatPhoneDisplay(user.phone || "")}
                  </div>
                </div>
              </div>
            </div>
            <p className="text-[11px] text-muted-foreground flex items-center gap-1.5 leading-relaxed">
              <ShieldCheck className="h-3.5 w-3.5 shrink-0 text-[#2E7D32]" />
              لا حاجة لإدخال الاسم أو الرقم — نستخدم بيانات حسابك تلقائياً في كل طلب
            </p>
          </div>

          {/* موقع التوصيل داخل حديثة — تلقائي أو يدوي */}
          <div className="bg-white rounded-2xl border border-border p-4 space-y-3.5">
            <h2 className="font-black text-sm flex items-center gap-2">
              <Navigation className="h-4 w-4 text-[#FF6B00]" /> موقع التوصيل في مدينة حديثة
            </h2>

            {/* زر التحديد التلقائي + حالة الوضع اليدوي */}
            <div className="flex flex-wrap items-center gap-2">
              <Button
                type="button"
                onClick={autoLocate}
                disabled={locating}
                className={`rounded-full h-9 font-black text-xs ${
                  geoMode === "auto"
                    ? "bg-[#E6F4EA] text-[#2E7D32] hover:bg-[#D8EDDE] border border-[#2E7D32]/30"
                    : "bg-[#2E7D32] hover:bg-[#256B29] text-white"
                }`}
              >
                {locating ? (
                  <Loader2 className="h-4 w-4 animate-spin me-1.5" />
                ) : (
                  <LocateFixed className="h-4 w-4 me-1.5" />
                )}
                {locating ? "جاري تحديد موقعك…" : geoMode === "auto" ? "تم تحديد موقعك تلقائياً ✅" : "تحديد موقعي تلقائياً (GPS)"}
              </Button>
              {geoMode === "manual" && (
                <span className="text-[11px] font-bold text-[#FF6B00] flex items-center gap-1">
                  <Pencil className="h-3 w-3" />
                  وضع يدوي: اختر الحي ثم انقر على الخريطة
                </span>
              )}
            </div>

            <div className="grid sm:grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>الحي / المنطقة *</Label>
                <Select value={area} onValueChange={setArea}>
                  <SelectTrigger className="bg-[#F8F9FA]">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {HADITHA_AREAS.map((a) => (
                      <SelectItem key={a} value={a}>
                        {a}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cust-details">أقرب نقطة دالة / الشارع *</Label>
                <Input id="cust-details" value={detailsVal} onChange={(e) => setDetails(e.target.value)} placeholder="مثال: قرب مدرسة الفرات، بناية 8" className="bg-[#F8F9FA]" />
              </div>
            </div>

            {/* خريطة حديثة — انقر لتحديد موقعك */}
            <div className="space-y-2">
              <Label className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <MapPin className="h-3.5 w-3.5 text-[#FF6B00]" />
                {geoMode === "auto"
                  ? "موقعك المحدد تلقائياً — انقر على الخريطة لتعديله بدقة"
                  : "انقر على الخريطة لتحديد موقع منزلك بدقة (سينتقل السائق إليه)"}
              </Label>
              <div className="rounded-2xl overflow-hidden border border-border">
                <HadithaMap
                  storeLoc={HADITHA_CENTER}
                  dest={pin}
                  pickMode
                  onPick={(p) => {
                    setPin(p);
                    setGeoMode("manual");
                  }}
                  className="h-56 w-full"
                  fitKey="picker"
                />
              </div>
              <p className="text-[11px] text-muted-foreground flex items-center gap-1">
                <MapPin className="h-3 w-3 text-[#FF6B00]" />
                الموقع المحدد: <span dir="ltr" className="font-bold">{pin.lat.toFixed(5)}, {pin.lng.toFixed(5)}</span>
                {geoMode === "auto" && <span className="text-[#2E7D32] font-black"> (GPS تلقائي)</span>}
                {geoMode === "manual" && <span className="text-[#FF6B00] font-black"> (يدوي)</span>}
              </p>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="cust-notes" className="flex items-center gap-1.5">
                <StickyNote className="h-3.5 w-3.5 text-[#FF6B00]" /> ملاحظات للوكيل (اختياري)
              </Label>
              <Textarea id="cust-notes" value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="مثال: اتصل بي عند الوصول، الطابق الثاني..." className="bg-[#F8F9FA] min-h-16" />
            </div>
          </div>

          <div className="bg-white rounded-2xl border border-border p-4">
            <h2 className="font-black text-sm mb-3">طريقة الدفع</h2>
            <RadioGroup value={payment} onValueChange={(v) => setPayment(v as "CASH" | "CARD")} className="grid grid-cols-2 gap-3">
              <Label
                htmlFor="pay-cash"
                className={`flex items-center gap-3 rounded-xl border p-3.5 cursor-pointer transition ${payment === "CASH" ? "border-[#FF6B00] bg-[#FFF3E6]" : "border-border hover:border-[#FFAA00]"}`}
              >
                <RadioGroupItem value="CASH" id="pay-cash" />
                <Banknote className="h-5 w-5 text-[#2E7D32]" />
                <div>
                  <div className="font-bold text-sm">نقداً عند الاستلام</div>
                  <div className="text-[11px] text-muted-foreground">ادفع للوكيل مباشرة</div>
                </div>
              </Label>
              <Label
                htmlFor="pay-card"
                className={`flex items-center gap-3 rounded-xl border p-3.5 cursor-pointer transition ${payment === "CARD" ? "border-[#FF6B00] bg-[#FFF3E6]" : "border-border hover:border-[#FFAA00]"}`}
              >
                <RadioGroupItem value="CARD" id="pay-card" />
                <CreditCard className="h-5 w-5 text-[#FFAA00]" />
                <div>
                  <div className="font-bold text-sm">بطاقة / محفظة</div>
                  <div className="text-[11px] text-muted-foreground">دفع إلكتروني آمن</div>
                </div>
              </Label>
            </RadioGroup>
          </div>
        </div>

        {/* ملخص الطلب */}
        <div className="lg:col-span-2 bg-white rounded-2xl border border-border p-4 lg:sticky lg:top-24">
          <h2 className="font-black text-sm mb-3">ملخص السلة</h2>
          <div className="space-y-3 max-h-72 overflow-y-auto nice-scroll pe-1">
            {cart.map((l) => (
              <div key={l.id} className="flex items-center gap-2.5">
                <div className="flex items-center gap-1 bg-[#F8F9FA] border border-border rounded-full px-1 py-0.5 shrink-0">
                  <button className="h-5 w-5 text-[#FF6B00] font-bold" onClick={() => updateQty(l.id, -1)} aria-label="إنقاص">−</button>
                  <span className="text-xs font-bold w-4 text-center">{l.quantity}</span>
                  <button className="h-5 w-5 text-[#FF6B00] font-bold" onClick={() => updateQty(l.id, 1)} aria-label="زيادة">+</button>
                </div>
                <span className="text-sm flex-1 truncate">{l.name}</span>
                <span className="text-sm font-bold whitespace-nowrap">{formatIQD(l.price * l.quantity)}</span>
              </div>
            ))}
          </div>
          <Separator className="my-3.5" />
          <div className="space-y-1.5 text-sm">
            <div className="flex justify-between text-muted-foreground">
              <span>مجموع الأصناف</span>
              <span>{formatIQD(subtotal)}</span>
            </div>
            <div className="flex justify-between text-muted-foreground">
              <span>أجرة التوصيل</span>
              <span>{fee === 0 ? "مجاني" : formatIQD(fee)}</span>
            </div>
            <Separator className="my-2" />
            <div className="flex justify-between font-black text-base">
              <span>المجموع الكلي</span>
              <span className="text-[#FF6B00]">{formatIQD(total)}</span>
            </div>
          </div>
          <Button className="w-full mt-4 rounded-full bg-[#FF6B00] hover:bg-[#E85F00] h-11 font-black text-base" onClick={submitOrder} disabled={submitting}>
            {submitting ? <Loader2 className="h-5 w-5 animate-spin me-2" /> : null}
            {submitting ? "جاري الإرسال..." : "تأكيد الطلب 🛵"}
          </Button>
          <p className="text-[11px] text-muted-foreground text-center mt-2">بتأكيدك الطلب أنت توافق على شروط الخدمة</p>
        </div>
      </div>
    </div>
  );
}
