"use client";

import { useEffect, useMemo, useState } from "react";
import { ArrowRight, Star, Clock, Truck, MapPin, Phone, Plus, Minus, ShoppingCart, Flame } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { formatIQD } from "@/lib/format";
import { TYPE_AR, type Store, type StoreType } from "@/lib/types";
import { useAppStore, cartSubtotal } from "@/store/app-store";

interface Props {
  storeId: string;
}

export function StoreView({ storeId }: Props) {
  const [store, setStore] = useState<Store | null>(null);
  const [loading, setLoading] = useState(true);
  const [section, setSection] = useState<string>("الكل");
  const setView = useAppStore((s) => s.setView);
  const { addToCart, updateQty, cart, clearCartIfDifferentStore } = useAppStore();

  useEffect(() => {
    let cancel = false;
    fetch(`/api/stores/${storeId}`)
      .then((r) => r.json())
      .then((data) => {
        if (!cancel) {
          setStore(data?.id ? data : null);
          setLoading(false);
        }
      })
      .catch(() => {
        if (!cancel) setLoading(false);
      });
    return () => {
      cancel = true;
    };
  }, [storeId]);

  useEffect(() => {
    clearCartIfDifferentStore(storeId);
  }, [storeId, clearCartIfDifferentStore]);

  const sections = useMemo(() => {
    if (!store?.items) return [];
    return Array.from(new Set(store.items.map((i) => i.section)));
  }, [store]);

  const visibleItems = useMemo(() => {
    if (!store?.items) return [];
    return section === "الكل" ? store.items : store.items.filter((i) => i.section === section);
  }, [store, section]);

  const subtotal = cartSubtotal(cart);

  if (loading) {
    return (
      <div className="max-w-6xl mx-auto px-4 pb-32 pt-4 space-y-4">
        <Skeleton className="h-56 w-full rounded-3xl" />
        <Skeleton className="h-8 w-1/3" />
        <div className="grid grid-cols-2 gap-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24 rounded-2xl" />
          ))}
        </div>
      </div>
    );
  }

  if (!store) {
    return (
      <div className="max-w-6xl mx-auto px-4 pb-32 pt-16 text-center">
        <div className="text-5xl mb-3">😕</div>
        <p className="font-bold text-lg">المتجر غير موجود</p>
        <Button className="mt-4 rounded-full bg-[#FF6B00] hover:bg-[#FF6B00]/90" onClick={() => setView({ name: "home" })}>
          العودة للرئيسية
        </Button>
      </div>
    );
  }

  const typeIcon = store.type === "RESTAURANT" ? "🍽️" : store.type === "MARKET" ? "🛒" : "🏬";

  return (
    <div className="max-w-6xl mx-auto px-4 pb-40 pt-4">
      <button
        onClick={() => setView({ name: "home" })}
        className="flex items-center gap-1.5 text-sm font-bold text-muted-foreground hover:text-[#FF6B00] transition mb-3"
      >
        <ArrowRight className="h-4 w-4" />
        رجوع
      </button>

      {/* غلاف المتجر */}
      <div className="rounded-3xl overflow-hidden border border-border bg-white anim-in">
        <div className="relative h-44 sm:h-60">
          <img
            src={store.coverUrl || store.imageUrl || "/placeholder-restaurant.svg"}
            alt={store.name}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
          <div className="absolute bottom-3 start-4 end-4 text-white">
            <div className="flex items-end justify-between gap-2 flex-wrap">
              <div>
                <h1 className="text-2xl font-black">{store.name}</h1>
                <p className="text-sm text-white/90">{typeIcon} {TYPE_AR[store.type as StoreType] || ""} · {store.category}</p>
              </div>
              <Badge className={`border-0 ${store.isOpen ? "bg-[#2E7D32]" : "bg-red-500"}`}>
                {store.isOpen ? "مفتوح الآن" : "مغلق"}
              </Badge>
            </div>
          </div>
        </div>

        <div className="p-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-sm">
          <div className="flex items-center gap-2">
            <span className="h-9 w-9 rounded-xl bg-[#FFF3E6] flex items-center justify-center shrink-0">
              <Star className="h-4 w-4 text-[#ffaa00] fill-[#ffaa00]" />
            </span>
            <div><div className="font-bold">{store.rating.toFixed(1)}</div><div className="text-[11px] text-muted-foreground">التقييم</div></div>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-9 w-9 rounded-xl bg-[#FFF6DE] flex items-center justify-center shrink-0">
              <Clock className="h-4 w-4 text-[#FFAA00]" />
            </span>
            <div><div className="font-bold">{store.deliveryTime}</div><div className="text-[11px] text-muted-foreground">وقت التوصيل</div></div>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-9 w-9 rounded-xl bg-[#E6F4EA] flex items-center justify-center shrink-0">
              <Truck className="h-4 w-4 text-[#2E7D32]" />
            </span>
            <div><div className="font-bold">{store.deliveryFee === 0 ? "مجاني" : formatIQD(store.deliveryFee)}</div><div className="text-[11px] text-muted-foreground">أجرة التوصيل</div></div>
          </div>
          <div className="flex items-center gap-2">
            <span className="h-9 w-9 rounded-xl bg-[#FFF6DE] flex items-center justify-center shrink-0">
              <MapPin className="h-4 w-4 text-[#FF6B00]" />
            </span>
            <div className="min-w-0"><div className="font-bold text-xs truncate">{store.address || "حديثة – الأنبار"}</div><div className="text-[11px] text-muted-foreground">العنوان</div></div>
          </div>
        </div>
        {store.description && (
          <p className="px-4 pb-4 text-sm text-muted-foreground">{store.description}</p>
        )}
        {store.phone && (
          <div className="px-4 pb-4 flex items-center gap-2 text-sm text-muted-foreground">
            <Phone className="h-3.5 w-3.5" />
            <span dir="ltr">{store.phone}</span>
          </div>
        )}
      </div>

      {/* شرائح أقسام المنيو */}
      {sections.length > 0 && (
        <div className="sticky top-[64px] z-30 bg-background/95 backdrop-blur py-2.5 -mx-4 px-4">
          <div className="flex gap-2 overflow-x-auto no-scrollbar">
            {["الكل", ...sections].map((sec) => (
              <button
                key={sec}
                onClick={() => setSection(sec)}
                className={`px-3.5 py-2 rounded-full text-xs font-bold whitespace-nowrap border transition ${
                  section === sec
                    ? "bg-[#FF6B00] text-white border-transparent shadow"
                    : "bg-white border-border hover:border-[#FFAA00]"
                }`}
              >
                {sec}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* الأصناف */}
      <div className="mt-3 space-y-3">
        {visibleItems.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center border border-dashed border-[#FFAA00]">
            <div className="text-4xl mb-2">📭</div>
            <p className="font-bold">لا توجد أصناف بعد</p>
            <p className="text-sm text-muted-foreground mt-1">يمكن للمدير إضافة أصناف المنيو من لوحة التحكم</p>
          </div>
        ) : (
          visibleItems.map((item) => {
            const line = cart.find((l) => l.id === item.id);
            const qty = line?.quantity || 0;
            return (
              <div
                key={item.id}
                className={`bg-white rounded-2xl border border-border p-3.5 flex gap-3.5 items-start transition ${!item.isAvailable ? "opacity-55" : "hover:shadow-md"}`}
              >
                <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl overflow-hidden shrink-0 bg-[#F8F9FA]">
                  <img
                    src={item.imageUrl || "/placeholder-restaurant.svg"}
                    alt={item.name}
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h4 className="font-black text-[15px]">{item.name}</h4>
                    {item.isPopular && (
                      <span className="text-[10px] font-bold bg-[#FFF3E6] text-[#FF6B00] px-1.5 py-0.5 rounded flex items-center gap-0.5">
                        <Flame className="h-3 w-3" /> الأكثر طلباً
                      </span>
                    )}
                    {!item.isAvailable && <span className="text-[10px] font-bold text-red-500 bg-red-50 px-1.5 py-0.5 rounded">غير متوفر</span>}
                  </div>
                  {item.description && <p className="text-xs text-muted-foreground mt-0.5 line-clamp-2">{item.description}</p>}
                  <div className="flex items-center justify-between mt-2 flex-wrap gap-2">
                    <span className="font-black text-[#FF6B00]">{formatIQD(item.price)}</span>
                    {item.isAvailable && (
                      qty === 0 ? (
                        <Button
                          size="sm"
                          className="rounded-full bg-[#FF6B00] hover:bg-[#FF6B00]/90 h-8 px-4 text-xs"
                          onClick={() =>
                            addToCart(
                              { id: item.id, name: item.name, price: item.price, quantity: 1, imageUrl: item.imageUrl },
                              { id: store.id, name: store.name, deliveryFee: store.deliveryFee }
                            )
                          }
                        >
                          <Plus className="h-3.5 w-3.5 me-1" /> أضف
                        </Button>
                      ) : (
                        <div className="flex items-center gap-1 bg-[#FF6B00] rounded-full px-1 py-0.5">
                          <button
                            className="h-7 w-7 rounded-full bg-white text-[#FF6B00] flex items-center justify-center hover:bg-white/90"
                            onClick={() => updateQty(item.id, -1)}
                            aria-label="إنقاص الكمية"
                          >
                            <Minus className="h-3.5 w-3.5" />
                          </button>
                          <span className="text-white font-bold text-sm w-6 text-center">{qty}</span>
                          <button
                            className="h-7 w-7 rounded-full bg-white text-[#FF6B00] flex items-center justify-center hover:bg-white/90"
                            onClick={() => updateQty(item.id, 1)}
                            aria-label="زيادة الكمية"
                          >
                            <Plus className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      )
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* شريط السلة العائم */}
      {cart.length > 0 && subtotal > 0 && (
        <div className="fixed bottom-[88px] inset-x-0 z-40 px-4">
          <button
            onClick={() => setView({ name: "checkout" })}
            className="max-w-6xl mx-auto w-full bg-[#FF6B00] text-white rounded-2xl px-5 py-3.5 flex items-center justify-between shadow-xl hover:bg-[#E85F00] transition"
          >
            <span className="flex items-center gap-2 font-bold text-sm">
              <span className="relative">
                <ShoppingCart className="h-5 w-5" />
                <span className="absolute -top-2 -end-2 bg-white text-[#FF6B00] text-[10px] font-black rounded-full h-4.5 w-4.5 flex items-center justify-center">
                  {cart.reduce((s, l) => s + l.quantity, 0)}
                </span>
              </span>
              {cartStoreNameLabel(cart.length)}
            </span>
            <span className="font-black">{formatIQD(subtotal)} ← إتمام الطلب</span>
          </button>
        </div>
      )}
    </div>
  );
}

function cartStoreNameLabel(count: number): string {
  return count > 0 ? `${count} صنف في السلة` : "السلة";
}
