"use client";

// الشريط السفلي لجيبلي — الرئيسية، تتبع، حسابي، السلة، الضبط
// الضبط في الأسفل (مع بار السلة والرئيسية) + دليل «كيف يعمل جيبلي؟» للأطراف الثلاثة
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Home,
  ShoppingCart,
  UserRound,
  MapPinned,
  Settings,
  Package,
  Bike,
  ChevronLeft,
  ShoppingBag,
  HelpCircle,
  UtensilsCrossed,
  Smartphone,
} from "lucide-react";
import { Sheet, SheetContent, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { useAppStore, cartSubtotal } from "@/store/app-store";
import { formatIQD } from "@/lib/format";
import Image from "next/image";

interface NavItem {
  key: string;
  label: string;
  icon: typeof Home;
  active: boolean;
  onClick: () => void;
  badge?: number;
}

// ===== دليل عمل التطبيق للأطراف الثلاثة =====
const HOW_IT_WORKS = [
  {
    icon: Smartphone,
    tone: "bg-[#FFF3E6] text-[#FF6B00]",
    title: "١) عند المستخدم (العميل)",
    steps: [
      "يدخل رقم هاتفه العراقي ويستلم رمز تحقق — بدون كلمة مرور — فيصبح حسابه جاهزاً خلال ثوانٍ.",
      "يتصفح مطاعم ومتاجر وأسواق حديثة، ويضيف ما يريد إلى السلة (بياناته وموقعها تُعبأ تلقائياً).",
      "يحدد موقعه تلقائياً عبر GPS أو يدوياً من الخريطة، ثم يؤكد الطلب ويدفع نقداً عند الاستلام أو بالبطاقة.",
      "يتابع الكابتن لحظياً على خريطة حديثة مع مدة الوصول المتوقعة، ويستلم إشعارات كل تغيير بحالة الطلب.",
    ],
  },
  {
    icon: UtensilsCrossed,
    tone: "bg-[#FFF6DE] text-[#FFAA00]",
    title: "٢) عند المطعم (أو المتجر / السوق)",
    steps: [
      "يصل الطلب فوراً إلى لوحة المطعم في تطبيق جيبلي مع رقم الطلب والأصناف والعنوان.",
      "يضغط «قبول» فيتحول الطلب إلى «قيد التحضير»، ويشاهد العميل الحالة على هاتفه مباشرة.",
      "بعد تجهيز الطلب يضغط «جاهز للاستلام» فيظهر الطلب للوكلاء المتاحين القريبين.",
      "يستلم مبالغ الطلبات النقدية ويحاسبها مع الإدارة، ويراقب تقييماته ومبيعاته من لوحة المدير.",
    ],
  },
  {
    icon: Bike,
    tone: "bg-[#E6F4EA] text-[#2E7D32]",
    title: "٣) عند سائق التوصيل (الوكيل / الكابتن)",
    steps: [
      "يفتح تطبيق الوكيل ويغيّر حالته إلى «متاح» — سيارة أو دراجة — لتبدأ الطلبات بالوصول إليه.",
      "يقبل الطلب ويذهب للمطعم: يستلم الطلب بعد تجهيزه ويتأكد من الأصناف.",
      "يتبع مسار العميل على خريطة حديثة المباشرة، وعند التسليم يضغط «تم التسليم» فيُغلق الطلب.",
      "ترتفع تقييماته وعدد توصيلاته تلقائياً، وتبلغ أجرة التوصيل له حسب المسافة والمركبة.",
    ],
  },
];

function HowItWorksDialog({ open, onOpenChange }: { open: boolean; onOpenChange: (v: boolean) => void }) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="rounded-3xl max-w-lg max-h-[85dvh] overflow-y-auto nice-scroll">
        <DialogHeader className="text-start">
          <DialogTitle className="flex items-center gap-2 text-lg">
            <Image src="/brand/jeebly-icon.png" alt="جيبلي" width={32} height={32} className="h-8 w-8 rounded-lg" />
            كيف يعمل تطبيق جيبلي؟
          </DialogTitle>
          <DialogDescription className="text-xs leading-relaxed">
            رحلة الطلب داخل مدينة حديثة من لحظة الطلب حتى التسليم — عند المستخدم والمطعم والسائق
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-3.5 pb-2">
          {HOW_IT_WORKS.map((sec) => {
            const Icon = sec.icon;
            return (
              <div key={sec.title} className="rounded-2xl border border-border overflow-hidden">
                <div className={`flex items-center gap-2 px-3.5 py-2.5 font-black text-sm ${sec.tone}`}>
                  <Icon className="h-4.5 w-4.5" />
                  {sec.title}
                </div>
                <ol className="p-3.5 space-y-2">
                  {sec.steps.map((s, i) => (
                    <li key={i} className="flex gap-2.5 text-[13px] leading-relaxed">
                      <span className="shrink-0 h-5 w-5 rounded-full bg-[#F8F9FA] border border-border flex items-center justify-center text-[10px] font-black text-[#FF6B00]">
                        {i + 1}
                      </span>
                      <span>{s}</span>
                    </li>
                  ))}
                </ol>
              </div>
            );
          })}
          <p className="text-[11px] text-center text-muted-foreground">
            كل شيء يديره المدير من لوحة التحكم: المتاجر، الوكلاء، الطلبات، والإحصائيات.
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function BottomNav() {
  const view = useAppStore((s) => s.view);
  const setView = useAppStore((s) => s.setView);
  const cart = useAppStore((s) => s.cart);
  const [openSettings, setOpenSettings] = useState(false);
  const [openHelp, setOpenHelp] = useState(false);

  const subtotal = cartSubtotal(cart);
  const itemsCount = cart.reduce((s, l) => s + l.quantity, 0);
  const cartStoreName = useAppStore((s) => s.cartStoreName);

  const items: NavItem[] = [
    {
      key: "home",
      label: "الرئيسية",
      icon: Home,
      active: view.name === "home" || view.name === "store",
      onClick: () => setView({ name: "home" }),
    },
    {
      key: "track",
      label: "تتبع",
      icon: MapPinned,
      active: view.name === "track" || view.name === "myOrders",
      onClick: () => setView({ name: "myOrders" }),
    },
    {
      key: "account",
      label: "حسابي",
      icon: UserRound,
      active: view.name === "account",
      onClick: () => setView({ name: "account" }),
    },
    {
      key: "cart",
      label: "السلة",
      icon: ShoppingCart,
      active: view.name === "checkout",
      onClick: () => setView({ name: "checkout" }),
      badge: itemsCount,
    },
    {
      key: "settings",
      label: "الضبط",
      icon: Settings,
      active: false,
      onClick: () => setOpenSettings(true),
    },
  ];

  return (
    <>
      {/* بار السلة العائم — يظهر فوق الشريط الرئيسي عند وجود أصناف بالسلة */}
      <AnimatePresence>
        {subtotal > 0 && view.name !== "checkout" && (
          <motion.div
            initial={{ y: 90, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 90, opacity: 0 }}
            transition={{ type: "spring", stiffness: 340, damping: 30 }}
            className="fixed inset-x-3 z-40"
            style={{ bottom: "calc(72px + env(safe-area-inset-bottom))" }}
            role="region"
            aria-label="بار السلة"
          >
            <button
              onClick={() => setView({ name: "checkout" })}
              className="w-full brand-gradient rounded-2xl shadow-brand px-3.5 py-2.5 flex items-center gap-3 text-white text-right"
              aria-label="أكمل الطلب — عرض السلة"
            >
              <span className="relative h-10 w-10 rounded-xl bg-white/20 backdrop-blur flex items-center justify-center shrink-0">
                <ShoppingBag className="h-5 w-5" />
                <span className="absolute -top-1.5 -end-1.5 bg-white text-[#FF6B00] text-[10px] font-black rounded-full min-w-5 h-5 px-1 flex items-center justify-center shadow">
                  {itemsCount}
                </span>
              </span>
              <span className="flex-1 min-w-0">
                <span className="block font-black text-sm leading-tight">
                  سلتك من {cartStoreName || "المتجر"}
                </span>
                <span className="block text-[11px] text-white/90 mt-0.5">
                  {formatIQD(subtotal)} — أكمل طلبك الآن
                </span>
              </span>
              <span className="flex items-center gap-0.5 font-black text-xs bg-white/20 backdrop-blur rounded-full px-3 py-1.5 shrink-0">
                أكمل الطلب
                <ChevronLeft className="h-4 w-4" />
              </span>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* الشريط الرئيسي السفلي — 5 أقسام */}
      <nav
        className="fixed bottom-0 inset-x-0 z-50 bg-white/97 backdrop-blur-md border-t border-border safe-bottom"
        aria-label="التنقل الرئيسي"
      >
        <div className="max-w-6xl mx-auto grid grid-cols-5">
          {items.map((it) => {
            const Icon = it.icon;
            return (
              <button
                key={it.key}
                onClick={it.onClick}
                className={`relative flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-bold transition ${
                  it.active ? "text-[#FF6B00]" : "text-muted-foreground hover:text-foreground"
                }`}
                aria-current={it.active ? "page" : undefined}
                aria-label={it.label}
              >
                <span className="relative">
                  <Icon
                    className={`h-5.5 w-5.5 ${it.active ? "scale-110" : ""} transition-transform`}
                  />
                  {it.badge ? (
                    <span className="absolute -top-1.5 -end-2 bg-[#FF6B00] text-white text-[9px] font-black rounded-full min-w-4 h-4 px-1 flex items-center justify-center ring-2 ring-white">
                      {it.badge}
                    </span>
                  ) : null}
                </span>
                {it.label}
                {it.active && <span className="absolute top-0 w-8 h-0.5 bg-[#FF6B00] rounded-full" />}
              </button>
            );
          })}
        </div>
      </nav>

      {/* ورقة الضبط — من الأسفل */}
      <Sheet open={openSettings} onOpenChange={setOpenSettings}>
        <SheetContent side="bottom" className="rounded-t-3xl p-0 max-h-[85dvh] flex flex-col">
          <SheetHeader className="p-5 pb-3 warm-gradient rounded-t-3xl">
            <SheetTitle className="flex items-center gap-2 text-[#111827]">
              <Image
                src="/brand/jeebly-icon.png"
                alt="جيبلي Jeebly"
                width={34}
                height={34}
                className="h-9 w-9 rounded-xl"
              />
              ضبط وقوائم تطبيق جيبلي
            </SheetTitle>
          </SheetHeader>
          <div className="p-3 space-y-1 overflow-y-auto">
            <button
              onClick={() => {
                setOpenHelp(true);
              }}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-[#F8F9FA] transition text-sm font-semibold"
            >
              <span className="h-9 w-9 rounded-lg bg-[#E6F4EA] flex items-center justify-center">
                <HelpCircle className="h-4.5 w-4.5 text-[#2E7D32]" />
              </span>
              كيف يعمل جيبلي؟ (المستخدم · المطعم · السائق)
            </button>
            <button
              onClick={() => {
                setView({ name: "account" });
                setOpenSettings(false);
              }}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-[#F8F9FA] transition text-sm font-semibold"
            >
              <span className="h-9 w-9 rounded-lg bg-[#FFF3E6] flex items-center justify-center">
                <UserRound className="h-4.5 w-4.5 text-[#FF6B00]" />
              </span>
              حسابي وطلباتي
            </button>
            <button
              onClick={() => {
                setView({ name: "myOrders" });
                setOpenSettings(false);
              }}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-[#F8F9FA] transition text-sm font-semibold"
            >
              <span className="h-9 w-9 rounded-lg bg-[#FFF6DE] flex items-center justify-center">
                <Package className="h-4.5 w-4.5 text-[#FFAA00]" />
              </span>
              تتبع طلب برقمه
            </button>
            <button
              onClick={() => {
                setView({ name: "admin" });
                setOpenSettings(false);
              }}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-[#F8F9FA] transition text-sm font-semibold"
            >
              <span className="h-9 w-9 rounded-lg bg-[#FFF6DE] flex items-center justify-center">
                <Settings className="h-4.5 w-4.5 text-[#FFAA00]" />
              </span>
              لوحة تحكم المدير
            </button>
            <button
              onClick={() => {
                setView({ name: "agent" });
                setOpenSettings(false);
              }}
              className="w-full flex items-center gap-3 p-3 rounded-xl hover:bg-[#F8F9FA] transition text-sm font-semibold"
            >
              <span className="h-9 w-9 rounded-lg bg-[#E6F4EA] flex items-center justify-center">
                <Bike className="h-4.5 w-4.5 text-[#2E7D32]" />
              </span>
              تطبيق الوكيل (الكابتن)
            </button>
          </div>
          <div className="px-5 py-4 mt-auto text-xs text-muted-foreground border-t">
            <div className="flex items-center gap-1.5 mb-1">
              <MapPinned className="h-3.5 w-3.5 text-[#FF6B00]" />
              <span className="font-semibold text-foreground">مدينة حديثة – محافظة الأنبار</span>
            </div>
            التوصيل متاح داخل مدينة حديثة فقط
          </div>
        </SheetContent>
      </Sheet>

      <HowItWorksDialog open={openHelp} onOpenChange={setOpenHelp} />
    </>
  );
}
