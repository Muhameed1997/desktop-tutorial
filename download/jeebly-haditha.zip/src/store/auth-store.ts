"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface AuthUser {
  id: string;
  name: string;
  email?: string | null;
  phone?: string | null;
  address?: string | null;
}

interface AuthState {
  user: AuthUser | null;
  setUser: (u: AuthUser | null) => void;
  /** مزامنة مع الخادم عند بدء التطبيق (التحقق من الكوكيز) */
  sync: () => Promise<void>;
  logout: () => Promise<void>;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      setUser: (u) => set({ user: u }),

      sync: async () => {
        try {
          const res = await fetch("/api/auth/me");
          const data = await res.json();
          set({ user: data && data.id ? data : null });
        } catch {
          /* تجاهل أخطاء الشبكة */
        }
      },

      logout: async () => {
        await fetch("/api/auth/logout", { method: "POST" }).catch(() => {});
        set({ user: null });
      },
    }),
    { name: "toters-auth" }
  )
);
