"use client";

import { create } from "zustand";
import { persist } from "zustand/middleware";

export interface CartLine {
  id: string; // معرف الصنف
  name: string;
  price: number;
  quantity: number;
  imageUrl?: string | null;
}

export type View =
  | { name: "home" }
  | { name: "store"; storeId: string }
  | { name: "checkout" }
  | { name: "account" }
  | { name: "myOrders" }
  | { name: "track"; code: string }
  | { name: "admin" }
  | { name: "agent" };

interface AppState {
  view: View;
  setView: (v: View) => void;
  goHome: () => void;

  // السلة
  cart: CartLine[];
  cartStoreId: string | null;
  cartStoreName: string | null;
  cartStoreFee: number;
  addToCart: (line: CartLine, store: { id: string; name: string; deliveryFee: number }) => void;
  updateQty: (id: string, delta: number) => void;
  clearCart: () => void;
  clearCartIfDifferentStore: (storeId: string) => void;

  // آخر طلب تم إنشاؤه (لتتبعه)
  lastOrderCode: string | null;
  setLastOrderCode: (code: string | null) => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      view: { name: "home" },
      setView: (v) => set({ view: v }),
      goHome: () => set({ view: { name: "home" } }),

      cart: [],
      cartStoreId: null,
      cartStoreName: null,
      cartStoreFee: 0,

      addToCart: (line, store) => {
        const state = get();
        // إذا كان السلة من متجر مختلف → نبدأ سلة جديدة
        const sameStore = state.cartStoreId === store.id;
        const cart = sameStore ? state.cart.map((l) => ({ ...l })) : [];
        const idx = cart.findIndex((l) => l.id === line.id);
        if (idx >= 0) {
          cart[idx] = { ...cart[idx], quantity: cart[idx].quantity + line.quantity };
        } else {
          cart.push(line);
        }
        set({
          cart,
          cartStoreId: store.id,
          cartStoreName: store.name,
          cartStoreFee: store.deliveryFee,
        });
      },

      updateQty: (id, delta) => {
        const state = get();
        let cart = state.cart
          .map((l) => (l.id === id ? { ...l, quantity: l.quantity + delta } : l))
          .filter((l) => l.quantity > 0);
        set({ cart });
      },

      clearCart: () => set({ cart: [], cartStoreId: null, cartStoreName: null, cartStoreFee: 0 }),

      clearCartIfDifferentStore: (storeId) => {
        const state = get();
        if (state.cartStoreId && state.cartStoreId !== storeId) {
          set({ cart: [], cartStoreId: null, cartStoreName: null, cartStoreFee: 0 });
        }
      },

      lastOrderCode: null,
      setLastOrderCode: (code) => set({ lastOrderCode: code }),
    }),
    { name: "toters-clone-store" }
  )
);

export function cartSubtotal(cart: CartLine[]): number {
  return cart.reduce((s, l) => s + l.price * l.quantity, 0);
}
