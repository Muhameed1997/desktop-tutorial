// تنسيق الأرقام والعملة (دينار عراقي)
export function formatIQD(amount: number): string {
  return `${new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 0 }).format(Math.round(amount))} د.ع`;
}

export function formatNumber(amount: number): string {
  return new Intl.NumberFormat("ar-IQ", { maximumFractionDigits: 0 }).format(Math.round(amount));
}

export function formatDate(dateStr: string): string {
  try {
    return new Intl.DateTimeFormat("ar-IQ", {
      day: "numeric",
      month: "short",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(dateStr));
  } catch {
    return dateStr;
  }
}

// صورة بديلة عند غياب الصورة
export function fallbackImage(type: string): string {
  switch (type) {
    case "RESTAURANT":
      return "/placeholder-restaurant.svg";
    case "MARKET":
      return "/placeholder-market.svg";
    default:
      return "/placeholder-store.svg";
  }
}
