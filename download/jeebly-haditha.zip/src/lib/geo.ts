// أدوات الجغرافيا — مدينة حديثة، محافظة الأنبار، العراق

/** مركز مدينة حديثة */
export const HADITHA_CENTER = { lat: 34.1329, lng: 42.3775 };

/** حدود عرض الخريطة لمدينة حديثة */
export const HADITHA_BOUNDS: [[number, number], [number, number]] = [
  [34.09, 42.32],
  [34.18, 42.44],
];

/** أحياء ومناطق مدينة حديثة لاختيار العنوان */
export const HADITHA_AREAS = [
  "مركز المدينة",
  "حي المعلمين",
  "حي الضباط",
  "حي الكرامة",
  "شارع الستين (60)",
  "السوق القديم",
  "حي المسلك الكبير",
  "حي الجامعة",
  "كورنيش الفرات",
  "الجسر الغربي",
];

/** مسافة هافرساين بالكيلومتر بين نقطتين */
export function haversineKm(a: { lat: number; lng: number }, b: { lat: number; lng: number }): number {
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((a.lat * Math.PI) / 180) * Math.cos((b.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(s));
}

/** استيفاء خطي بين نقطتين (نقطة تقدم من 0 إلى 1) */
export function interpolate(a: { lat: number; lng: number }, b: { lat: number; lng: number }, t: number) {
  const clamped = Math.min(1, Math.max(0, t));
  return {
    lat: a.lat + (b.lat - a.lat) * clamped,
    lng: a.lng + (b.lng - a.lng) * clamped,
  };
}

/**
 * مدة الوصول المتوقعة بالدقائق داخل مدينة حديثة
 * الدراجة ~25 كم/س، السيارة ~35 كم/س + دقيقتان تحضير طريق
 */
export function etaMinutesFor(distanceKm: number, vehicle: string): number {
  const speed = vehicle === "CAR" ? 35 : 25;
  const minutes = (distanceKm / speed) * 60 + 2;
  return Math.min(20, Math.max(4, Math.round(minutes)));
}

/** توليد نقطة عشوائية قريبة من مركز حديثة (لتوزيع المتاجر والوكلاء) */
export function randomHadithaPoint(maxOffset = 0.012) {
  return {
    lat: HADITHA_CENTER.lat + (Math.random() - 0.5) * 2 * maxOffset,
    lng: HADITHA_CENTER.lng + (Math.random() - 0.5) * 2 * maxOffset,
  };
}
