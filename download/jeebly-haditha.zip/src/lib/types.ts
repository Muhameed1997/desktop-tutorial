// أنواع البيانات المشتركة في التطبيق

export type StoreType = "RESTAURANT" | "STORE" | "MARKET";
export type AgentVehicle = "CAR" | "MOTORCYCLE";
export type AgentStatus = "AVAILABLE" | "BUSY" | "OFFLINE";
export type OrderStatus =
  | "PENDING"
  | "CONFIRMED"
  | "PREPARING"
  | "DELIVERING"
  | "DELIVERED"
  | "CANCELLED";

export interface StoreItem {
  id: string;
  storeId: string;
  name: string;
  description?: string | null;
  price: number;
  section: string;
  imageUrl?: string | null;
  isAvailable: boolean;
  isPopular: boolean;
}

export interface Store {
  id: string;
  name: string;
  description?: string | null;
  type: StoreType;
  category: string;
  imageUrl?: string | null;
  coverUrl?: string | null;
  rating: number;
  deliveryFee: number;
  deliveryTime: string;
  minOrder: number;
  isOpen: boolean;
  isFeatured: boolean;
  phone?: string | null;
  address?: string | null;
  lat?: number | null;
  lng?: number | null;
  items?: StoreItem[];
  _count?: { orders?: number; items?: number };
}

export interface Agent {
  id: string;
  name: string;
  phone: string;
  vehicleType: AgentVehicle;
  vehiclePlate?: string | null;
  status: AgentStatus;
  rating: number;
  totalDeliveries: number;
  lat?: number | null;
  lng?: number | null;
  orders?: { id: string; code: string; status: string }[];
}

export interface OrderItemData {
  id: string;
  orderId: string;
  name: string;
  price: number;
  quantity: number;
}

export interface Order {
  id: string;
  code: string;
  customerName: string;
  customerPhone: string;
  address: string;
  notes?: string | null;
  userId?: string | null;
  storeId: string;
  agentId?: string | null;
  status: OrderStatus;
  paymentMethod: string;
  subtotal: number;
  deliveryFee: number;
  total: number;
  destLat?: number | null;
  destLng?: number | null;
  deliveringAt?: string | null;
  etaMinutes?: number | null;
  store?: { id: string; name: string; imageUrl?: string | null; type: string; lat?: number | null; lng?: number | null };
  agent?: { id: string; name: string; phone: string; vehicleType: string; vehiclePlate?: string | null; rating?: number } | null;
  items: OrderItemData[];
  createdAt: string;
  updatedAt: string;
}

export interface Stats {
  stores: { total: number; restaurants: number; stores: number; markets: number };
  agents: { total: number; available: number };
  orders: { total: number; active: number; delivered: number; cancelled: number };
  revenue: number;
  recentOrders: Order[];
  topStores: { id: string; name: string; type: string; imageUrl?: string | null; _count: { orders: number } }[];
}

// حالات الطلب بالعربية
export const ORDER_STATUS_AR: Record<OrderStatus, string> = {
  PENDING: "بانتظار القبول",
  CONFIRMED: "تم القبول",
  PREPARING: "قيد التحضير",
  DELIVERING: "جاري التوصيل",
  DELIVERED: "تم التسليم",
  CANCELLED: "ملغي",
};

// ترتيب مراحل الطلب للتتبع
export const ORDER_FLOW: OrderStatus[] = ["PENDING", "CONFIRMED", "PREPARING", "DELIVERING", "DELIVERED"];

export const TYPE_AR: Record<StoreType, string> = {
  RESTAURANT: "مطعم",
  STORE: "متجر",
  MARKET: "سوق",
};

export const VEHICLE_AR: Record<AgentVehicle, string> = {
  CAR: "سيارة",
  MOTORCYCLE: "دراجة",
};

export const AGENT_STATUS_AR: Record<AgentStatus, string> = {
  AVAILABLE: "متاح",
  BUSY: "مشغول",
  OFFLINE: "غير متصل",
};
