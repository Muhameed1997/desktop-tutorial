// أدوات رقم الهاتف العراقي — التسجيل بدون الحاجة لمفتاح الدولة (+964 يُضاف تلقائياً)

/**
 * تطبيع أي صيغة رقم عراقي إلى الصيغة المحلية 07XXXXXXXXX
 * يقبل: 07701234567 · 7701234567 · +9647701234567 · 009647701234567 · 9647701234567
 * مع تجاهل المسافات والشرطات والأقواس.
 * يُرجع null إذا كان الرقم غير صالح.
 */
export function normalizeIrPhone(input: string): string | null {
  if (!input) return null;
  let d = String(input).replace(/[^\d]/g, ""); // نحتفظ بالأرقام فقط

  // إزالة مفتاح الدولة بأشكاله المختلفة (الرقم يُقبل بدون مفتاح الدولة)
  if (d.startsWith("00964")) d = d.slice(5);
  else if (d.startsWith("964") && d.length > 10) d = d.slice(3);

  // 7XXXXXXXXX (10 أرقام بدون الصفر) → نضيف الصفر
  if (d.length === 10 && d.startsWith("7")) d = "0" + d;

  // الصيغة المحلية الصحيحة: 07 + 9 أرقام = 11 رقماً (بادئات 073–079)
  if (/^07[3-9]\d{8}$/.test(d)) return d;

  return null;
}

/** عرض الرقم بصيغة أنيقة: 0770 123 4567 */
export function formatPhoneDisplay(phone: string): string {
  const d = phone.replace(/\D/g, "");
  if (d.length === 11 && d.startsWith("07")) {
    return `${d.slice(0, 4)} ${d.slice(4, 7)} ${d.slice(7)}`;
  }
  return phone;
}

/** مفتاح الدولة العراقي المعروض تلقائياً بجانب حقل الإدخال */
export const IQ_DIAL_CODE = "+964";
