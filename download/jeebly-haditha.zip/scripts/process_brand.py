#!/usr/bin/env python3
# معالجة أصول لوغو جيبلي من إطارات التصميم المرفوعة
# Frame 8  : الأيقونة (J + دبوس + أجنحة) على خلفية برتقالية → jeebly-icon.png
# Frame 6  : الاسم الأبيض "jeebly | جيبلي" على برتقالي → jeebly-wordmark.png (شفاف)
# Frame 8  : استخراج العلامة فقط بإزالة الخلفية → jeebly-mark.png
# مشتق    : إعادة تلوين الاسم الأبيض إلى الداكن → jeebly-wordmark-dark.png
from PIL import Image, ImageFilter
import os

UP = "/home/z/my-project/upload"
OUT = "/home/z/my-project/public/brand"
os.makedirs(OUT, exist_ok=True)

ORANGE = (255, 77, 0)  # خلفية الإطارات البرتقالية


def close(c1, c2, tol=90):
    return all(abs(a - b) <= tol for a, b in zip(c1[:3], c2[:3]))


def chroma_key_transparent(img, key, tol=90):
    """إزالة كل البكسلات القريبة من لون المفتاح مع حواف ناعمة"""
    img = img.convert("RGBA")
    px = img.load()
    w, h = img.size
    for y in range(h):
        for x in range(w):
            r, g, b, a = px[x, y]
            if close((r, g, b), key, tol):
                px[x, y] = (r, g, b, 0)
    return img


def trim(img, pad=14):
    bbox = img.getbbox()
    if not bbox:
        return img
    l, t, r, b = bbox
    l = max(0, l - pad); t = max(0, t - pad)
    r = min(img.width, r + pad); b = min(img.height, b + pad)
    return img.crop((l, t, r, b))


def soften_alpha(img, radius=1.2):
    a = img.split()[3].filter(ImageFilter.GaussianBlur(radius))
    img.putalpha(a)
    return img


# 1) الأيقونة الرسمية — المربع البرتقالي كما هو (الاستد&#160;يران عبر CSS rounded-[28%])
icon = Image.open(f"{UP}/Frame 8.png").convert("RGB")
icon = icon.resize((512, 512), Image.LANCZOS)
icon.save(f"{OUT}/jeebly-icon.png", optimize=True)
print("jeebly-icon.png", icon.size)

# 2) العلامة المائية — العلامة فقط بخلفية شفافة (من Frame 8)
mark = chroma_key_transparent(Image.open(f"{UP}/Frame 8.png"), ORANGE, tol=95)
mark = soften_alpha(mark)
mark = trim(mark)
mark.thumbnail((420, 420), Image.LANCZOS)
mark.save(f"{OUT}/jeebly-mark.png", optimize=True)
print("jeebly-mark.png", mark.size)

# 3) الاسم الأبيض شفاف — من Frame 6
wm = chroma_key_transparent(Image.open(f"{UP}/Frame 6.png"), ORANGE, tol=95)
wm = soften_alpha(wm, 0.8)
wm = trim(wm)
wm.thumbnail((900, 260), Image.LANCZOS)
wm.save(f"{OUT}/jeebly-wordmark.png", optimize=True)
print("jeebly-wordmark.png", wm.size)

# 4) الاسم الداكن — إعادة تلوين الأبيض إلى #111827 مع إبقاء الفاصل الذهبي
dark = wm.copy()
px = dark.load()
for y in range(dark.height):
    for x in range(dark.width):
        r, g, b, a = px[x, y]
        if a > 0 and r > 190 and g > 190 and b > 190:
            px[x, y] = (17, 24, 39, a)
dark.save(f"{OUT}/jeebly-wordmark-dark.png", optimize=True)
print("jeebly-wordmark-dark.png", dark.size)

print("DONE")
